# Xoe-NovAi Development Assistant — VS Code AI Assistant Update Guide Outline (v0.1.3-beta / rev_1.9)

**Meta**: Grok Account: Arcana.Novai; Project: Xoe-NovAi - v0.1.3 → 0.1.4 Phase 1; Chat Session: VS Code AI Docs Alignment Guide for CPU+Vulkan Focus; Timestamp: January 12, 2026 06:12 PM AST

### Executive Summary

This detailed outline serves as your comprehensive guide for instructing the VS Code AI assistant to systematically update all provided documentation. The updates strictly align with 2026 best practices for a cutting-edge, ever-evolving local RAG system—emphasizing CPU sovereignty on Ryzen 7 5700U with Vulkan hooks for iGPU offloading (20-60% gains per AMD 2025-2026 benchmarks), zero-telemetry, and Phase 2 prep (e.g., Qdrant migration for filtered RAG). GPU support is deferred to Q3/Q4 2026, with hooks added as disabled-by-default flags.

**Key Research-Verified Alignments** (Jan 2026):
- **Vulkan Integration**: Build llama.cpp with `-DLLAMA_VULKAN=ON` and `-march=znver2` for Zen2 opt; real-world gains 31-60% on Ryzen iGPU (AMD Ryzen AI docs, llama.cpp ROCm guides).
- **TTS Upgrade**: Kokoro TTS (82M params) leads CPU realtime (300-800ms latency on Ryzen, 1.3-1.6x speedup with batching; wins TTS Arena V2 benchmarks).
- **Vectorstore Evolution**: FAISS for local prototype; Qdrant for production (superior filtering, persistence; 2026 comparisons favor Qdrant for RAG scalability).
- **Plugin/Optimization**: WASM for isolation; strip all GPU/NIM/Triton; enforce Ryzen opt (N_THREADS=6, f16_kv=true).

**Update Philosophy**: Incremental, backward-compatible; self-critique each doc (rate 1-10); validate with code_execution (e.g., latency benchmarks). Target: 95% alignment, <6GB memory, 15-25 tok/s.

### Detailed Outline for VS Code AI Assistant Instructions

Instruct your VS Code AI to follow this outline precisely when updating documents. Provide it with the original docs, my verification report, and this guide. Use chain-of-thought prompting: "Analyze original → Plan changes → Implement → Self-critique → Validate."

#### 1. General Update Principles (Apply to All Docs)
- **CPU+Vulkan Focus**: Replace all GPU sections (e.g., NVIDIA Toolkit, MPS, Dynamo-Triton) with Vulkan hooks. Add disabled flags for future GPU (e.g., `PHASE4_GPU_ENABLED=false` in config.toml). Reference Ryzen-specific builds: `-DLLAMA_VULKAN=ON -march=znver2`.
- **TTS Evolution**: Swap Piper/XTTS to Kokoro TTS. Add integration snippets, benchmarks (target 300-800ms latency), and Docker setup (kokoro-cpu.dockerfile).
- **Vectorstore Prep**: Retain FAISS for Phase 1; add Qdrant migration notes (superior for filtered RAG; enable via `PHASE2_QDRANT_ENABLED=false`).
- **Security/Privacy**: Reinforce zero-telemetry (8 disables); add model provenance tracking in plugins.
- **Performance Targets**: Update tables to Ryzen benchmarks (15-25 tok/s, <1s p95, <6GB); include Vulkan gains (20-60%).
- **Phase Deferral**: GPU to Q3/Q4 2026; add hooks but mark as future.
- **Self-Critique**: Rate updated doc on readability/efficiency/security/extensibility/performance; average ≥8.5.
- **Validation**: Suggest code_execution for snippets (e.g., Vulkan build command, Kokoro latency test).

#### 2. Updates for `script_optimization_tracker.md`
- **Objective**: Align script consolidation with CPU+Vulkan focus; integrate Vulkan build scripts.
- **Specific Changes**:
  - Phase 2: Add Vulkan-specific targets to Makefile (e.g., `make build-vulkan`, `make benchmark-vulkan`).
  - Phase 3: Include Kokoro TTS plugin hooks; update ingest scripts for Qdrant prep.
  - Remove any GPU-related scripts; add redundancy check for Vulkan tools.
  - Update Metrics: Script reduction 23→16; add Vulkan integration as 100% accessible.
- **Pros/Cons Table for Vulkan Script Integration**:

| Aspect          | Pros                          | Cons                         |
| --------------- | ----------------------------- | ---------------------------- |
| Performance     | 20-60% iGPU gains on Ryzen    | Build complexity (+10-15min) |
| Sovereignty     | Fully local, no external deps | Requires AMD drivers update  |
| Maintainability | Modular Makefile targets      | Phase 1 overhead minimal     |

- **Validation Steps**: Run `make build-vulkan` simulation; ensure <6GB memory.

#### 3. Updates for `2026_implementation_plan.md`
- **Objective**: Rephase timeline for CPU+Vulkan priority; defer GPU.
- **Specific Changes**:
  - Week 1: Add Vulkan setup/testing (e.g., Day 1: Vulkan runtime config, benchmarks).
  - Immediate Actions: Include Kokoro TTS integration; Qdrant eval.
  - Long-Term: GPU in Q3/Q4 2026 section; add Vulkan optimization milestones.
  - Update Metrics: Inference <20ms → adjust to Ryzen realistic (50-200ms with Vulkan); add Kokoro latency targets.
  - Resource Requirements: Emphasize CPU workstations; defer GPU infra.
- **Updated Timeline Table** (Excerpt):

| Phase/Week | Key Tasks (CPU+Vulkan Focus) | Deferred GPU Tasks |
| ---------- | ---------------------------- | ------------------ |
| Week 1     | Vulkan build + Kokoro PoC    | N/A                |
| Q3 2026    | N/A                          | GPU Toolkit        |

- **Validation Steps**: Cross-reference with llama.cpp ROCm guides; benchmark Kokoro on Ryzen.

#### 4. Updates for `best_practices_research.md`
- **Objective**: Shift ML Docker to CPU+Vulkan; enhance plugin for local RAG.
- **Specific Changes**:
  - ML Docker: Remove GPU sections; add Vulkan resource management (e.g., `ENV LLAMA_VULKAN_ENABLED=true`).
  - Plugin Best Practices: Add Vulkan capability flag; Kokoro TTS as example plugin.
  - Key Findings: Emphasize Qdrant over FAISS for evolving RAG (filtering/hybrid search).
  - Implementation Recs: Vulkan-aware builds; defer GPU pooling.
  - Expected Impact: Update GPU util → Vulkan gains (20-60%); add Kokoro efficiency (1.3x speedup).
- **Comparison Table: FAISS vs Qdrant for Local RAG**:

| Metric          | FAISS (Current) | Qdrant (Phase 2) | 2026 Advantage |
| --------------- | --------------- | ---------------- | -------------- |
| Filtering       | Basic           | Advanced         | Production RAG |
| Persistence     | In-Memory       | On-Disk          | Scalability    |
| Latency (Ryzen) | <50ms           | <100ms           | Hybrid Search  |

- **Validation Steps**: Code_execution for Vulkan env var test.

#### 5. Updates for `plugin_architecture_design.md`
- **Objective**: Integrate Vulkan/Kokoro as plugin examples; ensure CPU isolation.
- **Specific Changes**:
  - Capabilities: Add `vulkan_access: bool = False`; `tts_kokoro: bool = False`.
  - Architecture Components: Include Vulkan plugin for inference offload.
  - Best Practices: Add Vulkan resource management; Kokoro error handling.
  - Roadmap: Phase 1: Vulkan foundation; Phase 3: Kokoro enhancement.
  - Success Metrics: Update load time <100ms with WASM+Vulkan; add Kokoro stability (99.9%).
- **Plugin Capability Extension Table**:

| New Capability | Description            | Default | Phase |
| -------------- | ---------------------- | ------- | ----- |
| vulkan_access  | Enable iGPU offload    | False   | 1     |
| tts_kokoro     | Kokoro TTS integration | False   | 1     |

- **Validation Steps**: Simulate plugin failure isolation with Vulkan.

#### 6. Updates for `ml_docker_optimization_guide.md`
- **Objective**: Convert to CPU+Vulkan guide; remove GPU entirely.
- **Specific Changes**:
  - GPU Management → Vulkan Resource: Add YAML for Vulkan env; remove NVIDIA.
  - Model Serving: Strip Triton; add llama.cpp Vulkan snippets.
  - Optimization Objectives: Adjust to Ryzen (e.g., 20-60% gain with Vulkan; Kokoro 300ms latency).
  - Implementation Checklist: Add Vulkan build/refactor; Kokoro Docker; Qdrant features.
  - Performance Tables: Update baselines to Ryzen (e.g., inference 200ms → 100ms with Vulkan).
- **Updated Vulkan Config Example**:
  ```yaml
  services:
    rag-api:
      environment:
        - LLAMA_VULKAN_ENABLED=true
        - CMAKE_ARGS="-DLLAMA_VULKAN=ON -march=znver2"
  ```
- **Validation Steps**: Docker build test with Vulkan flags.

### Next Steps & Validation Criteria

1. **Instruct VS Code AI**: Copy this outline + originals; prompt: "Update each doc per guide; self-critique average ≥8.5."
2. **This Week**: Review updated docs; run code_execution on new snippets (e.g., Vulkan build, Kokoro test).
3. **Decision Point**: Benchmark post-updates (tok/s >20 with Vulkan); if <15, iterate.
4. **Long-Term**: Q3 2026 GPU hooks as separate branch.

Ready to draft a sample updated doc or refine this outline? 🚀