# Docker Setup Tutorial

Learn how to deploy Xoe-NovAi using Docker containers for consistent, isolated environments.

## Prerequisites

- Docker Engine 20.10+
- Docker Compose 2.0+
- 8GB RAM minimum
- 20GB free disk space

## Quick Start with Docker Compose

The easiest way to run Xoe-NovAi is using the provided Docker Compose setup:

```bash
# Clone the repository
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi

# Start all services
docker-compose up -d

# Check logs
docker-compose logs -f
```

This starts:
- **RAG API** (Port 8000) - Main AI service
- **Chainlit UI** (Port 8001) - Voice/text interface
- **Redis** (Port 6379) - Caching and session storage
- **Monitoring** (Port 9090/3000) - Prometheus/Grafana

## Manual Docker Setup

For more control, run services individually:

### 1. Build the Documentation Container

```bash
# Build docs container (optional)
docker build -f docs/Dockerfile.docs -t xoe-docs:latest .
```

### 2. Start Redis

```bash
# Start Redis with persistence
docker run -d \
  --name xoe-redis \
  -p 6379:6379 \
  -v xoe-redis-data:/data \
  redis:7-alpine redis-server --appendonly yes
```

### 3. Start RAG API

```bash
# Start the main API service
docker run -d \
  --name xoe-api \
  -p 8000:8000 \
  -e REDIS_URL=redis://host.docker.internal:6379 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/models:/app/models \
  xoe-novai/rag-api:latest
```

### 4. Start Chainlit UI

```bash
# Start the web interface
docker run -d \
  --name xoe-ui \
  -p 8001:8001 \
  --link xoe-api \
  xoe-novai/chainlit-ui:latest
```

## Development Setup

For development with live reloading:

```bash
# Development compose file
docker-compose -f docker-compose.dev.yml up -d

# View logs
docker-compose -f docker-compose.dev.yml logs -f
```

## Production Deployment

For production environments:

```bash
# Use production compose
docker-compose -f docker-compose.prod.yml up -d

# Enable monitoring
docker-compose -f monitoring/docker-compose.monitoring.yml up -d
```

### Production Features

- **Security hardening** - Non-root containers
- **Resource limits** - Memory and CPU constraints
- **Health checks** - Automated service monitoring
- **Logging** - Structured logs with rotation

## Environment Variables

Configure Xoe-NovAi through environment variables:

```bash
# Core settings
XOE_MODEL_PATH=/app/models/gguf
XOE_REDIS_URL=redis://redis:6379
XOE_LOG_LEVEL=INFO

# Performance tuning
XOE_MAX_TOKENS=4096
XOE_TEMPERATURE=0.7
XOE_CONTEXT_WINDOW=2048

# Security
XOE_API_KEY=your-secret-key
XOE_CORS_ORIGINS=http://localhost:3000

# Enterprise features
XOE_ENTERPRISE_MONITORING=true
XOE_SECURITY_AUDITING=true
```

## Volume Management

### Persistent Data

```yaml
volumes:
  xoe-models:
    driver: local
  xoe-data:
    driver: local
  xoe-logs:
    driver: local
```

### Backup Strategy

```bash
# Backup data volumes
docker run --rm -v xoe-data:/data -v $(pwd)/backup:/backup \
  alpine tar czf /backup/data-$(date +%Y%m%d).tar.gz -C /data .

# Restore from backup
docker run --rm -v xoe-data:/data -v $(pwd)/backup:/backup \
  alpine tar xzf /backup/data-20260115.tar.gz -C /data
```

## Networking

### Port Configuration

| Service | Internal Port | External Port | Protocol |
|---------|---------------|---------------|----------|
| RAG API | 8000 | 8000 | HTTP |
| Chainlit UI | 8001 | 8001 | HTTP |
| Redis | 6379 | 6379 | TCP |
| Prometheus | 9090 | 9090 | HTTP |
| Grafana | 3000 | 3000 | HTTP |

### Network Security

```yaml
# Internal network for services
networks:
  xoe-internal:
    driver: bridge
    internal: true

# External access network
networks:
  xoe-external:
    driver: bridge
```

## Troubleshooting Docker Issues

### Common Problems

**Container Won't Start**
```bash
# Check logs
docker logs <container-name>

# Check resource usage
docker stats

# Verify port conflicts
netstat -tlnp | grep :8000
```

**Out of Memory**
```bash
# Increase Docker memory limit
# Docker Desktop: Preferences > Resources > Memory
# Linux: Update /etc/docker/daemon.json
```

**Volume Permission Issues**
```bash
# Fix permissions on host
sudo chown -R $USER:$USER ./data
sudo chmod -R 755 ./data
```

### Performance Optimization

- **Use host networking** for lower latency
- **Enable BuildKit** for faster builds
- **Use multi-stage builds** to reduce image size
- **Implement proper logging** to avoid disk space issues

## Advanced Configuration

### Custom Dockerfiles

For specialized deployments, extend the base images:

```dockerfile
FROM xoe-novai/rag-api:latest

# Add custom models
COPY models/ /app/models/

# Custom configuration
COPY config/custom.toml /app/config.toml

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s \
  CMD curl -f http://localhost:8000/health || exit 1
```

### Orchestration

For large-scale deployments:

```yaml
# Kubernetes deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: xoe-novai
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: rag-api
        image: xoe-novai/rag-api:latest
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
```

## Next Steps

- [Voice Interface Tutorial](voice-interface.md) - Learn voice interactions
- [API Reference](../reference/) - Programmatic access
- [Troubleshooting Guide](../how-to/troubleshooting.md) - Problem solving

---

**Docker Setup**: Reliable, scalable containerized deployment for Xoe-NovAi.
