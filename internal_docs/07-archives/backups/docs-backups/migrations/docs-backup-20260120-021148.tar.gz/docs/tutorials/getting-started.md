# Getting Started with Xoe-NovAi

Complete beginner's guide to setting up and running your first Xoe-NovAi instance.

## What is Xoe-NovAi?

Xoe-NovAi is an enterprise-grade AI assistant that combines:
- **Voice-to-voice conversations** with natural speech synthesis
- **Advanced RAG (Retrieval-Augmented Generation)** for accurate responses
- **Research integration** with cutting-edge AI technologies
- **Enterprise security** and compliance features

## System Requirements

### Minimum Requirements
- **CPU**: AMD Ryzen 5 series or equivalent (Intel i5+)
- **RAM**: 8GB
- **Storage**: 20GB free space
- **OS**: Ubuntu 20.04+, macOS 12+, Windows 10+

### Recommended for Best Experience
- **CPU**: AMD Ryzen 7 series or equivalent (Intel i7+)
- **RAM**: 16GB+
- **Storage**: 50GB SSD
- **GPU**: AMD Radeon RX 6000 series (for Vulkan acceleration)

## Installation Methods

### Option 1: Docker Compose (Recommended)

```bash
# 1. Clone the repository
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi

# 2. Start all services
docker-compose up -d

# 3. Check everything is running
docker-compose ps

# 4. Access the interface
# Voice UI: http://localhost:8001
# API Docs: http://localhost:8000/docs
```

### Option 2: Manual Installation

```bash
# 1. Install Python 3.12
# Ubuntu/Debian
sudo apt update
sudo apt install python3.12 python3.12-venv

# 2. Clone and setup
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi

# 3. Create virtual environment
python3.12 -m venv venv
source venv/bin/activate  # Linux/Mac
# or venv\Scripts\activate  # Windows

# 4. Install dependencies
pip install -r requirements.txt

# 5. Start services
make dev  # Development mode
# or make prod  # Production mode
```

## First Run Experience

### Step 1: Access the Interface

Open your browser and navigate to `http://localhost:8001`. You'll see the Xoe-NovAi voice interface.

### Step 2: Test Voice Input

1. Click the **microphone button**
2. Say: *"Hello, can you tell me about Xoe-NovAi?"*
3. The AI will respond with both voice and text

### Step 3: Try Different Queries

- **General questions**: "What can you help me with?"
- **Technical queries**: "How does RAG work?"
- **Voice settings**: "Change to a different voice"

### Step 4: Explore Features

- **Text mode**: Click the keyboard icon for text-only interaction
- **Settings**: Gear icon for voice and interface preferences
- **History**: View conversation history and export

## Basic Configuration

### Environment Variables

Create a `.env` file in the project root:

```bash
# Core settings
XOE_MODEL_PATH=./models
XOE_REDIS_URL=redis://localhost:6379

# Voice settings
XOE_VOICE_MODEL=en_US-lessac-medium
XOE_SPEECH_RATE=1.0

# Performance
XOE_MAX_TOKENS=2048
XOE_TEMPERATURE=0.7
```

### Voice Customization

```bash
# Available voices (auto-detected)
XOE_VOICE_MODEL=en_US-lessac-medium    # Female, clear
XOE_VOICE_MODEL=en_US-ryan-medium      # Male, warm
XOE_VOICE_MODEL=en_GB-alan-medium      # British male

# Speech parameters
XOE_SPEECH_RATE=0.8    # Slower
XOE_SPEECH_RATE=1.2    # Faster
```

## Understanding the Interface

### Voice Controls
- **🎤 Microphone**: Start/stop voice recording
- **🔇 Mute**: Disable voice output
- **⚙️ Settings**: Voice and interface preferences
- **📝 Text**: Switch to text-only mode

### Response Types
- **Voice + Text**: Full multimedia response
- **Text Only**: Written responses only
- **Code Blocks**: Syntax-highlighted code examples
- **Links**: Clickable references to documentation

## Common First-Time Issues

### Microphone Not Working
```bash
# Check browser permissions
# Chrome: Settings > Privacy > Microphone
# Firefox: Preferences > Privacy > Microphone

# Test microphone access
# Browser console should show "Microphone access granted"
```

### Docker Containers Not Starting
```bash
# Check Docker service
sudo systemctl status docker

# Check available resources
docker system df

# Clean up and retry
docker system prune -f
docker-compose up -d
```

### Voice Not Playing
- Check speaker/headphone connections
- Verify browser audio permissions
- Test with system audio (not browser)
- Check for conflicting audio applications

## Performance Optimization

### For Better Voice Quality
```bash
# Use wired headphones
# Close other audio applications
# Ensure quiet environment
# Use latest browser version
```

### For Faster Responses
```bash
# Use SSD storage
# Close unnecessary applications
# Ensure stable internet (for cloud features)
# Monitor system resources
```

## Next Steps

Now that you have Xoe-NovAi running, explore:

1. **[Voice Interface Tutorial](voice-interface.md)** - Advanced voice features
2. **[Docker Setup Guide](docker-setup.md)** - Container management
3. **[API Reference](../reference/)** - Programmatic access
4. **[Troubleshooting Guide](../how-to/troubleshooting.md)** - Problem solving

## Getting Help

### Community Support
- **GitHub Issues**: Report bugs and request features
- **Documentation**: Comprehensive guides and tutorials
- **Community Forum**: Connect with other users

### Enterprise Support
For organizations needing enterprise support:
- **Priority support**: 24/7 technical assistance
- **Custom deployments**: Tailored configurations
- **Training**: Team onboarding and best practices

---

**Welcome to Xoe-NovAi!** You've successfully set up an advanced AI assistant with voice capabilities. Explore the features and let the AI help you with your tasks.
