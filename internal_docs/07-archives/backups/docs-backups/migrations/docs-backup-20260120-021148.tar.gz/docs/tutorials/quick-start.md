# Quick Start Guide

Welcome to Xoe-NovAi! This guide will get you up and running in minutes.

## Prerequisites

- Docker and Docker Compose
- 8GB RAM minimum (16GB recommended)
- AMD Ryzen CPU (for Vulkan acceleration)

## One-Command Setup

```bash
# Clone and start everything
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi
make all
```

This will:
- Build all Docker containers
- Start the full stack (API, UI, monitoring)
- Set up development environment

## Access Your Instance

- **Voice Chat UI**: http://localhost:8001
- **API Documentation**: http://localhost:8000/docs
- **Health Monitoring**: http://localhost:8000/health

## First Voice Interaction

1. Open http://localhost:8001
2. Click the microphone button
3. Say "Hello, can you help me understand Xoe-NovAi?"
4. The AI will respond with voice and text

## Next Steps

- [Voice Interface Tutorial](voice-interface.md)
- [Docker Setup Guide](docker-setup.md)
- [Getting Started Deep Dive](getting-started.md)

---

**Need Help?** Check the [troubleshooting guide](../how-to/troubleshooting.md) or join our community.
