**Advanced Features of uv: The Fast Python Package & Project Manager (2026 Edition)**

**uv** (developed by Astral, the team behind Ruff) is a **Rust-based**, extremely fast Python package installer, resolver, and project manager. It serves as a **drop-in replacement** for `pip`, `pip-tools`, `virtualenv`, `poetry`, `pipx`, and parts of `pyenv` — often **10–100× faster** than classic tools.

As of January 2026 (latest stable ~0.9.24), uv has matured into a production-grade tool used in CI/CD pipelines, large monorepos, ML/AI workflows, and privacy-sensitive environments (like your Xoe-NovAi stack).

### 1. Core Philosophy & Why It’s Revolutionary

- **Speed** — Written in Rust → zero Python startup overhead, parallel downloads, aggressive caching.
- **Unified** — One binary replaces ~7 tools.
- **Compatible** — `uv pip install` works like classic pip (with extras).
- **Modern** — Lockfiles (`uv.lock`), workspaces, inline script metadata, global shared cache.
- **Minimal** — Tiny footprint, no GIL, content-addressed cache.

### 2. Advanced Features & Commands (Most Useful in 2026)

#### **A. Project Management (Cargo/Poetry-like)**

| Feature                | Command / Example                                      | Why Powerful                                                 |
| ---------------------- | ------------------------------------------------------ | ------------------------------------------------------------ |
| Initialize project     | `uv init myproject`                                    | Creates `pyproject.toml` + `.git/` ready structure           |
| Add/remove dependency  | `uv add fastapi` <br> `uv remove httpx`                | Auto-updates `pyproject.toml` + lockfile                     |
| Lock dependencies      | `uv lock` <br> `uv lock --frozen` (CI-safe)            | Creates `uv.lock` (exact, platform-independent, hash-verified) |
| Sync environment       | `uv sync` <br> `uv sync --frozen`                      | Installs exact locked versions (removes extras)              |
| Run in project context | `uv run main.py` <br> `uv run --with httpx ruff check` | Auto-syncs env first, then runs                              |

**Advanced flags**:
- `--resolution=lowest-direct` — minimal versions (security/testing)
- `--prerelease=explicit` — only allow explicitly requested pre-releases
- `--no-sources` — ignore source distributions (wheels only)

#### **B. Inline Script Dependencies (PEP 723 – Huge for Notebooks/Scripts)**

```python
# example.py
# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "requests>=2.31",
#   "rich>=13.7",
# ]
# ///

import requests
from rich import print
print(requests.get("https://astral.sh").text)
```

```bash
uv add --script example.py pandas     # Adds to inline metadata
uv run example.py                     # Installs deps + runs (cached)
```

#### **C. Tools / Ephemeral CLI Execution (pipx replacement)**

```bash
uvx pycowsay "Moo from uv!"           # Run once (ephemeral env)
uv tool install ruff                  # Install globally (~/.local/share/uv/tools)
uv tool run ruff check .              # Run installed tool
uv tool upgrade --all                 # Update all tools
```

**Advanced**: `--with ruff==0.5.0` — temporary overrides

#### **D. Python Version Management (pyenv-lite)**

```bash
uv python install 3.12 3.13 3.14      # Downloads & installs
uv python list                        # Shows installed versions
uv python pin 3.12.7                  # Pins project to version (.python-version)
uv venv --python 3.13                 # Creates venv with specific interpreter
```

#### **E. Workspaces (Monorepo / Multi-package Support)**

Cargo-style workspaces in `pyproject.toml`:

```toml
[tool.uv.workspace]
members = ["packages/api", "packages/core", "packages/worker"]
```

`uv lock` / `uv sync` coordinates all packages with one lockfile.

#### **F. Caching & Disk Efficiency (Best in Class)**

- Global cache (`~/.cache/uv`) — content-addressed, deduplicated across projects
- Prune unused: `uv cache prune --ci`
- Clean: `uv cache clean`
- Size: `uv cache size -H`

**Production tip**: Use `--offline` + `--no-cache-dir` in air-gapped Docker builds for reproducibility.

#### **G. Pip-Compatible Interface (Most Important for Migration)**

`uv pip` is the drop-in mode:

```bash
uv pip compile requirements.in --universal -o requirements.txt   # like pip-compile
uv pip sync requirements.txt                                          # like pip install -r
uv pip install --system --no-cache-dir fastapi                    # system-wide
uv pip tree --depth 2 --invert                                        # dep tree
uv pip check                                                          # verify compatibility
```

**Advanced pip flags** (all supported):
- `--resolution=lowest-direct`
- `--prerelease=explicit`
- `--require-hashes` — supply-chain security
- `--link-mode=hardlink` — fast container installs
- `--torch-backend=cpu` — PyTorch index selection

### 3. Production / Enterprise Patterns (2026)

- **Docker Builds**:
```dockerfile
RUN curl -LsSf https://astral.sh/uv/install.sh | sh \
    && uv python install 3.12 \
    && uv pip install --system --no-cache -r requirements.txt
```

- **CI/CD (GitHub Actions)**:
```yaml
- name: Install uv
  run: curl -LsSf https://astral.sh/uv/install.sh | sh
- name: Sync deps
  run: uv sync --frozen
```

- **Air-gapped / Offline**:
```bash
uv pip install --offline --no-index --find-links=/wheels -r requirements.txt
```

### 4. Quick Comparison: uv vs Classic pip (2026)

| Task                  | Classic pip | uv (same task)          | Speedup |
| --------------------- | ----------- | ----------------------- | ------- |
| Install 50 deps cold  | 45–120 s    | 3–12 s                  | 10–40×  |
| Sync lockfile in CI   | 30–90 s     | 1–4 s                   | 20–50×  |
| Create venv + install | 15–40 s     | 1–3 s                   | 15×     |
| Run script with deps  | Manual venv | `uv run script.py` (1s) | Instant |

### 5. Migration Tips for Your Xoe-NovAi Stack

1. Install uv globally (one-time):
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

2. Activate venv & migrate:
   ```bash
   source .xoe_novai_py312_venv/bin/activate
   uv pip sync requirements.txt   # Fast replacement for pip install -r
   ```

3. Update Makefile (example):
   ```makefile
   deps-sync:                  ## Sync dependencies with uv
   	uv pip sync requirements.txt
   ```

4. Docker (build stage):
   ```dockerfile
   RUN uv python install 3.12 && uv pip install --system -r requirements.txt
   ```

**Bottom line (2026)**:  
**uv** is no longer experimental — it's the **standard** for fast, reproducible Python workflows.  
Switching gives you **the biggest single speedup** possible in your current stack.
