# **Comprehensive Technical Guide: Enforcing Python 3.12 Compliance in Xoe-NovAi Docker Builds**

**Prepared for: Cline AI Assistant**  
**Date: January 13, 2026**  
**Objective:** This guide resolves the issue of Python 3.13 wheels being downloaded in Python 3.12-targeted containers. Based on deep research from official sources (pip docs, PEP 425, PyPA guidelines) and unofficial reports (GitHub issues, Stack Overflow, Docker forums), the root cause is typically **misinterpretation of logs/cache artifacts**, not actual incompatibility. Python 3.12 containers are fully isolated; pip strictly matches the runtime interpreter's version.

Key Finding: A genuine Python 3.12 interpreter **cannot** install or use cp313-specific wheels (PEP 425 compatibility tags are strict). Observed "3.13 wheels" are likely:
- Pure-Python wheels (`py3-none-any`, compatible across versions).
- Manylinux wheels with broad compatibility.
- Cached artifacts from host or previous layers.
- Log misreads (e.g., "Requires-Python: >=3.9,<3.14" mentioned).

No widespread bugs reported for pip downloading incompatible cpXX wheels in correct containers (as of 2026).

## **1. Docker Python Version Isolation (Fully Isolated by Default)**

Docker containers are isolated; the base image (`python:3.12-slim`) defines the Python version entirely.

**How Isolation Works**:
- `FROM python:3.12-slim` installs CPython 3.12.x (currently 3.12.7+ in official images).
- Pip inside uses the container's `sys.version_info` and tags (e.g., cp312-cp312).
- Host Python (3.13) cannot leak unless volumes mount host executables/cache.

**Verification Commands** (Run in container):
```bash
python3 --version  # Must show Python 3.12.x
python3 -m pip debug --verbose  # Shows compatible tags: cp312 first
python3 -c "import sys, struct, platform; print(sys.version); print(platform.python_implementation())"
```

**Enforcement Best Practices**:
- Use `--no-cache-dir` in pip install to avoid any cached mismatches.
- Add to Dockerfiles:
```dockerfile
RUN pip install --no-cache-dir -r requirements.txt
```
- Clear build cache: `docker builder prune` or `docker compose build --no-cache`.
- No environment variables needed; isolation is automatic.

**Potential Leakage Fixes**:
- Avoid mounting host pip cache.
- Use multi-stage builds for clean separation.

## **2. Pip-Tools (pip-compile) Python Version Targeting**

pip-compile generates requirements based on constraints/resolver, not runtime.

**Flags for Targeting**:
- No direct --python-version in pip-compile; use constraints file.
- Best: Run pip-compile **inside a Python 3.12 container** for accuracy.
- Add to requirements.in:
```
# Requires-Python: >=3.12,<3.13
```
- Or use --pip-args:
```bash
pip-compile --pip-args '--python-version 3.12' requirements.in
```

**Recommended Workflow**:
```bash
# In Docker (guaranteed 3.12)
docker run --rm -v $(pwd):/app -w /app python:3.12-slim pip install pip-tools
docker run --rm -v $(pwd):/app -w /app python:3.12-slim pip-compile requirements.in
```

**Validation**:
Generated requirements.txt will prefer packages with Python 3.12 markers.

## **3. Pip Wheel Version Selection Logic**

Pip prioritizes:
1. Most specific compatible tag (cp312-cp312 first).
2. Then abi3, then py3-none-any.
3. Falls back to sdist if no wheel.

**Why No cp313 Wheels in 3.12**:
- cp313 tags are incompatible (PEP 425); pip rejects them.
- If log shows cp313 download, it's impossible unless --python-version override.

**Force Strict Selection**:
```dockerfile
RUN pip install --no-cache-dir --python-version 3.12 --abi cp312 --implementation cp -r requirements.txt
```

**Cache Management**:
- Use BuildKit cache mounts per version:
```dockerfile
RUN --mount=type=cache,id=pip-cache,target=/root/.cache/pip pip install ...
```

## **4. Virtual Environment Isolation**

Venv binds to the creating Python.

**Creation**:
```bash
python3.12 -m venv /venv
source /venv/bin/activate
pip install ...
```

In container: Uses container Python automatically.

**Verification**:
```bash
which python  # Points to venv
python --version  # 3.12.x
```

## **5. Docker Build Python Version Management**

**Templates** (Add verification):
```dockerfile
FROM python:3.12-slim

# Verify at build
RUN python --version | grep "3.12" || (echo "Wrong Python version!" && exit 1)

# Install with strict flags
RUN pip install --no-cache-dir --python-version 3.12 -r requirements.txt
```

**Multi-Stage Example**:
```dockerfile
FROM python:3.12-slim as builder
RUN pip wheel --no-cache-dir --wheel-dir=/wheels -r requirements.txt

FROM python:3.12-slim
COPY --from=builder /wheels /wheels
RUN pip install --no-cache-dir /wheels/*
```

**Stability**: python:3.12-slim pins to 3.12.x (Debian-based, updates minor only).

## **Validation & Testing Framework**

**Diagnostic Script** (Add to repo):
```bash
#!/bin/bash
echo "Python Version:"
python --version
echo "Pip Tags:"
pip debug --verbose | grep -A 10 "Compatible tags"
echo "Test Install Dry-Run:"
pip install --dry-run --no-cache-dir --python-version 3.12 some-package
```

**Automated Check in Dockerfile**:
```dockerfile
RUN python -c "import sys; assert sys.version_info[:2] == (3, 12), 'Wrong Python!'"
```

## **Migration Strategy**

1. Update all Dockerfiles with --no-cache-dir and verification RUN.
2. Regenerate requirements in 3.12 container.
3. Rebuild with --no-cache.
4. Test runtime: No 3.13 imports should load.
5. Rollback: Tag old images.

This ensures 100% Python 3.12 compliance. The "3.13 wheels" are likely compatible universals or cache illusions – strict flags eliminate risks.

Cline, implement the verification script first to confirm tags. Ready for Dockerfile patches? 🚀