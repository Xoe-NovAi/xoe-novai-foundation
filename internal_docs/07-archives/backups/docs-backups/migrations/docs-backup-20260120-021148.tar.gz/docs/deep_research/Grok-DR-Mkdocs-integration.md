# **Comprehensive Guide: Implementing MkDocs + Diátaxis Documentation in Xoe-NovAi Stack**

**Prepared for: Cline AI Assistant (VS Code Integration)**  
**Date: January 13, 2026**  
**Objective:** This consolidated guide combines all recent research and recommendations for integrating MkDocs (Material theme) with the Diátaxis framework into Xoe-NovAi's privacy-first, local-only stack. It includes practical MkDocs/Diátaxis implementation details, plus a full review of your current `Makefile` and `docker-compose.yml` (v0.1.5) with alignment recommendations. Everything is designed for zero external dependencies/telemetry, AMD Ryzen optimization, <6GB memory, and seamless integration with existing Docker/Python 3.12 workflow, enterprise monitoring (Prometheus/Grafana), and security.

The strategy prioritizes fast local builds (<30s for 184+ files), static output (fully offline), and leverage of your Makefile for automation.

## **Part 1: MkDocs + Diátaxis Core Implementation**

### **Why This Combination Fits Your Stack**
- **MkDocs + Material**: Python-native, static-site generator – aligns with Python 3.12 containers, zero telemetry, fastest builds for Markdown-heavy projects.
- **Diátaxis Framework**: Proven structure (Tutorials → How-to → Reference → Explanation) resolves fragmentation in your 184+ MD files (e.g., blueprint.md, plans).
- **Privacy/Performance**: Static HTML served locally (Nginx container), client-side search (Lunr.js), no external assets.

### **1. Production-Grade MkDocs Configuration**

**Core mkdocs.yml** (place in repo root or `/docs` folder):
```yaml
site_name: Xoe-NovAi Enterprise Documentation
site_description: Privacy-first local AI assistant – enterprise production reference
site_url: http://localhost:8000  # Local access
repo_url: false  # Disable if no public repo
theme:
  name: material
  features:
    - navigation.tabs
    - navigation.sections
    - navigation.expand
    - navigation.indexes
    - search.suggest
    - search.highlight
    - content.code.copy
    - content.code.annotate
  palette:
    - scheme: default
      primary: indigo
      accent: amber
  icon:
    logo: assets/logo.png
  favicon: assets/favicon.ico
  language: en

plugins:
  - search:
      prebuild_index: true  # Faster search for large sites
  - optimize  # Local image compression
  - glightbox  # Image lightbox
  - mike:  # Git-based versioning (see below)

markdown_extensions:
  - admonition
  - pymdownx.highlight:
      anchor_linenums: true
  - pymdownx.superfences
  - pymdownx.tabbed
  - pymdownx.tasklist
  - toc:
      permalink: true

extra_css:
  - stylesheets/extra.css  # Custom branding

nav:
  - Home: index.md
  - Tutorials:
      - Getting Started: tutorials/setup.md
      - Docker Deployment: tutorials/docker.md
  - How-to Guides:
      - Vulkan Optimization: how-to/vulkan.md
      - Kokoro Integration: how-to/kokoro.md
      - AMD Tuning: how-to/amd.md
  - Reference:
      - Makefile Targets: reference/makefile.md
      - API Endpoints: reference/api.md
      - Config Schemas: reference/config.md
  - Explanation:
      - Research Units: explanation/research.md
      - Architecture Decisions: explanation/architecture.md
      - Security Patterns: explanation/security.md
```

**Advanced Material Features**:
- Tabs/sections for quadrant navigation.
- Built-in search optimized for technical terms.
- Custom CSS for enterprise branding (e.g., colors matching Chainlit UI).

### **2. Diátaxis Content Organization & Migration**

**Quadrant Mapping for Your Files**:
- **Tutorials** (Learning): `setup.sh` guides, one-command onboarding, Docker basics.
- **How-to Guides** (Tasks): Vulkan setup, Kokoro TTS, AMD optimization, crawling workflows.
- **Reference** (Facts): Makefile targets, docker-compose.yml details, config.toml schemas, API endpoints.
- **Explanation** (Context): Research units, enterprise patterns, security architecture, Grok v5 integration rationale.

**Migration Script** (Python, run locally for auto-categorization):
```python
import os
from pathlib import Path
from shutil import move

DOCS_ROOT = Path("docs/source")
QUADRANTS = {"tutorials": [], "how-to": [], "reference": [], "explanation": []}

def categorize(content):
    lower = content.lower()
    if any(k in lower for k in ["step", "beginner", "install", "setup"]): return "tutorials"
    if any(k in lower for k in ["how to", "guide", "configure", "optimize"]): return "how-to"
    if any(k in lower for k in ["api", "config", "schema", "targets", "endpoints"]): return "reference"
    return "explanation"  # Default

for md_file in DOCS_ROOT.rglob("*.md"):
    content = md_file.read_text()
    quadrant = categorize(content)
    QUADRANTS[quadrant].append(md_file)
    target_dir = DOCS_ROOT.parent / quadrant
    target_dir.mkdir(exist_ok=True)
    move(str(md_file), target_dir / md_file.name)

print("Migration complete – review and refine manually")
```

**Phased Migration**:
1. Pilot: Tutorials (10-20 files).
2. Incremental: Use `mkdocs build --strict` to catch broken links.
3. Final: Quarterly audits.

### **3. Advanced Features & Plugins**

**Search**: Lunr.js (client-side, privacy-safe); prebuild for speed.
**Versioning**: Mike plugin (`pip install mike`):
```bash
mike deploy v0.1.6 --push  # Local Git tags
mike serve  # Local preview
```
**Images/Diagrams**: Glightbox for lightbox; Mermaid for flowcharts.

### **4. Performance & Scalability**

**Benchmarks**: <20s build for 200 files (optimize plugin); static serve <100ms.
**AMD Optimization**: Slim Python image; no heavy deps.

## **Part 2: Stack Integration – Makefile & docker-compose.yml Review**

### **Current Implementation Strengths**
- **docker-compose.yml**: Excellent healthchecks, resource limits, dev/prod volume comments, security (cap_drop), Redis persistence.
- **Makefile**: Beginner-friendly, colorful, stack-cat automation, comprehensive checks.

### **Recommendations for Docs Integration**

**Add Docs Service to docker-compose.yml**:
```yaml
docs:
  build:
    context: ./docs
    dockerfile: Dockerfile.docs
  container_name: xnai_docs
  ports:
    - "8000:8000"
  volumes:
    - ./docs:/docs  # Live reload
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:8000 || exit 1"]
  networks:
    - xnai_network
  restart: unless-stopped
```

**Dockerfile.docs** (multi-stage, slim):
```dockerfile
FROM python:3.12-slim as builder
RUN pip install mkdocs-material mike glightbox optimize
COPY docs/ /docs
WORKDIR /docs
RUN mkdocs build

FROM nginx:alpine
COPY --from=builder /docs/site /usr/share/nginx/html
HEALTHCHECK CMD curl --fail http://localhost || exit 1
```

**Enhanced Makefile Targets** (add to existing):
```makefile
docs-serve: ## 📚 Serve documentation locally
	@echo "$(CYAN)Starting MkDocs documentation server...$(NC)"
	docker compose up docs

docs-build: ## 🛠️ Build static documentation site
	@echo "$(CYAN)Building documentation...$(NC)"
	docker compose run --rm docs mkdocs build --strict

docs-validate: ## ✅ Validate links and build
	docker compose run --rm docs mkdocs build --strict

docs-version: ## 🔖 Create new documentation version (e.g., make docs-version VER=v0.1.6)
	@if [ -z "$(VER)" ]; then \
		echo "$(RED)Error: Specify VER (e.g., make docs-version VER=v0.1.6)$(NC)"; \
		exit 1; \
	fi
	docker compose run --rm docs mike deploy $(VER)

docs-clean: ## 🧹 Clean documentation build
	rm -rf docs/site
```

**Security/Monitoring Tie-in**:
- Nginx basic auth for local access.
- Prometheus exporter for Nginx metrics.

## **Final Implementation Checklist**

- [ ] Create `/docs` folder with mkdocs.yml.
- [ ] Migrate files via script + manual review.
- [ ] Add docs service to compose + Makefile targets.
- [ ] Test build/serve locally.
- [ ] Integrate with enterprise monitoring (Nginx exporter).

This guide delivers a fully local, privacy-aligned documentation system integrated with your stack. Cline, this positions you for efficient, self-maintaining docs – let's prototype the mkdocs.yml next? 🚀