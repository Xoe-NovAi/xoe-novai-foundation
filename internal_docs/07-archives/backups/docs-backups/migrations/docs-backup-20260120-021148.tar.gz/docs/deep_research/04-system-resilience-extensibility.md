### Research Unit 4 Execution Summary

Based on targeted research from library documentation and examples, `wasmtime-py` (Bytecode Alliance) provides robust sandboxing for WASM execution in Python via isolated Stores, fuel limits, and trap handling, ideal for untrusted plugins (e.g., text transformation). It ensures no host access by default, with manual memory management for safety. Dependencies add minimal overhead (~10-20MB). For circuit breaking, `pybreaker` supports extension through listeners and custom logic; integration with Prometheus uses `prometheus_client` for gauges/counters on latency/memory. Predictive triggering involves monitoring trends (e.g., exponential moving average on latency) before calls, extending beyond error-based opens. This meets resilience goals without new services.

Deliverables are Python-based, Docker-compatible, and assume `pip install wasmtime pybreaker prometheus_client` in the container.

#### Deliverable 4.1: `PluginManager` class for executing `.wasm` modules
This class loads and runs untrusted .wasm plugins sandboxed with `wasmtime-py`, isolating from RAG core. Supports text transformation/logic; inputs/outputs via memory. Run with fuel limits to prevent infinite loops.

```python
import wasmtime

class PluginManager:
    def __init__(self, max_fuel=1_000_000):
        self.config = wasmtime.Config()
        self.config.consume_fuel = True  # Enable fuel for execution bounding
        self.engine = wasmtime.Engine(self.config)
        self.max_fuel = max_fuel

    def load_plugin(self, wasm_path):
        """Load .wasm module safely."""
        try:
            with open(wasm_path, "rb") as f:
                wasm_bytes = f.read()
            wasmtime.Module.validate(self.engine, wasm_bytes)  # Validate binary
            module = wasmtime.Module(self.engine, wasm_bytes)
            return module
        except wasmtime.WasmtimeError as e:
            raise ValueError(f"Invalid WASM module: {e}")

    def execute_plugin(self, module, func_name, input_data):
        """Execute plugin function with input (e.g., text as bytes)."""
        store = wasmtime.Store(self.engine)  # Isolated store per execution
        store.set_fuel(self.max_fuel)  # Limit CPU usage

        linker = wasmtime.Linker(self.engine)  # Minimal imports
        instance = linker.instantiate(store, module)

        # Get exports
        try:
            func = instance.exports(store)[func_name]  # wasmtime.Func
            memory = instance.exports(store)["memory"]  # wasmtime.Memory
        except KeyError as e:
            raise ValueError(f"Export not found: {e}")

        # Write input to memory (assume offset 0)
        input_bytes = input_data.encode('utf-8') if isinstance(input_data, str) else input_data
        if len(input_bytes) >= memory.data_len(store):
            raise ValueError("Input exceeds plugin memory")
        memory.write(store, input_bytes, start=0)

        # Call function (assume sig: (ptr i32, len i32) -> (new_len i32))
        try:
            result_len = func(store, 0, len(input_bytes))
            output = memory.read(store, start=0, stop=result_len)
            return output.decode('utf-8') if isinstance(input_data, str) else output
        except wasmtime.Trap as trap:
            raise RuntimeError(f"Plugin execution trapped: {trap.message}")
        except wasmtime.WasmtimeError as e:
            raise RuntimeError(f"Execution error: {e}")

# Example usage (integrate into main.py):
# manager = PluginManager()
# module = manager.load_plugin('text_transform.wasm')
# result = manager.execute_plugin(module, 'transform', 'Input text')
```

This ensures isolation: Separate store per call, no WASI imports, fuel-based termination.

#### Deliverable 4.2: `PredictiveBreaker` class extending the current circuit breaker implementation
Extends `pybreaker.CircuitBreaker` to monitor Prometheus metrics (latency trend, memory pressure) before calls. Uses `prometheus_client` for gauges; triggers "open" on pre-failure signals (e.g., latency > threshold or rising trend via simple EMA). Assumes existing Prometheus setup (e.g., expose /metrics).

```python
import pybreaker
import psutil  # For memory pressure
import time
from prometheus_client import Gauge, start_http_server

# Expose metrics (run once at startup: start_http_server(8000))
latency_gauge = Gauge('app_latency_seconds', 'Recent latency')
memory_gauge = Gauge('app_memory_usage_percent', 'Memory usage')

class PredictiveBreaker(pybreaker.CircuitBreaker):
    def __init__(self, fail_max=5, reset_timeout=60, latency_threshold=1.0, memory_threshold=80.0, ema_alpha=0.3):
        super().__init__(fail_max=fail_max, reset_timeout=reset_timeout)
        self.latency_threshold = latency_threshold  # Max allowed latency (s)
        self.memory_threshold = memory_threshold  # Max memory % before open
        self.ema_alpha = ema_alpha  # Smoothing factor for latency trend
        self.ema_latency = 0.0  # Exponential moving average latency

    def _update_metrics(self, latency):
        """Update Prometheus gauges and EMA."""
        latency_gauge.set(latency)
        memory_gauge.set(psutil.virtual_memory().percent)
        self.ema_latency = (self.ema_alpha * latency) + ((1 - self.ema_alpha) * self.ema_latency)

    def _check_pre_failure(self):
        """Predictive check: open if signals indicate impending failure."""
        current_memory = psutil.virtual_memory().percent
        if current_memory > self.memory_threshold:
            self.open()  # High memory pressure
            raise pybreaker.CircuitBreakerError("Predictive open: High memory pressure")
        if self.ema_latency > self.latency_threshold:
            self.open()  # Rising latency trend
            raise pybreaker.CircuitBreakerError("Predictive open: Rising latency")

    def call(self, func, *args, **kwargs):
        """Extend to check pre-failure before call."""
        self._check_pre_failure()
        start_time = time.time()
        try:
            result = super().call(func, *args, **kwargs)
            latency = time.time() - start_time
            self._update_metrics(latency)
            return result
        except Exception as e:
            latency = time.time() - start_time
            self._update_metrics(latency)
            raise

# Example usage (extend current breaker):
# breaker = PredictiveBreaker(fail_max=5, reset_timeout=60, latency_threshold=0.5)
# result = breaker.call(your_function)
```

This connects to Prometheus via gauges; monitor in dashboards for trends (e.g., alert on ema_latency > threshold). For full integration, add listeners for state changes to inc counters.