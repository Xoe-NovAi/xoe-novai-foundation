Here is the **final, consolidated, and updated comprehensive guide** for your VS Code AI coding & documentation assistant (Cline).

This guide is based on:
- Deep analysis of your current stack files (Makefile, docker-compose.yml, main.py, freshness_monitor.py, indexer.py, migrate_content.py, research_validator.py, research_request_system.py, enterprise-enhancement roadmap)
- Previous research threads (Vulkan, Kokoro, FAISS, WASM, circuit breakers, Python 3.12 enforcement, MkDocs + Diátaxis)
- Official sources (FastAPI 0.115+, Docker BuildKit, pip-tools 7.x, MkDocs Material 9.x, Diátaxis framework 2025–2026 updates)
- Unofficial/practical sources (GitHub issues, Reddit r/selfhosted & r/MachineLearning, FastAPI Discord patterns 2025–2026, production RAG deployments)

**Current date context:** January 13, 2026  
**Target state:** Production-grade, privacy-first, local-only, AMD-optimized AI assistant with excellent developer documentation experience.

### 1. Strategic Overview & Guiding Principles (2026 Edition)

Your documentation system should follow these priorities (in order):

1. **Privacy & Locality** — zero external telemetry, no SaaS, everything runs in containers or locally
2. **Static-first + Self-hosted** — MkDocs (Material theme) as primary renderer, served via Nginx container
3. **Diátaxis structure** — mandatory organization principle
4. **Automation & Freshness** — Makefile targets + your freshness_monitor.py / indexer.py as core
5. **Enterprise observability** — tie docs health into Prometheus/Grafana
6. **Developer velocity** — fast local preview, incremental builds, VS Code integration

### 2. Recommended Final Architecture (January 2026)

```
docs/
├── mkdocs.yml                  ← single source of truth
├── Dockerfile.docs             ← multi-stage, slim
├── site/                       ← built static output (gitignored)
├── 01-getting-started/         ← Diátaxis Tutorials
├── 02-development/             ← How-to Guides
├── 03-architecture/            ← Reference
├── 04-operations/              ← How-to + Reference mix
├── 05-governance/              ← Explanation + Policies
├── 06-meta/                    ← This documentation system
├── scripts/
│   ├── freshness_monitor.py    ← your current monitor (enhanced)
│   ├── indexer.py              ← your indexer (keep + improve)
│   ├── migrate_content.py      ← migration helper (keep)
│   └── research_validator.py   ← keep for Grok research coverage
└── requirements-docs.txt       ← mkdocs + plugins
```

### 3. Production mkdocs.yml (Recommended Final Version)

```yaml
site_name: Xoe-NovAi Enterprise Documentation
site_description: Privacy-first local AI assistant – production reference & research archive
site_url: http://localhost:8000
use_directory_urls: true

theme:
  name: material
  features:
    - navigation.tabs
    - navigation.sections
    - navigation.expand
    - navigation.indexes
    - search.suggest
    - search.highlight
    - content.code.copy
    - content.code.annotate
    - toc.integrate
  palette:
    primary: indigo
    accent: amber
  language: en

plugins:
  - search:
      separator: '[\s\-,:!=\(\)"`/\]\[\\]+'  # better tokenization for code
      prebuild_index: true
  - glightbox
  - optimize:
      images: true
      minify_html: true
  - mike:
      version_selector: true

markdown_extensions:
  - admonition
  - pymdownx.highlight:
      anchor_linenums: true
  - pymdownx.superfences
  - pymdownx.tabbed
  - pymdownx.tasklist
  - toc:
      permalink: true

nav:
  - Home: index.md
  - 01 Getting Started:
      - Quick Start: 01-getting-started/quick-start.md
      - Docker Deployment: 01-getting-started/docker.md
  - 02 Development:
      - Setup & Tooling: 02-development/setup.md
      - Async Patterns: 02-development/async-fastapi.md
      - RAG Caching: 02-development/rag-caching.md
  - 03 Architecture:
      - System Blueprint: 03-architecture/blueprint.md
      - Research Integration: 03-architecture/research-v5.md
  - 04 Operations:
      - Monitoring & Alerts: 04-operations/monitoring.md
      - Troubleshooting: 04-operations/troubleshooting.md
  - 05 Governance:
      - Security Model: 05-governance/security.md
      - Best Practices: 05-governance/best-practices.md
  - 06 Meta:
      - About this Documentation: 06-meta/about.md
      - Freshness & Index: 06-meta/freshness.md

extra:
  generator: false  # remove MkDocs badge
```

### 4. Dockerfile.docs (Recommended Slim & Secure)

```dockerfile
# Stage 1: Build
FROM python:3.12-slim AS builder

RUN pip install --no-cache-dir \
    mkdocs-material \
    mike \
    mkdocs-glightbox \
    mkdocs-optimize

WORKDIR /docs
COPY docs/ /docs/

# Strict build + validation
RUN mkdocs build --strict

# Stage 2: Serve (minimal)
FROM nginx:alpine-slim

COPY --from=builder /docs/site /usr/share/nginx/html

# Security hardening
RUN chmod -R 555 /usr/share/nginx/html && \
    chown -R nginx:nginx /usr/share/nginx/html

HEALTHCHECK --interval=30s --timeout=3s \
  CMD wget --quiet --tries=1 --spider http://localhost:80 || exit 1

EXPOSE 80
```

### 5. Makefile Integration (Add these targets)

```makefile
# ──────────────────────────────────────────────────────────────────────────────
# Documentation Targets
# ──────────────────────────────────────────────────────────────────────────────

docs-deps: ## Install documentation dependencies locally (for VS Code preview)
	$(PYTHON) -m pip install -r docs/requirements-docs.txt

docs-serve: ## Serve documentation locally with live reload
	@echo "$(CYAN)Starting MkDocs live preview...$(NC)"
	docker compose up -d docs

docs-build: ## Build static documentation site (production artifact)
	@echo "$(CYAN)Building static docs...$(NC)"
	docker compose run --rm docs mkdocs build --strict

docs-version: ## Create new versioned documentation snapshot
	@if [ -z "$(VER)" ]; then echo "$(RED)Error: make docs-version VER=v0.1.6$(NC)"; exit 1; fi
	docker compose run --rm docs mike deploy $(VER) --push

docs-freshness: ## Run documentation freshness & health check
	$(PYTHON) docs/scripts/freshness_monitor.py --check --report

docs-index: ## Rebuild documentation search index
	$(PYTHON) docs/scripts/indexer.py --rebuild

docs-migrate: ## Migrate legacy content to new numbered categories (dry-run first)
	$(PYTHON) docs/scripts/migrate_content.py --dry-run
	# Then run with --execute when ready

docs-validate-research: ## Validate Grok v5 research coverage
	$(PYTHON) docs/scripts/research_validator.py --validate
```

### 6. Recommended Next 4–6 Weeks Action Plan (Aligned with your roadmap)

**Week 1–2 (Documentation Cleanup & Foundation)**
- Run `docs-migrate --dry-run` → review → `--execute`
- Fix 24 broken links (use freshness_monitor report)
- Bulk-add frontmatter to legacy files (script enhancement possible)
- Deploy MkDocs container & verify live preview

**Week 3–4 (Core Enhancement Documentation)**
- Write & integrate:
  - Async FastAPI migration guide (patterns from previous response)
  - 3-level RAG caching architecture (code + explanation)
  - Voice streaming + VAD implementation details

**Week 5–6 (Enterprise & Observability Docs)**
- OpenTelemetry + correlation IDs guide
- Multi-worker session affinity (Nginx sticky + Redis)
- Security hardening patterns (Pydantic validators + rate limiting)

**Week 7–8 (Polish & Automation)**
- Final freshness/indexer/validator runs
- Create dashboard panel in Grafana: Documentation Health Score
- Document the documentation system itself (06-meta/)

### 7. Quick VS Code Workflow Recommendations for Cline

1. **Recommended Extensions**
   - Markdown All in One
   - Material for MkDocs Preview
   - Docker
   - Python (Pylance)
   - GitLens
   - Error Lens

2. **Tasks.json snippet** (run docs locally)
```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Docs: Serve",
      "type": "shell",
      "command": "make docs-serve",
      "group": "build",
      "problemMatcher": []
    },
    {
      "label": "Docs: Freshness Check",
      "type": "shell",
      "command": "make docs-freshness",
      "group": "test"
    }
  ]
}
```

This guide represents the **current state-of-the-art recommendation** as of January 13, 2026 for your specific privacy-first, local RAG/voice/AI stack.

You now have everything needed to move from fragmented Markdown → professional, maintainable, searchable enterprise documentation system.

**Next immediate action suggestion:** Run the migration dry-run and create the docs service in docker-compose. Want me to generate the complete docker-compose patch or the frontmatter bulk-adder script? 🚀