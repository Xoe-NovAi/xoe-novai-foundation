# 🚀 Week 1: Foundation Acceleration Implementation Plan
## Revolutionary Performance Gains & Core Functionality

**Week**: January 15-21, 2026
**Priority**: 🔴 CRITICAL - Blocks All Subsequent Improvements
**Status**: � IMPLEMENTATION IN PROGRESS - Foundation Complete
**Expected Impact**: 25-55% LLM Performance Boost + Production Voice Pipeline

---

## 📋 **Executive Summary**

Week 1 focuses on **immediate high-impact implementations** that provide revolutionary performance gains while establishing core operational functionality. These changes transform the stack from functional prototype to production-ready AI platform.

**Key Deliverables**:
- ✅ **25-55% LLM Performance** via Vulkan iGPU acceleration
- ✅ **Sub-300ms Voice Pipeline** with distil-large-v3-turbo
- ✅ **Enterprise Dependencies** resolution (missing langchain-community, faiss-cpu)
- ✅ **Academic MkDocs RAG** foundation with Diátaxis structure

---

## 🎯 **Day 1-2: Vulkan iGPU Acceleration (25-55% Performance Boost)**

### **Priority 1: Vulkan Environment Setup**
**Why Critical**: Enables 25-55% LLM performance gains on Ryzen 5700U Vega 8

#### **Actions**:
1. **Install Vulkan ecosystem** on host system
2. **Update Dockerfile.api** with Vulkan build support
3. **Add .env configuration** for safe Vulkan enablement
4. **Implement safe loading logic** with comprehensive fallbacks

#### **Implementation Details**:
```bash
# Host setup
sudo apt install -y vulkan-tools libvulkan-dev mesa-vulkan-drivers

# Verify Vulkan
vulkaninfo --summary
```

#### **Success Criteria**:
- ✅ Vulkan drivers properly installed and detected
- ✅ Dockerfile.api updated with Vulkan build arguments
- ✅ .env configuration added for Vulkan control

---

### **Priority 2: Vulkan Code Integration**
**Why Critical**: Safe implementation with emergency fallbacks

#### **Actions**:
1. **Update dependencies.py** with Vulkan loading logic
2. **Add environment variable controls** for layer management
3. **Implement comprehensive error handling** with CPU fallback
4. **Create performance validation benchmarks**

#### **Implementation Details**:
```python
# dependencies.py - Vulkan integration
def get_llm():
    vulkan_enabled = os.getenv("LLAMA_VULKAN_ENABLED", "false").lower() == "true"
    requested_layers = int(os.getenv("LLAMA_VULKAN_LAYERS", "0"))

    try:
        if vulkan_enabled:
            llm = Llama(
                model_path=CONFIG["models"]["llm_path"],
                n_gpu_layers=requested_layers,  # 28-35 for Ryzen 5700U
                n_threads=6,
                f16_kv=True,
                use_mlock=True,
                n_ctx=min(4096, CONFIG["models"]["llm_context_window"])
            )
            print(f"[Vulkan] Using {requested_layers} layers")
        else:
            # CPU fallback
            llm = Llama(...)
    except RuntimeError as e:
        if "Vulkan" in str(e) and vulkan_enabled:
            print(f"[Vulkan fallback] {e} → falling back to CPU")
            return get_llm_cpu_fallback()
        raise

    return llm
```

#### **Success Criteria**:
- ✅ Safe Vulkan loading with automatic CPU fallback
- ✅ Performance benchmarks showing 25-55% improvement
- ✅ No crashes or instability during testing

---

## 🎯 **Day 3-4: Voice Pipeline Turbo (Sub-300ms STT/TTS)**

### **Priority 3: Distil-Large-V3-Turbo STT Integration**
**Why Critical**: 180-320ms end-to-end STT latency vs current 400-800ms

#### **Actions**:
1. **Switch STT model** to distil-large-v3-turbo
2. **Add CTranslate2 integration** for acceleration
3. **Update voice configuration** in config.toml
4. **Optimize VAD integration** (Silero ONNX)

#### **Implementation Details**:
```python
# chainlit_app_voice.py - Turbo STT integration
from faster_whisper import WhisperModel

async def transcribe_audio(audio_bytes: bytes) -> str:
    model = WhisperModel(
        "Systran/faster-whisper-distil-large-v3-turbo",
        device="cpu",
        compute_type="int8",  # or "float16" if memory allows
        cpu_threads=6,
        num_workers=3
    )

    segments, _ = model.transcribe(audio_bytes, language="en")
    return " ".join(segment.text for segment in segments)
```

#### **Success Criteria**:
- ✅ STT latency <320ms end-to-end
- ✅ Wake-word detection near-instantaneous
- ✅ Accuracy maintained or improved

---

### **Priority 4: Piper ONNX TTS Optimization**
**Why Critical**: <100ms TTS generation vs current >150ms

#### **Actions**:
1. **Implement ONNX simplifier** for Piper models
2. **Add low-quality model optimization** for speed
3. **Stream audio chunks** for real-time experience
4. **Benchmark latency improvements**

#### **Implementation Details**:
```bash
# Optimize Piper model
pip install onnx onnxsim
onnxsim input.onnx optimized.onnx
```

#### **Success Criteria**:
- ✅ TTS latency <100ms
- ✅ Audio quality acceptable for real-time use
- ✅ Memory usage optimized

---

## 🎯 **Day 5-7: Enterprise Dependencies & MkDocs Foundation**

### **Priority 5: Critical Dependencies Resolution**
**Why Critical**: Missing langchain-community, faiss-cpu, anyio, pycircuitbreaker block functionality

#### **Actions**:
1. **Install uv** for modern dependency management
2. **Create complete pyproject.toml** with all required packages
3. **Update requirements files** with proper dependencies
4. **Migrate from pybreaker to pycircuitbreaker**

#### **Implementation Details**:
```bash
# Install uv
pip install uv

# Configure Tsinghua mirror
mkdir -p ~/.config/pip
cat > ~/.config/pip/pip.conf << EOF
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
trusted-host = pypi.tuna.tsinghua.edu.cn
EOF
```

```toml
# pyproject.toml
[project]
name = "xoe-novai"
version = "0.1.5"

[[tool.uv.index]]
url = "https://pypi.tuna.tsinghua.edu.cn/simple"

[project.dependencies]
# Core RAG stack (CRITICAL - MISSING)
langchain = ">=0.1.0"
langchain-community = ">=0.0.20"
faiss-cpu = ">=1.8.0"


# Voice stack
faster-whisper = ">=1.0.0"
piper-tts = ">=1.3.0"

# Async & Concurrency (2026 standards)
anyio = ">=4.0.0"
pycircuitbreaker = ">=1.0.0"

# Observability
opentelemetry-sdk = ">=1.20.0"
opentelemetry-exporter-prometheus = ">=1.0.0"
```

#### **Success Criteria**:
- ✅ All critical dependencies installed
- ✅ uv migration completed
- ✅ Tsinghua mirror configured for fast installs

---

### **Priority 6: MkDocs Diátaxis Structure & RAG Foundation**
**Why Critical**: Academic-grade AI assistance foundation

#### **Actions**:
1. **Enforce Diátaxis structure** across documentation
2. **Add frontmatter standards** to key documents
3. **Implement Griffe extensions** for API metadata
4. **Update ingestion pipeline** for versioned content

#### **Implementation Details**:
```yaml
# docs/index.md frontmatter example
---
title: Xoe-NovAi Enterprise Documentation
category: reference
tags: [documentation, overview, enterprise]
version: 0.1.5+
authors: [Arcana-NovAi]
status: stable
---
```

#### **Success Criteria**:
- ✅ Diátaxis structure enforced (tutorials, how-to, reference, explanation)
- ✅ Frontmatter standards applied to all documentation
- ✅ Griffe extensions configured for API documentation

---

## 📊 **Expected Week 1 Outcomes**

### **Performance Improvements**
- **LLM Speed**: +25-55% via Vulkan iGPU acceleration
- **STT Latency**: 180-320ms (vs current 400-800ms)
- **TTS Latency**: <100ms (vs current >150ms)
- **Voice Experience**: Near-instantaneous wake-word detection

### **Functional Improvements**
- **Dependencies**: All critical packages resolved
- **Circuit Breakers**: Modern pycircuitbreaker implementation
- **Documentation**: Academic-grade RAG foundation
- **Observability**: OpenTelemetry GenAI instrumentation

### **System Readiness**
- **Core Functionality**: All basic operations working
- **Performance**: Enterprise-grade speed and latency
- **Stability**: Comprehensive error handling and fallbacks
- **Monitoring**: Full observability stack active

---

## 🔧 **Implementation Dependencies**

### **Code Changes Required**
1. **Dockerfile.api**: Vulkan build arguments and dependencies
2. **dependencies.py**: Safe Vulkan loading with fallbacks
3. **chainlit_app_voice.py**: distil-large-v3-turbo integration
4. **requirements-api.in**: Updated with missing dependencies
5. **mkdocs.yml**: Diátaxis structure and Griffe extensions
6. **pyproject.toml**: Complete dependency specification

### **Configuration Updates**
1. **.env**: Vulkan enablement and layer controls
2. **config.toml**: Voice model configurations
3. **mkdocs.yml**: API documentation extensions

### **Testing Requirements**
1. **Performance Benchmarks**: Before/after Vulkan comparisons
2. **Voice Latency Tests**: STT/TTS timing validation
3. **Dependency Verification**: All packages import successfully
4. **Documentation Build**: MkDocs generates without errors

---

## 🎯 **Success Validation Criteria**

### **Performance Targets Met**
- ✅ Vulkan: ≥ +25% token generation speed
- ✅ STT: <320ms end-to-end latency
- ✅ TTS: <100ms generation time
- ✅ Dependencies: All critical packages resolved

### **Functional Completeness**
- ✅ Voice Pipeline: Sub-300ms end-to-end operation
- ✅ Documentation: Diátaxis structure enforced
- ✅ Circuit Breakers: Modern async implementation
- ✅ Observability: OpenTelemetry active

### **System Stability**
- ✅ No crashes during testing
- ✅ Memory usage within bounds
- ✅ Error handling comprehensive
- ✅ Fallback mechanisms working

---

## 📈 **Week 1 Completion Status**

**Target Completion Date**: January 21, 2026

### **Daily Checkpoints**
- **Day 1-2**: Vulkan iGPU acceleration operational
- **Day 3-4**: Voice pipeline turbo implemented
- **Day 5-7**: Dependencies resolved, MkDocs foundation complete

### **Week 1 Success**: Revolutionary transformation from prototype to production AI platform
- 🚀 **Performance**: 25-55% LLM speed improvement
- 🚀 **Voice**: Sub-300ms real-time interaction
- 🚀 **Reliability**: Enterprise-grade dependencies and error handling
- 🚀 **Documentation**: Academic-grade AI assistance foundation

**Ready for Week 2 advanced capabilities implementation.**
