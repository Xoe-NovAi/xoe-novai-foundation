# 🚀 Xoe-NovAi Quick Start Guide
## Get Your AI Assistant Running in 5 Minutes

**Version:** v0.1.5
**Status:** ✅ READY - Beginner-friendly with AMD optimization
**Last Updated:** January 10, 2026

---

## ⚡ The Absolute Fastest Way (Recommended)

### One Command Does Everything
```bash
# Clone and run this - that's literally it!
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi
./setup.sh
```

**What happens automatically:**
1. ✅ **Checks your system** (AMD CPU detection, memory, disk space)
2. ✅ **Downloads AI components** (shows progress, ~10-20 minutes)
3. ✅ **Builds everything** (wheels, containers, optimizations)
4. ✅ **Starts your AI** at http://localhost:8001
5. ✅ **Gives you next steps** and usage instructions

**Why this works:**
- 🔥 **AMD Ryzen automatic optimization** (detects and tunes)
- 📊 **Real-time progress** (you see exactly what's happening)
- 🛡️ **Error handling** (tells you exactly what to fix if something fails)
- 📱 **Mobile friendly** (works on any modern computer)

---

## 🎯 What You'll Get

### Your Personal AI Assistant
- **💬 Chat with Documents** - Upload PDFs and ask questions
- **🎤 Voice Conversations** - Talk naturally (speech recognition + synthesis)
- **🔒 Complete Privacy** - Everything stays on your computer
- **🚀 Offline Operation** - No internet required after setup
- **📚 Document Learning** - Remembers everything you upload

### Technical Architecture
- **🐳 Docker Containers** - Isolated, secure, reproducible
- **🐍 Python 3.12** - Optimized for AI workloads
- **🔥 AMD CPU Optimization** - Automatic performance tuning
- **💾 Local Storage** - Documents and conversations saved locally

---

## 📋 System Requirements (Quick Check)

### Minimum Requirements
- **CPU:** 4+ cores (AMD Ryzen recommended for best performance)
- **RAM:** 16GB (32GB+ for voice features)
- **Storage:** 50GB free space
- **OS:** Ubuntu 20.04+, Debian 11+, or compatible Linux

### Recommended for Best Experience
- **CPU:** 8+ core AMD Ryzen
- **RAM:** 32GB
- **Storage:** 100GB SSD
- **Internet:** Required for initial setup only

### Quick Self-Check
```bash
# Run these commands to check your system:
echo "CPU Cores: $(nproc)"
echo "Memory: $(free -h | grep '^Mem:' | awk '{print $2}')"
echo "Free Disk: $(df -h . | tail -1 | awk '{print $4}')"
echo "AMD CPU: $(grep -q "AMD" /proc/cpuinfo && echo "Yes - optimizations available!" || echo "No - still works great")"
```

---

## 🚀 Step-by-Step Manual Setup (Alternative)

If you prefer to do things manually or need more control:

### Step 1: Install Prerequisites
```bash
# Update system
sudo apt update && sudo apt upgrade

# Install required tools
sudo apt install docker.io python3 python3-venv python3-pip git curl
```

### Step 2: Clone and Prepare
```bash
# Get the code
git clone https://github.com/Xoe-NovAi/Xoe-NovAi.git
cd Xoe-NovAi

# Create Python environment
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Build AI Components
```bash
# Build Python packages (AMD optimized automatically)
make wheel-build-docker

# Build Docker containers
make build
```

### Step 4: Start Your AI
```bash
# Start all services
make up

# Check it's working
make status
```

### Step 5: Access Your AI
Open http://localhost:8001 in your browser!

---

## 🎤 First 10 Minutes with Your AI

### 1. Basic Chat (2 minutes)
- Type: *"Hello! Can you help me understand what you can do?"*
- Try: *"What's the weather like?"* or *"Tell me a joke!"*

### 2. Voice Features (3 minutes)
- Click the **microphone icon** 🎤
- Allow microphone access when prompted
- Say: *"Introduce yourself"* or *"What can you help me with?"*
- Listen to the AI's voice response!

### 3. Document Intelligence (5 minutes)
- Click **"Upload Documents"** in the interface
- Upload a PDF or text document
- Ask specific questions like:
  - *"What are the main points in this document?"*
  - *"Summarize the key findings"*
  - *"Explain the conclusion in simple terms"*

---

## 📱 Daily Usage Commands

### Start and Stop
```bash
make start    # Start your AI assistant
make stop     # Stop when done
make restart  # Restart if running slow
```

### Check Status
```bash
make status   # Overview of all services
make doctor   # Diagnose any issues
```

### View Logs
```bash
make logs     # See recent activity
make logs CONTAINER=xnai_rag_api  # Specific service logs
```

### Update
```bash
make update   # Get latest version
```

---

## 🔧 Troubleshooting Quick Fixes

### "Permission denied" with Docker
```bash
sudo usermod -aG docker $USER
newgrp docker
# OR logout and login again
```

### Port 8000/8001 already in use
```bash
# Find what's using the port
sudo lsof -i :8000

# Kill the process
sudo kill -9 <PID>
```

### Voice not working
- Check browser microphone permissions
- Try Chrome browser (works best)
- Check system audio settings

### Slow performance
- AMD CPUs get automatic optimizations
- Ensure 16GB+ RAM available
- Close other applications

### Need more help?
- Run `make doctor` for automated diagnosis
- Check `BEGINNER_GUIDE.md` for detailed solutions
- Run `make help` for all available commands

---

## 🌟 What Makes Xoe-NovAi Special?

### Privacy First
- ✅ **Zero data sent online** - everything local
- ✅ **Your documents stay private** - never uploaded
- ✅ **Conversations remain secure** - no tracking

### Voice Native
- ✅ **Natural speech recognition** - understands you clearly
- ✅ **AI voice responses** - speaks back naturally
- ✅ **Context aware** - remembers conversation flow

### Smart Document Processing
- ✅ **Reads and understands** PDFs, docs, text files
- ✅ **Answers specific questions** about your content
- ✅ **Learns from multiple documents** simultaneously
- ✅ **Remembers everything** for future conversations

### Performance Optimized
- ✅ **AMD Ryzen optimizations** - automatic CPU tuning
- ✅ **Docker isolation** - consistent performance
- ✅ **Local processing** - no latency from internet
- ✅ **Resource efficient** - runs on consumer hardware

---

## 📚 Documentation Resources

### For Beginners
- **`../BEGINNER_GUIDE.md`** - Complete tutorial (2000+ words)
- **`../README.md`** - Quick reference and commands

### For Advanced Users
- **`docs/howto/wheelhouse-build.md`** - Custom wheel building
- **`docs/howto/enterprise-build.md`** - Manual build processes
- **`docs/reference/architecture.md`** - Technical architecture

### Getting Help
- **`make help`** - See all available commands
- **`make doctor`** - Automated system diagnosis
- **GitHub Issues** - Report bugs or request features

---

## 🎯 Success Checklist

After setup, verify everything works:
- [ ] Can access http://localhost:8001
- [ ] AI responds to text chat
- [ ] Voice features work (microphone + speakers)
- [ ] Can upload and ask questions about documents
- [ ] `make status` shows all services running
- [ ] Data persists between restarts

---

## 🚀 Advanced Features to Explore

Once comfortable with basics:
- **Custom document collections** - Build specialized knowledge bases
- **Voice conversation flows** - Multi-turn natural dialogues
- **Performance monitoring** - Track response times and usage
- **Backup and restore** - Preserve your AI's knowledge
- **Integration options** - Connect with other tools

---

**🎉 Congratulations! You now have your own private AI assistant running locally.**

**Need help? Start with `cat ../BEGINNER_GUIDE.md` - it covers everything in detail!**
