# Developer Portability Guide: Avoiding Partition Migration Issues

## Quick Start Checklist

Before deploying or migrating Xoe-NovAi, run this checklist:

```bash
# 1. Environment Check
python3 --version  # Should be 3.12+
docker --version   # Should be 28.4.0+
uname -a          # Check kernel version

# 2. Repository Integrity Check
ls -la wheelhouse/ scripts/build_tracking.py  # Should exist
./scripts/detect_environment.sh              # Run environment detection

# 3. Build Test
docker build -f Dockerfile.api .             # Should succeed
docker run --rm test-image python3 -c "import llama_cpp; print('OK')"

# 4. Configuration Validation
python3 -c "import tomllib; tomllib.load(open('config.toml', 'rb'))"
```

## Common Issues & Solutions

### Issue: "IndentationError: unexpected indent"

**Symptoms**: Container starts but immediately crashes with Python syntax error.

**Causes**:
- Host code has syntax errors when bind-mounted
- Mixed tabs/spaces in Python files
- File encoding issues

**Solutions**:
```bash
# Check for mixed indentation
python3 -m tabnanny app/XNAi_rag_app/*.py

# Check file encoding
file app/XNAi_rag_app/main.py

# Use built-in container code as fallback
# Comment out bind mount in docker-compose.yml:
# - ./app/XNAi_rag_app:/app/XNAi_rag_app
```

### Issue: "Embedding model not found"

**Symptoms**: Application starts but embeddings fail to load.

**Causes**:
- Incorrect model paths in config.toml
- Missing model files
- Permission issues on mounted directories

**Solutions**:
```bash
# Check model file exists
ls -la models/ embeddings/

# Verify config paths
grep -E "(llm_path|embedding_path)" config.toml

# Check container permissions
docker run --rm -v $(pwd)/models:/models:ro test-image ls -la /models
```

### Issue: "No such file or directory: '/app'"

**Symptoms**: Container fails to start with file system errors.

**Causes**:
- Docker build didn't create directory structure
- User permissions incorrect
- Base image issues

**Solutions**:
```dockerfile
# Add explicit directory creation to Dockerfile
WORKDIR /app
RUN mkdir -p /app && chown appuser:appuser /app

# Rebuild without cache
docker build --no-cache -f Dockerfile.api .
```

### Issue: "llama-cpp-python not installed"

**Symptoms**: Import errors for llama_cpp module.

**Causes**:
- Build failed to install llama-cpp-python
- Architecture-specific compilation issues
- Missing build dependencies

**Solutions**:
```bash
# Check build logs
docker build -f Dockerfile.api . 2>&1 | grep -i llama

# Manual installation test
docker run --rm test-image pip list | grep llama

# Force reinstall
docker build --no-cache --build-arg BUILDKIT_INLINE_CACHE=1 -f Dockerfile.api .
```

## Environment-Specific Fixes

### Ubuntu 24.04 / Python 3.13

```bash
# Python 3.13 compatibility
pip install --upgrade pip setuptools wheel

# GCC 14 compatibility
export CMAKE_ARGS="-DLLAMA_AVX2=ON -DLLAMA_FMA=ON"
```

### Docker Desktop vs Engine

```bash
# Docker Desktop (Mac/Windows)
export DOCKER_HOST="unix:///home/user/.docker/desktop/docker.sock"

# Docker Engine (Linux)
export DOCKER_HOST="unix:///var/run/docker.sock"
```

### Snap vs Native Docker

```bash
# Snap Docker issues
sudo snap connect docker:home
sudo snap restart docker

# Check Docker context
docker context ls
```

## Development Workflow

### Safe Development Setup

1. **Use bind mounts for development** (but with fallbacks):
```yaml
# docker-compose.yml
volumes:
  # Enable for live reload
  - ./app/XNAi_rag_app:/app/XNAi_rag_app
  # Comment out if host code has issues
  # - ./app/XNAi_rag_app:/app/XNAi_rag_app
```

2. **Test builds regularly**:
```bash
# Daily build test
make build && make test
```

3. **Use environment-specific configs**:
```bash
# Development
cp config.toml.dev config.toml

# Production
cp config.toml.prod config.toml
```

### Debugging Commands

```bash
# Check container logs
docker logs container_name --tail 50

# Inspect container filesystem
docker run --rm -it --entrypoint sh test-image

# Check environment variables
docker exec test-container env | grep -E "(REDIS|LLM|EMBEDDING)"

# Test API endpoints
curl http://localhost:8000/health
curl http://localhost:8000/docs
```

## Migration Procedures

### Repository Migration

```bash
# 1. Backup current setup
tar -czf backup.tar.gz .

# 2. Clone fresh repository
git clone <repository> new-xoe
cd new-xoe

# 3. Run environment detection
./scripts/detect_environment.sh

# 4. Copy data (not code)
cp -r ../old-xoe/data/* ./data/
cp -r ../old-xoe/models/* ./models/
cp -r ../old-xoe/embeddings/* ./embeddings/

# 5. Test build
make build

# 6. Test runtime
make up
curl http://localhost:8000/health
```

### System Migration

```bash
# 1. Check compatibility
python3 scripts/check_compatibility.py

# 2. Update dependencies
pip install --upgrade -r requirements-dev.txt

# 3. Test Docker
docker system info

# 4. Rebuild images
docker compose build --no-cache

# 5. Test deployment
docker compose up -d
docker compose logs -f
```

## Prevention Strategies

### Code Quality

1. **Linting**:
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/psf/black
    rev: 23.12.1
    hooks:
      - id: black
        language_version: python3
  - repo: https://github.com/pycqa/flake8
    rev: 7.0.0
    hooks:
      - id: flake8
```

2. **Type checking**:
```bash
mypy app/XNAi_rag_app/
```

3. **Testing**:
```bash
pytest tests/ -v
```

### Infrastructure

1. **Version pinning**:
```txt
# requirements.txt
llama-cpp-python==0.3.16
fastapi==0.116.2
uvicorn==0.40.0
```

2. **Docker best practices**:
```dockerfile
# Use specific base images
FROM python:3.12-slim@sha256:...

# Multi-stage builds
FROM builder AS runtime

# Health checks
HEALTHCHECK --interval=30s --timeout=15s --retries=3 \
    CMD python3 /app/healthcheck.py
```

3. **Configuration management**:
```bash
# Use environment variables
export LLM_MODEL_PATH="/models/${MODEL_NAME}.gguf"

# Template configs
envsubst < config.toml.template > config.toml
```

## Emergency Recovery

### If Everything Breaks

```bash
# 1. Stop all containers
docker compose down --volumes --remove-orphans

# 2. Clean Docker cache
docker system prune -f
docker volume prune -f

# 3. Rebuild from scratch
docker compose build --no-cache --pull

# 4. Start minimal services
docker compose up -d redis

# 5. Test RAG service manually
docker run --rm -it \
  -v $(pwd)/config.toml:/config.toml:ro \
  -v $(pwd)/models:/models:ro \
  -v $(pwd)/embeddings:/embeddings:ro \
  --network xoe-network \
  xoe-novai-rag \
  uvicorn XNAi_rag_app.main:app --host 0.0.0.0 --port 8000
```

### Data Recovery

```bash
# Recover from backups
tar -xzf backup.tar.gz -C /tmp/restore

# Restore FAISS index
cp /tmp/restore/data/faiss_index/* ./data/faiss_index/

# Restore models
cp /tmp/restore/models/* ./models/
```

## Contributing Guidelines

### Before Submitting PR

1. **Test on multiple environments**:
   - Ubuntu 22.04 + Python 3.12
   - Ubuntu 24.04 + Python 3.13
   - Docker Engine + Docker Desktop

2. **Run full test suite**:
```bash
make test-full
```

3. **Update documentation**:
```bash
# Update any changed paths
grep -r "old-path" docs/  # Should return nothing

# Test documentation builds
make docs
```

4. **Check portability**:
```bash
# Run portability checks
python3 scripts/check_portability.py
```

### PR Checklist

- [ ] All tests pass
- [ ] No hardcoded paths
- [ ] Docker builds successfully
- [ ] Works on multiple environments
- [ ] Documentation updated
- [ ] Migration guide included (if breaking changes)

## Conclusion

Portability issues are preventable with proper design and testing. Always:

1. **Assume environments differ**
2. **Test across multiple setups**
3. **Document requirements clearly**
4. **Implement graceful fallbacks**
5. **Use configuration, not code, for environment-specifics**

The partition migration taught us that robust systems require defensive design - assume nothing about the deployment environment.