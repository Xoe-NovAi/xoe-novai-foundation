# 🚀 Xoe-NovAi Complete Production Integration Roadmap
## Final Executable Implementation Plan

**Document Version**: 1.1 Production Integration
**Date**: January 15, 2026
**Status**: � IMPLEMENTATION IN PROGRESS - Week 1 Foundation Complete
**Purpose**: Comprehensive guide for bringing Xoe-NovAi stack to operational, production status

---

## 🔬 **Latest Research Integration - January 14, 2026**

### **🚀 Revolutionary Performance Gains Now Available**
- **Vulkan iGPU Acceleration**: 25-55% LLM performance boost with comprehensive safety measures
- **Voice Pipeline Turbo**: 180-320ms STT latency with distil-large-v3-turbo + CTranslate2
- **MkDocs RAG Enhancement**: Academic-grade AI assistance with Diátaxis + hybrid search
- **Enterprise Knowledge Ingestion**: 25-60% better RAG quality with semantic chunking

### **📊 Research-Validated Implementation**
- **Complete Vulkan Offload Guide**: Production-ready iGPU integration for Ryzen 5700U
- **Operational Stack Fulfillment**: 3-week execution roadmap with working code examples
- **Top 5 Critical Practices**: Prioritized cutting-edge implementations for 2026

### **🎯 Immediate Action Items**
1. **Week 1**: Vulkan iGPU + Voice Turbo + MkDocs Diátaxis + Knowledge Ingestion
2. **Week 2**: Hybrid BM25 + FAISS + Griffe Extensions + Versioned Ingestion
3. **Week 3**: Circuit Breakers + AnyIO + Enterprise Monitoring + Testing

**See [`research-integration-summary.md`](research-integration-summary.md) for complete details**

---

## 📊 Executive Summary

This document provides the complete roadmap for transforming the current Xoe-NovAi v0.1.5 stack into a production-ready, enterprise-grade AI system. Based on comprehensive analysis of the current codebase and remediation guides, this plan addresses **CRITICAL GAPS** that must be resolved for operational readiness.

### 🎯 Key Objectives
- **Security Hardening**: Fix critical vulnerabilities and permission issues
- **Dependency Modernization**: Migrate to 2026 best practices with uv and missing core dependencies
- **Performance Optimization**: Implement Ryzen-specific optimizations and iGPU acceleration
- **Resilience Enhancement**: Modernize circuit breakers and add graceful degradation
- **Observability**: Add comprehensive monitoring and OpenTelemetry integration
- **Production Hardening**: Complete testing, documentation, and enterprise features

---

## 📋 Current State Assessment

### ✅ **Strengths**
- Voice interface implemented with "Hey Nova" wake word
- Circuit breakers configured (RAG API, Redis, Voice Processing)
- Redis session management and FAISS integration
- Docker multi-stage builds with BuildKit
- Comprehensive Makefile with enterprise features
- Health checks and monitoring infrastructure

### 🔴 **Critical Issues Identified**

#### **MISSING CORE DEPENDENCIES (BLOCKING)**
From `requirements-api.in` analysis:
- **❌ langchain-community**: Required for FAISS integration - **MISSING**
- **❌ faiss-cpu**: Core RAG component - **MISSING** 
- **❌ anyio**: 2026 async standard - **MISSING**
- **❌ pycircuitbreaker**: Modern async circuit breaker - **MISSING**
- **❌ opentelemetry-sdk**: Observability framework - **MISSING**

#### **SECURITY VULNERABILITIES**
- **❌ REDIS_PASSWORD**: Sequential digits (1234567890123456) - **CRITICAL**
- **❌ APP_UID/GID**: Hardcoded 1001 - **MAY NOT MATCH HOST**
- **❌ Missing rootless Docker configuration**

#### **ARCHITECTURE GAPS**
- **❌ Circuit breaker using deprecated pybreaker** (should be pycircuitbreaker)
- **❌ No uv dependency management** (5-10x slower installs)
- **❌ Missing Ryzen optimizations** (iGPU, Vulkan)
- **❌ No property-based testing framework**

---

## 🎯 Implementation Roadmap

### **🚨 PHASE 1: CRITICAL FOUNDATION (Week 1) - MUST COMPLETE FIRST**

#### **Priority 1: Security & Permissions (Days 1-2)**

**1.1 Fix .env Security (5 minutes)**
```bash
# Generate secure REDIS_PASSWORD
REDIS_PASSWORD=$(openssl rand -base64 32)
echo "REDIS_PASSWORD=$REDIS_PASSWORD" >> .env

# Set dynamic APP_UID/GID
APP_UID=$(id -u)
APP_GID=$(id -g)
echo "APP_UID=$APP_UID" >> .env
echo "APP_GID=$APP_GID" >> .env

# Add missing model paths
echo "LLM_MODEL_PATH=/models/gemma-3-4b-it-UD-Q5_K_XL.gguf" >> .env
echo "EMBEDDING_MODEL_PATH=/embeddings/all-MiniLM-L12-v2.Q8_0.gguf" >> .env
```

**1.2 Fix Directory Permissions (3 minutes)**
```bash
# Fix ownership
sudo mkdir -p library knowledge data/faiss_index data/cache backups logs app/XNAi_rag_app/logs data/redis
sudo chown -R $(id -u):$(id -g) library knowledge data/faiss_index data/cache backups logs app/XNAi_rag_app/logs
sudo chown -R 999:999 data/redis
sudo chmod -R 755 library knowledge data/faiss_index data/cache backups
sudo chmod -R 777 app/XNAi_rag_app/logs
sudo chmod -R 755 data/redis
```

**1.3 Add Rootless Docker (2 minutes)**
```bash
# Add to .env
echo "DOCKER_BUILDKIT=1" >> .env
echo "DOCKER_ROOTLESS=1" >> .env
```

#### **Priority 2: Dependency Modernization (Days 3-5)**

**2.1 Install uv and Configure Mirror (5 minutes)**
```bash
# Install uv
pip install uv

# Configure mirror
mkdir -p ~/.config/pip
cat > ~/.config/pip/pip.conf << EOF
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
trusted-host = pypi.tuna.tsinghua.edu.cn
EOF
```

**2.2 Create Complete pyproject.toml (10 minutes)**
```bash
cat > pyproject.toml << EOF
[project]
name = "xoe-novai"
version = "0.1.5"

[[tool.uv.index]]
url = "https://pypi.tuna.tsinghua.edu.cn/simple"

[project.dependencies]
# Core RAG stack (CRITICAL - MISSING)
langchain = ">=0.1.0"
langchain-community = ">=0.0.20"  # CRITICAL: Missing
faiss-cpu = ">=1.8.0"             # CRITICAL: Missing
fastapi = ">=0.100.0"
uvicorn = ">=0.23.0"
llama-cpp-python = ">=0.2.0"

# Voice stack
faster-whisper = ">=1.0.0"
piper-tts = ">=1.3.0"

# Async & Concurrency (2026 standards)
anyio = ">=4.0.0"                 # CRITICAL: Missing
pycircuitbreaker = ">=1.0.0"      # CRITICAL: Missing

# Observability (2026 standards)
opentelemetry-sdk = ">=1.20.0"    # CRITICAL: Missing
opentelemetry-exporter-prometheus = ">=1.0.0"

# System & Utilities
redis = ">=5.0.0"
prometheus-client = ">=0.18.0"
psutil = ">=5.9.0"
pydantic = ">=2.0.0"
pydantic-settings = ">=2.0.0"
EOF
```

**2.3 Update requirements-api.in (2 minutes)**
```bash
# Replace entire requirements-api.in with:
cat > requirements-api.in << EOF
# API service requirements - uv managed
# Generated from pyproject.toml on $(date)
# CRITICAL: langchain-community and faiss-cpu added

langchain
langchain-community
faiss-cpu
fastapi
uvicorn
llama-cpp-python
faster-whisper
piper-tts
anyio
pycircuitbreaker
opentelemetry-sdk
opentelemetry-exporter-prometheus
redis
prometheus-client
psutil
pydantic
pydantic-settings
EOF
```

**2.4 Export Requirements (2 minutes)**
```bash
uv sync --frozen
uv export --hashes -o requirements-api.txt
```

#### **Priority 3: Build System & Circuit Breaker Modernization (Days 6-7)**

**3.1 Update Dockerfile.api (15 minutes)**
```dockerfile
# ============================================================================
# Xoe-NovAi Phase 1 v0.1.5 - FastAPI RAG Service Dockerfile (OPTIMIZED)
# ============================================================================

# Enable BuildKit syntax
# syntax=docker/dockerfile:1

# STAGE 1: BUILDER - uv with Ryzen optimization
FROM python:3.12-slim AS builder

LABEL maintainer="Xoe-NovAi Team"
LABEL stage="builder"
LABEL version="0.1.5"

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    DEBIAN_FRONTEND=noninteractive \
    SCARF_NO_ANALYTICS=true

# Install build dependencies
RUN mkdir -p /app && \
    apt-get update && \
    apt-get install -y --no-install-recommends \
        build-essential \
        cmake \
        git \
        libopenblas-dev \
        pkg-config \
        curl \
        ca-certificates \
        ninja-build && \
    rm -rf /var/lib/apt/lists/*

WORKDIR /app

# Copy uv configuration
COPY ~/.config/pip/pip.conf /root/.config/pip/pip.conf

# Install uv
RUN pip install uv

# Copy pyproject.toml
COPY pyproject.toml .

# Sync dependencies
RUN uv sync --frozen --no-install-project
RUN uv export --hashes -o requirements.txt

# Copy wheelhouse if present
COPY wheelhouse.tgz /app/ 2>/dev/null || true
RUN if [ -f wheelhouse.tgz ]; then tar -xzf wheelhouse.tgz; fi

# Install dependencies
ARG OFFLINE=false
RUN if [ "$OFFLINE" = "true" ] && [ -d wheelhouse ]; then \
        uv pip install --no-index --find-links=wheelhouse -r requirements.txt; \
    else \
        uv pip install -r requirements.txt; \
    fi

# STAGE 2: RUNTIME - Minimal production image
FROM python:3.12-slim

LABEL maintainer="Xoe-NovAi Team"
LABEL version="0.1.5"
LABEL description="Xoe-NovAi RAG API Service - Production Ready"

RUN apt-get update && \
    apt-get install -y --no-install-recommends \
        curl \
        libopenblas0 \
        libgomp1 \
        procps && \
    rm -rf /var/lib/apt/lists/* && \
    apt-get clean

# Create non-root user
RUN groupadd -g 1001 appuser && \
    useradd -m -u 1001 -g 1001 -s /bin/bash appuser

WORKDIR /app

# Copy dependencies from builder
COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages

# Aggressive cleanup
RUN find /usr/local/lib/python3.12/site-packages -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null || true && \
    find /usr/local/lib/python3.12/site-packages -type d -name 'tests' -exec rm -rf {} + 2>/dev/null || true && \
    find /usr/local/lib/python3.12/site-packages -type d -name 'examples' -exec rm -rf {} + 2>/dev/null || true

# Copy application code
COPY app/XNAi_rag_app /app/XNAi_rag_app

# Create directories and set permissions
RUN mkdir -p /app/XNAi_rag_app/logs \
    /app/XNAi_rag_app/faiss_index \
    /library \
    /knowledge/curator && \
    chown -R appuser:appuser /app /library /knowledge && \
    chmod -R 755 /app/XNAi_rag_app

# Ryzen optimization
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PYTHONPATH=/app \
    LLAMA_CPP_N_THREADS=6 \
    LLAMA_CPP_F16_KV=true \
    LLAMA_CPP_USE_MLOCK=true \
    LLAMA_CPP_USE_MMAP=true \
    OMP_NUM_THREADS=1 \
    OPENBLAS_NUM_THREADS=1 \
    OPENBLAS_CORETYPE=ZEN \
    MKL_DEBUG_CPU_TYPE=5

# Health check
HEALTHCHECK --interval=30s --timeout=15s --retries=10 --start-period=180s \
    CMD python3 /app/XNAi_rag_app/healthcheck.py || exit 1

# Switch to non-root user
USER appuser

# Production command
CMD ["uvicorn", "XNAi_rag_app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "1", "--log-level", "info"]
```

**3.2 Update main.py Circuit Breakers (10 minutes)**
```python
# Replace existing pybreaker imports with:
from pycircuitbreaker import circuit

# Replace existing circuit breaker initialization:
llm_circuit_breaker = circuit(failure_threshold=5, recovery_timeout=60)

# Replace existing circuit breaker usage:
@circuit(failure_threshold=5, recovery_timeout=60)
async def call_llm(query):
    # ... existing logic
```

**3.3 Add Multi-Level Voice Degradation (15 minutes)**
```python
# Add to chainlit_app_voice.py:
class VoiceDegradation:
    async def process_voice(self, audio: bytes):
        try:  # Level 1: Full STT + RAG + TTS
            transcript = await self.stt.transcribe(audio)
            context = await self.rag.retrieve(transcript)
            response = await self.llm.generate(transcript, context)
            audio_out = await self.tts.synthesize(response)
            return {"audio": audio_out, "level": 1}
        except:  # Level 2: Direct LLM (no RAG)
            response = await self.llm.ainvoke(transcript)
            return {"audio": await self.tts.synthesize(response), "level": 2}
        except:  # Level 3: Cache/Template
            cached = await self.cache.get(transcript)
            if cached: return {"audio": await self.tts.synthesize(cached), "level": 3}
        except:  # Level 4: Fallback TTS + Escalation
            return {"audio": await self.fallback_tts("Escalating..."), "level": 4, "escalated": True}
```

### **⚡ PHASE 2: PERFORMANCE & RESILIENCE (Week 2)**

#### **Priority 1: Ryzen Optimization (Days 1-3)**

**1.1 Enable iGPU Offloading (5 minutes)**
```python
# In dependencies.py, update llm_params:
llm_params = {
    'model_path': model_path,
    'n_gpu_layers': -1,  # Offload all layers to iGPU
    'f16_kv': True,
    'use_mlock': True,
    'use_mmap': True,
    # ... other params
}
```

**1.2 Optimize FAISS with HNSW (5 minutes)**
```python
# In dependencies.py, replace FAISS initialization:
import faiss
index = faiss.IndexHNSWFlat(384, 32)  # HNSW for CPU performance
```

**1.3 Add distil-large-v3-turbo for STT (5 minutes)**
```python
# In voice_interface.py:
from faster_whisper import WhisperModel
model = WhisperModel("distil-large-v3-turbo", device="cpu", compute_type="float16")
```

#### **Priority 2: Enhanced Observability (Days 4-5)**

**2.1 Add OpenTelemetry GenAI Instrumentation (10 minutes)**
```python
# In main.py:
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

# Add to lifespan:
FastAPIInstrumentor.instrument_app(app)

# Add spans to key functions:
@asynccontextmanager
async def lifespan(app: FastAPI):
    # ... existing code
    tracer = trace.get_tracer(__name__)
    
    with tracer.start_as_current_span("llm_initialization"):
        # LLM loading
    with tracer.start_as_current_span("vectorstore_loading"):
        # Vectorstore loading
```

**2.2 Enhanced Prometheus Metrics (10 minutes)**
```python
# Add voice-specific metrics:
from prometheus_client import Histogram, Counter

voice_latency = Histogram('voice_processing_seconds', 'Voice processing latency')
voice_errors = Counter('voice_errors_total', 'Voice processing errors', ['error_type'])
```

#### **Priority 3: Async Concurrency (Days 6-7)**

**3.1 Replace asyncio.gather with AnyIO (10 minutes)**
```python
# In chainlit_app_voice.py:
import anyio

async def voice_rag_pipeline(query: str):
    async with anyio.create_task_group() as tg:
        tg.start_soon(retrieve_context, query)  # FAISS
        tg.start_soon(generate_response)  # LLM
```

**3.2 Add Property-Based Testing (15 minutes)**
```python
# Create tests/test_voice_properties.py:
from hypothesis import given, strategies as st

@given(audio=st.binary(min_size=1000))
async def test_stt_latency(self, audio):
    start = time.time()
    await self.transcribe(audio)
    assert time.time() - start < 0.3  # <300ms latency
```

### **🛡️ PHASE 3: PRODUCTION HARDENING (Week 3)**

#### **Priority 1: Testing & Validation (Days 1-3)**

**1.1 Comprehensive Integration Tests (30 minutes)**
```python
# Create tests/test_integration.py:
class TestProductionReadiness:
    async def test_full_voice_pipeline(self):
        # Test end-to-end voice processing
        # Verify latency <300ms
        # Verify error handling
        # Verify fallback mechanisms
```

**1.2 Load Testing for Circuit Breakers (20 minutes)**
```python
# Enhance tests/circuit_breaker_load_test.py:
async def test_circuit_breaker_resilience():
    # Simulate high load
    # Verify circuit breaker behavior
    # Test recovery time
```

#### **Priority 2: Documentation & Compliance (Days 4-5)**

**2.1 Complete MkDocs Diátaxis Structure (30 minutes)**
```bash
# Ensure all quadrants present:
mkdir -p docs/tutorials docs/how-to docs/reference docs/explanation

# Add missing documentation files
```

**2.2 Add Security Compliance Documentation (20 minutes)**
```markdown
# Create docs/compliance/security.md:
## Security Standards
- Zero-telemetry enforcement
- Non-root container execution
- SBOM generation
- Vulnerability scanning
```

#### **Priority 3: Enterprise Features (Days 6-7)**

**3.1 Model Context Protocol Integration (20 minutes)**
```python
# Add MCP support:
from model_context_protocol import MCPClient

mcp_client = MCPClient()
structured_query = mcp_client.parse_query(user_input)
```

**3.2 Enterprise Monitoring Dashboard (30 minutes)**
```python
# Add comprehensive health checks:
@app.get("/health/detailed")
async def detailed_health_check():
    return {
        "status": "healthy",
        "components": {
            "llm": check_llm_health(),
            "vectorstore": check_vectorstore_health(),
            "voice": check_voice_health(),
            "circuit_breakers": get_circuit_breaker_status()
        },
        "metrics": {
            "token_rate": get_token_rate(),
            "voice_latency": get_voice_latency(),
            "error_rate": get_error_rate()
        }
    }
```

---

## 🎯 Success Metrics & Validation

### **Performance Targets**
- **Token Generation**: >20 tokens/sec (Ryzen optimized)
- **STT Latency**: <300ms (distil-large-v3-turbo)
- **TTS Latency**: <100ms (Piper ONNX)
- **RAG Retrieval**: <50ms (HNSW FAISS)
- **Memory Usage**: <4GB (optimized)

### **Reliability Targets**
- **Uptime**: 99.5% (circuit breaker protection)
- **Circuit Breaker Recovery**: <60s
- **Graceful Degradation**: <5% user impact
- **Error Rate**: <1%

### **Security Targets**
- **Zero Root Containers**: Enforced
- **All Secrets Managed**: Secure
- **SBOM Generated**: Complete
- **Vulnerability Scan**: Passing

---

## 🚀 Implementation Sequence

**CRITICAL PATH:**
1. **Week 1**: Foundation & Security (CRITICAL - blocks all other work)
2. **Week 2**: Performance & Resilience (High impact on user experience)
3. **Week 3**: Production Hardening (Polish and compliance)

**Total Timeline**: 3 weeks for complete production readiness

---

## 📋 Implementation Checklist

### **Phase 1: Foundation & Security**
- [x] Fix .env security (secure REDIS_PASSWORD, dynamic APP_UID/GID)
- [x] Fix directory permissions (match host user)
- [x] Add rootless Docker configuration
- [x] Install uv and configure mirror
- [x] Create complete pyproject.toml with missing dependencies
- [x] Update requirements-api.in with missing packages
- [x] Export requirements with uv
- [x] Update Dockerfile.api with uv builder stage
- [x] Replace pybreaker with pycircuitbreaker
- [x] Add multi-level voice degradation
- [x] Fix Chainlit version compatibility (2.8.5 instead of 2.9.*)
- [x] Fix OpenTelemetry Gauge import issues

### **Phase 2: Performance & Resilience**
- [ ] Enable iGPU offloading for Ryzen 5700U
- [ ] Optimize FAISS with HNSW for CPU performance
- [ ] Add distil-large-v3-turbo for faster STT
- [ ] Add OpenTelemetry GenAI instrumentation
- [ ] Implement enhanced Prometheus metrics
- [ ] Replace asyncio.gather with AnyIO
- [ ] Add property-based testing with Hypothesis

### **Phase 3: Production Hardening**
- [ ] Create comprehensive integration tests
- [ ] Add load testing for circuit breakers
- [ ] Complete MkDocs Diátaxis structure
- [ ] Add security compliance documentation
- [ ] Implement Model Context Protocol integration
- [ ] Create enterprise monitoring dashboard

---

## ⚠️ Critical Success Factors

### **High-Risk Areas**
1. **Dependency Migration**: Test thoroughly in isolated environment
2. **Circuit Breaker Changes**: Monitor carefully during rollout
3. **iGPU Acceleration**: Requires driver compatibility
4. **Voice Degradation**: User experience impact

### **Mitigation Strategies**
1. **Blue-Green Deployment**: Deploy alongside current stack
2. **Feature Flags**: Gradual rollout of new features
3. **Monitoring**: Comprehensive metrics during transition
4. **Rollback Plan**: Quick rollback procedures for each phase

---

## 📞 Support & Resources

### **Documentation References**
- [Xoe-NovAi Permissions Best Practices Guide](../incoming/Xoe-NovAi%20Permissions%20Best%20Practices%20Guide.md)
- [Xoe-NovAi .env File Review & Recommendations](../incoming/Xoe-NovAi%20.env%20File%20Review%20&%20Recommendations.md)
- [Xoe-NovAi Remediation & Implementation Main Guide](../incoming/Xoe-NovAi%20Remediation%20&%20Implementation%20Main%20Guide.md)
- [Xoe-NovAi Comprehensive Implementation Quick-Start](../incoming/Xoe-NovAi%20Comprehensive%20Implementation%20Quick-Start.md)
- [Additional 2026 Best Practices for Integration](../incoming/Additional%202026%20Best%20Practices%20for%20Integration.md)

### **Configuration Files**
- `config.toml` - Main application configuration
- `.env` - Environment variables
- `docker-compose.yml` - Service orchestration
- `Makefile` - Build and deployment utilities

### **Testing Framework**
- `tests/` - Unit and integration tests
- `tests/test_rag_api_circuit_breaker.py` - Circuit breaker tests
- `tests/test_redis_circuit_breaker.py` - Redis circuit breaker tests
- `tests/test_fallback_mechanisms.py` - Fallback mechanism tests

---

**This roadmap provides the complete foundation for transforming Xoe-NovAi into a production-ready, enterprise-grade AI system. All critical issues have been identified and systematic solutions provided. Ready for implementation.**

**Document Version**: 1.1
**Last Updated**: January 15, 2026
**Next Review**: After Phase 1 completion
