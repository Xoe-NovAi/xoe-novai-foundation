# Xoe-NovAi Build System Guide
## Beginner-Friendly Setup (2026 Edition)

**Version:** v0.1.5
**Status:** ✅ COMPLETE - Beginner-friendly with AMD optimization
**Last Updated:** January 10, 2026

---

## 🎯 NEW: One-Command Setup (Recommended for Everyone)

### For Complete Beginners (AMD Optimized)
```bash
# Run this ONE command - handles everything automatically!
./setup.sh
```

**What it does:**
- ✅ Checks your computer meets requirements (AMD CPU detection)
- ✅ Downloads AI components with progress indicators
- ✅ Builds Python wheels and Docker images
- ✅ Starts your AI assistant automatically
- ✅ Provides clear next steps and usage instructions

**Why this is better:**
- 🚀 **Zero technical knowledge required**
- 🔥 **AMD Ryzen automatic optimization**
- 📊 **Real-time progress tracking**
- 🛡️ **Comprehensive error handling**
- 📖 **Built-in guidance and documentation**

---

## 🔧 Advanced: Manual Build Commands

If you prefer manual control or need custom configurations:

```bash
# Step 1: Build Python wheelhouse (dependencies)
make wheel-build-docker  # Recommended: Guaranteed Python 3.12 compatibility

# Step 2: Build Docker images
make build

# Optional: Validate everything works
make status
make doctor
```

### Why Manual Commands?
- ✅ **Full control** over build process
- ✅ **Custom configurations** possible
- ✅ **Debugging visibility** - see exactly what happens
- ✅ **Integration ready** - works in CI/CD pipelines

---

## 🏗️ Basic Build Process

### Step 1: Wheelhouse Construction
```bash
make wheel-build
```
**What it does:**
- Downloads Python packages for all services (API, Chainlit, Crawl, Curation Worker)
- Builds wheels for offline installation
- Validates Python 3.12 compatibility
- Compresses wheelhouse for storage

**Expected output:**
```
Building wheels for offline caching...
Building wheels for API requirements...
Building wheels for Chainlit requirements...
Building wheels for Crawl requirements...
Building wheels for Curation Worker requirements...
✓ Wheel building complete with Python 3.12 validation
✓ Wheelhouse compressed: 125MB
```

### Step 2: Docker Image Building
```bash
make build
```
**What it does:**
- Builds all Docker images with BuildKit caching
- Creates redis, rag, ui, crawler, and curation_worker images
- Optimizes build cache for faster rebuilds
- Validates build success

**Expected output:**
```
Building Docker images with BuildKit cache mounts...
#1 [internal] load build definition from Dockerfile.api
#2 [internal] load .dockerignore
...
✓ Build completed successfully with BuildKit caching
```

### Step 3: Validation (Optional)
```bash
python3 scripts/validate_wheelhouse.py --target-version 312
```
**What it does:**
- Checks all wheels are compatible with Python 3.12
- Removes incompatible wheels automatically
- Generates detailed compatibility report

---

## 🚀 Quick Start (Recommended)

```bash
# Complete build process (3 commands)
make wheel-build
make build
python3 scripts/validate_wheelhouse.py --target-version 312

# Start services
make up

# Check logs
make logs CONTAINER=xnai_rag_api
```

---

## 📊 Enterprise Script Status

### Current Issues with `scripts/enterprise_build.sh`
- ❌ **Complex monitoring systems** causing race conditions
- ❌ **Background processes** interfering with main execution
- ❌ **Command execution failures** due to wrapper complexity
- ❌ **Silent periods** during long operations

### Simplification Plan
1. **Phase 1:** Remove complex multi-method monitoring
2. **Phase 2:** Implement simple synchronous execution
3. **Phase 3:** Add basic progress indicators
4. **Phase 4:** Restore comprehensive error handling

**Status:** Research complete, implementation in progress. Use basic commands for now.

---

## 🛠️ Troubleshooting

### Common Issues

#### "Command not found" errors
```bash
# Check required tools
which python3 make docker curl jq

# Install missing tools
sudo apt update && sudo apt install python3 make docker.io curl jq
```

#### Wheelhouse build failures
```bash
# Clear and rebuild
rm -rf wheelhouse/
make wheel-build

# Check disk space
df -h /
```

#### Docker build failures
```bash
# Clear Docker cache
sudo docker system prune -a

# Rebuild without cache
make build DOCKER_BUILDKIT=0

# Check Docker status
sudo docker info
```

#### Validation failures
```bash
# Clean incompatible wheels
python3 scripts/validate_wheelhouse.py --clean-incompatible

# Rebuild and validate
make wheel-build
python3 scripts/validate_wheelhouse.py --target-version 312
```

---

## 📋 Service Management

### Starting Services
```bash
make up
```

### Checking Status
```bash
# All containers
sudo docker ps

# Service health
make health

# Resource usage
sudo docker stats
```

### Viewing Logs
```bash
# All services
make logs

# Specific container
make logs CONTAINER=xnai_rag_api

# Follow logs
make logs CONTAINER=xnai_rag_api LINES=50
```

### Stopping Services
```bash
make down
```

---

## 🔧 Advanced Usage

### Development Workflow
```bash
# Clean rebuild
make clean
make wheel-build
make build

# Test integration
make test

# Performance check
make benchmark
```

### CI/CD Integration
```yaml
# .github/workflows/build.yml
name: Build
on: [push]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Docker
        run: sudo apt install docker.io
      - name: Build Wheelhouse
        run: make wheel-build
      - name: Build Docker Images
        run: make build
      - name: Validate
        run: python3 scripts/validate_wheelhouse.py --target-version 312
```

---

## 📚 Documentation Links

- **Quick Start:** `docs/howto/quick-start.md`
- **Docker Setup:** `docs/howto/docker-setup.md`
- **Troubleshooting:** Check logs in `logs/` directory
- **Architecture:** `docs/reference/architecture.md`

---

**Use `make wheel-build` and `make build` for reliable builds. Enterprise script simplification in progress.**
