# 🚀 Xoe-NovAi Deployment & Operations Guide
## Production Integration Operations Manual

**Last Updated**: January 14, 2026  
**Version**: v0.1.5 → v0.2.0 (Target)  
**Operational Readiness**: 70% → 95% (Target)  
**Zero-Downtime Capability**: No → Yes (Target)

---

## 📋 Operations Overview

### Current Operational State
- **Deployment**: Docker Compose with basic orchestration
- **Monitoring**: Basic health checks only
- **Scaling**: Single worker per service
- **Backup**: Manual FAISS and log backups
- **Updates**: Manual deployment process

### Target Operational State (Post-Implementation)
- **Deployment**: Multi-worker orchestration with load balancing
- **Monitoring**: Comprehensive observability with alerting
- **Scaling**: Auto-scaling based on load metrics
- **Backup**: Automated, scheduled backups with validation
- **Updates**: Blue-green deployment with rollback capability

---

## 🏗️ Deployment Architecture

### 1. Current Architecture (Docker Compose)

#### Service Architecture
```yaml
# docker-compose.yml (current)
services:
  xnai_rag_api:
    image: xnai:api-v0.1.5
    ports:
      - "8000:8000"
    volumes:
      - ./library:/library
      - ./knowledge:/knowledge
      - ./data:/app/data
    environment:
      - REDIS_URL=redis://redis:6379
    depends_on:
      - redis

  xnai_chainlit_ui:
    image: xnai:chainlit-v0.1.5
    ports:
      - "8001:8001"
    environment:
      - RAG_API_URL=http://rag:8000
    depends_on:
      - xnai_rag_api

  xnai_crawler:
    image: xnai:crawler-v0.1.5
    environment:
      - REDIS_URL=redis://redis:6379
    depends_on:
      - redis

  redis:
    image: redis:7.4.1-alpine
    ports:
      - "6379:6379"
    volumes:
      - ./data/redis:/data
```

#### Deployment Process
```bash
# Current deployment
make build
make up
make health
```

### 2. Enhanced Architecture (Production-Ready)

#### Multi-Worker Architecture
```yaml
# docker-compose.prod.yml (enhanced)
services:
  # Load Balancer
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl/certs
    depends_on:
      - chainlit_upstream

  # Chainlit UI (Multi-Worker)
  chainlit_upstream:
    image: xnai:chainlit-v0.2.0
    deploy:
      replicas: 3
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
    environment:
      - RAG_API_URL=http://api_upstream
      - WORKERS=4
      - WORKER_CLASS=uvicorn.workers.UvicornWorker
    volumes:
      - ./data/sessions:/app/sessions
    depends_on:
      - api_upstream

  # API Service (Multi-Worker)
  api_upstream:
    image: xnai:api-v0.2.0
    deploy:
      replicas: 2
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
    environment:
      - REDIS_URL=redis://redis_cluster
      - WORKERS=4
      - WORKER_CLASS=uvicorn.workers.UvicornWorker
    volumes:
      - ./library:/library:ro
      - ./knowledge:/knowledge:ro
      - ./data/faiss:/app/data/faiss:ro
    depends_on:
      - redis_cluster

  # Crawler (Background Service)
  crawler:
    image: xnai:crawler-v0.2.0
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
    environment:
      - REDIS_URL=redis://redis_cluster
    volumes:
      - ./knowledge:/knowledge
    depends_on:
      - redis_cluster

  # Redis Cluster
  redis_cluster:
    image: redis:7.4.1-alpine
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
    volumes:
      - ./data/redis:/data
      - ./config/redis.conf:/etc/redis/redis.conf
    command: redis-server /etc/redis/redis.conf

  # Monitoring Stack
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - ./data/prometheus:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_ADMIN_PASSWORD}
    volumes:
      - ./data/grafana:/var/lib/grafana
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning
    depends_on:
      - prometheus

  alertmanager:
    image: prom/alertmanager:latest
    ports:
      - "9093:9093"
    volumes:
      - ./monitoring/alertmanager.yml:/etc/alertmanager/alertmanager.yml
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
      - '--storage.path=/alertmanager'

  # Backup Service
  backup:
    image: xnai:backup-v0.2.0
    environment:
      - BACKUP_SCHEDULE=0 0 * * *
      - RETENTION_DAYS=7
      - S3_BUCKET=${BACKUP_BUCKET}
    volumes:
      - ./data:/data:ro
      - ./backups:/backups
    depends_on:
      - api_upstream
```

#### Nginx Load Balancer Configuration
```nginx
# nginx/nginx.conf
upstream chainlit_backend {
    ip_hash;  # Session affinity
    server chainlit_upstream:8001;
    server chainlit_upstream:8002;
    server chainlit_upstream:8003;
}

upstream api_backend {
    least_conn;  # Load balancing
    server api_upstream:8000;
    server api_upstream:8001;
}

server {
    listen 80;
    server_name xnai.example.com;

    # Rate limiting
    limit_req zone=api burst=10 nodelay;
    limit_req zone=voice burst=5 nodelay;

    # WebSocket support for voice
    location /ws {
        proxy_pass http://chainlit_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # API endpoints
    location /api/ {
        proxy_pass http://api_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Static UI
    location / {
        proxy_pass http://chainlit_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Health check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}

# Rate limiting zones
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=voice:10m rate=5r/s;
```

---

## 🚀 Deployment Strategies

### 1. Blue-Green Deployment

#### Architecture
```
Production Environment:
├── Blue Stack (Active)
│   ├── nginx (v1.0)
│   ├── api_upstream (v1.0)
│   └── chainlit_upstream (v1.0)
│
└── Green Stack (Inactive)
    ├── nginx (v2.0)
    ├── api_upstream (v2.0)
    └── chainlit_upstream (v2.0)
```

#### Deployment Process
```bash
#!/bin/bash
# deploy-blue-green.sh

set -e

ENVIRONMENT=$1
NEW_VERSION=$2

echo "🚀 Starting blue-green deployment of $NEW_VERSION to $ENVIRONMENT"

# 1. Deploy to green stack
echo "📦 Deploying to green stack..."
docker stack deploy --compose-file docker-compose.green.yml xnai_green

# 2. Wait for health checks
echo "🏥 Running health checks..."
for i in {1..30}; do
    if curl -f http://green.xnai.example.com/health; then
        echo "✅ Green stack is healthy"
        break
    fi
    if [ $i -eq 30 ]; then
        echo "❌ Green stack health check failed"
        exit 1
    fi
    sleep 10
done

# 3. Run smoke tests
echo "🧪 Running smoke tests..."
if ! ./scripts/smoke-test.sh green.xnai.example.com; then
    echo "❌ Smoke tests failed"
    exit 1
fi

# 4. Switch load balancer
echo "🔄 Switching load balancer to green stack..."
kubectl patch service nginx-lb -p '{"spec":{"selector":{"stack":"green"}}}'

# 5. Monitor for 5 minutes
echo "📊 Monitoring green stack performance..."
sleep 300

# 6. Verify no errors
if ./scripts/verify-deployment.sh green.xnai.example.com; then
    echo "✅ Deployment successful!"
    echo "🧹 Cleaning up blue stack..."
    docker stack rm xnai_blue
else
    echo "❌ Deployment verification failed, rolling back..."
    kubectl patch service nginx-lb -p '{"spec":{"selector":{"stack":"blue"}}}'
    exit 1
fi
```

### 2. Rolling Deployment

#### Configuration
```yaml
# docker-compose.roll.yml
services:
  xnai_chainlit_ui:
    image: xnai:chainlit-${TAG}
    deploy:
      replicas: 3
      update_config:
        parallelism: 1      # Update one container at a time
        delay: 10s          # Wait 10s between updates
        failure_action: rollback  # Rollback on failure
        monitor: 30s        # Monitor for 30s after update
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
```

#### Rolling Update Process
```bash
#!/bin/bash
# rolling-deploy.sh

TAG=$1
SERVICE=$2

echo "🔄 Starting rolling deployment of $SERVICE:$TAG"

# Update with rolling strategy
docker service update \
  --image xnai:$SERVICE-$TAG \
  --update-parallelism 1 \
  --update-delay 10s \
  --update-failure-action rollback \
  --update-monitor 30s \
  xnai_$SERVICE

# Monitor rollout
docker service ps xnai_$SERVICE --format "table {{.Name}}\t{{.CurrentState}}"

# Wait for completion
docker service ps xnai_$SERVICE | grep -v "Running\|Ready" | wc -l

echo "✅ Rolling deployment completed"
```

### 3. Canary Deployment

#### Configuration
```yaml
# kubernetes/canary-deployment.yml
apiVersion: v1
kind: Service
metadata:
  name: xnai-api
spec:
  selector:
    app: xnai-api
    version: stable  # Default to stable
  ports:
  - port: 80
    targetPort: 8000

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: xnai-api-stable
spec:
  replicas: 8  # 80% of traffic
  selector:
    matchLabels:
      app: xnai-api
      version: stable
  template:
    metadata:
      labels:
        app: xnai-api
        version: stable
    spec:
      containers:
      - name: api
        image: xnai:api-v1.0

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: xnai-api-canary
spec:
  replicas: 2  # 20% of traffic
  selector:
    matchLabels:
      app: xnai-api
      version: canary
  template:
    metadata:
      labels:
        app: xnai-api
        version: canary
    spec:
      containers:
      - name: api
        image: xnai:api-v2.0
```

---

## 📊 Monitoring & Alerting

### 1. System Health Monitoring

#### Health Check Endpoints
```python
# app/XNAi_rag_app/healthcheck.py
@app.get("/health")
async def health_check():
    """Comprehensive health check endpoint"""
    return await health_checker.run_health_checks()

@app.get("/health/detailed")
async def detailed_health_check():
    """Detailed health check with component status"""
    results = await health_checker.run_health_checks(targets=['llm', 'embeddings', 'memory', 'redis', 'vectorstore', 'ryzen'])
    
    # Add performance metrics
    performance = await get_performance_metrics()
    
    return {
        "status": "healthy" if all(r[0] for r in results.values()) else "degraded",
        "timestamp": datetime.utcnow().isoformat(),
        "checks": results,
        "performance": performance,
        "version": config.get('metadata.stack_version')
    }

@app.get("/metrics")
async def metrics_endpoint():
    """Prometheus metrics endpoint"""
    return Response(
        generate_latest(REGISTRY),
        media_type="text/plain; version=0.0.4; charset=utf-8"
    )
```

#### Health Check Configuration
```yaml
# docker-compose.health.yml
services:
  healthcheck:
    image: curlimages/curl:latest
    command: >
      sh -c "
        echo 'Starting health checks...' &&
        while true; do
          # API health
          if curl -f http://api_upstream:8000/health; then
            echo '✅ API healthy'
          else
            echo '❌ API unhealthy'
            exit 1
          fi
          
          # UI health
          if curl -f http://chainlit_upstream:8001/health; then
            echo '✅ UI healthy'
          else
            echo '❌ UI unhealthy'
            exit 1
          fi
          
          sleep 30
        done
      "
    depends_on:
      - api_upstream
      - chainlit_upstream
    restart: unless-stopped
```

### 2. Alerting Configuration

#### Prometheus Alerting Rules
```yaml
# monitoring/prometheus/alert_rules.yml
groups:
  - name: xnai_system
    rules:
      - alert: InstanceDown
        expr: up{job="xnai"} == 0
        for: 1m
        labels:
          severity: critical
          service: xnai
        annotations:
          summary: "Instance {{ $labels.instance }} is down"
          description: "{{ $labels.instance }} has been down for more than 1 minute"

      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.1
        for: 2m
        labels:
          severity: warning
          service: xnai
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value | humanizePercentage }}"

      - alert: HighLatency
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2.0
        for: 5m
        labels:
          severity: warning
          service: xnai
        annotations:
          summary: "High request latency"
          description: "95th percentile latency is {{ $value }}s"

  - name: xnai_voice
    rules:
      - alert: VoiceProcessingFailed
        expr: rate(voice_processing_errors_total[5m]) > 0
        for: 1m
        labels:
          severity: warning
          service: voice
        annotations:
          summary: "Voice processing errors detected"
          description: "{{ $value }} voice processing errors in the last 5 minutes"

  - name: xnai_resources
    rules:
      - alert: HighMemoryUsage
        expr: (1 - system_memory_available_bytes / system_memory_total_bytes) * 100 > 85
        for: 5m
        labels:
          severity: warning
          service: system
        annotations:
          summary: "High memory usage"
          description: "Memory usage is {{ $value | humanizePercentage }}"

      - alert: HighCPUUsage
        expr: system_cpu_usage_percent > 90
        for: 5m
        labels:
          severity: warning
          service: system
        annotations:
          summary: "High CPU usage"
          description: "CPU usage is {{ $value | humanizePercentage }}"
```

#### AlertManager Configuration
```yaml
# monitoring/alertmanager.yml
global:
  smtp_smarthost: 'smtp.gmail.com:587'
  smtp_from: 'alerts@xnai.example.com'
  smtp_auth_username: 'alerts@xnai.example.com'
  smtp_auth_password: '${SMTP_PASSWORD}'

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'team'
  routes:
  - match:
      severity: critical
    receiver: 'team-critical'

receivers:
- name: 'team'
  email_configs:
  - to: 'team@xnai.example.com'
    subject: '[{{ .GroupLabels.alertname }}] {{ .Annotations.summary }}'
    body: |
      {{ range .Alerts }}
      Alert: {{ .Annotations.summary }}
      Description: {{ .Annotations.description }}
      Runbook: {{ .Annotations.runbook_url }}
      {{ end }}

- name: 'team-critical'
  email_configs:
  - to: 'team@xnai.example.com'
  pagerduty_configs:
  - service_key: '${PAGERDUTY_SERVICE_KEY}'
```

---

## 🔄 Backup & Recovery

### 1. Automated Backup Strategy

#### Backup Configuration
```yaml
# docker-compose.backup.yml
services:
  backup:
    image: xnai:backup-v0.2.0
    environment:
      - BACKUP_SCHEDULE=0 0 * * *  # Daily at midnight
      - RETENTION_DAYS=7
      - COMPRESSION=gzip
      - ENCRYPTION=true
      - ENCRYPTION_KEY=${BACKUP_ENCRYPTION_KEY}
      - S3_BUCKET=${BACKUP_S3_BUCKET}
      - S3_ACCESS_KEY=${AWS_ACCESS_KEY_ID}
      - S3_SECRET_KEY=${AWS_SECRET_ACCESS_KEY}
    volumes:
      - ./data:/data:ro
      - ./library:/library:ro
      - ./knowledge:/knowledge:ro
      - ./backups:/backups
    command: backup-daemon
```

#### Backup Script
```bash
#!/bin/bash
# scripts/backup.sh

set -e

BACKUP_DIR="./backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="xnai_backup_${TIMESTAMP}"

echo "📦 Starting backup: $BACKUP_NAME"

# Create backup directory
mkdir -p "$BACKUP_DIR/$BACKUP_NAME"

# Backup FAISS index
echo "💾 Backing up FAISS index..."
cp -r ./data/faiss_index "$BACKUP_DIR/$BACKUP_NAME/"

# Backup Redis data
echo "🗄️ Backing up Redis data..."
docker exec xnai_redis redis-cli SAVE
cp ./data/redis/dump.rdb "$BACKUP_DIR/$BACKUP_NAME/redis_dump.rdb"

# Backup logs
echo "📝 Backing up logs..."
cp -r ./logs "$BACKUP_DIR/$BACKUP_NAME/"

# Backup configuration
echo "⚙️ Backing up configuration..."
cp config.toml "$BACKUP_DIR/$BACKUP_NAME/"
cp docker-compose.yml "$BACKUP_DIR/$BACKUP_NAME/"

# Compress backup
echo "🗜️ Compressing backup..."
tar -czf "$BACKUP_DIR/${BACKUP_NAME}.tar.gz" -C "$BACKUP_DIR" "$BACKUP_NAME"

# Encrypt backup
echo "🔐 Encrypting backup..."
openssl enc -aes-256-cbc -salt -in "$BACKUP_DIR/${BACKUP_NAME}.tar.gz" \
  -out "$BACKUP_DIR/${BACKUP_NAME}.enc" -k "${BACKUP_ENCRYPTION_KEY}"

# Upload to S3
echo "☁️ Uploading to S3..."
aws s3 cp "$BACKUP_DIR/${BACKUP_NAME}.enc" "s3://${S3_BUCKET}/backups/"

# Clean up local files
rm -rf "$BACKUP_DIR/$BACKUP_NAME"
rm "$BACKUP_DIR/${BACKUP_NAME}.tar.gz"

# Rotate backups
echo "🧹 Rotating old backups..."
find "$BACKUP_DIR" -name "xnai_backup_*.enc" -mtime +7 -delete

echo "✅ Backup completed successfully"
```

### 2. Disaster Recovery

#### Recovery Procedures
```bash
#!/bin/bash
# scripts/recovery.sh

set -e

BACKUP_NAME=$1

if [ -z "$BACKUP_NAME" ]; then
    echo "Usage: $0 <backup_name>"
    echo "Available backups:"
    aws s3 ls "s3://${S3_BUCKET}/backups/" | grep xnai_backup
    exit 1
fi

echo "🔄 Starting recovery from: $BACKUP_NAME"

# Stop services
echo "🛑 Stopping services..."
docker-compose down

# Download and decrypt backup
echo "📥 Downloading backup..."
aws s3 cp "s3://${S3_BUCKET}/backups/${BACKUP_NAME}.enc" "./backups/"

echo "🔓 Decrypting backup..."
openssl enc -d -aes-256-cbc -in "./backups/${BACKUP_NAME}.enc" \
  -out "./backups/${BACKUP_NAME}.tar.gz" -k "${BACKUP_ENCRYPTION_KEY}"

# Extract backup
echo "📦 Extracting backup..."
tar -xzf "./backups/${BACKUP_NAME}.tar.gz" -C "./backups/"

# Restore data
echo "🔄 Restoring FAISS index..."
cp -r "./backups/${BACKUP_NAME}/faiss_index" ./data/

echo "🔄 Restoring Redis data..."
cp "./backups/${BACKUP_NAME}/redis_dump.rdb" ./data/redis/dump.rdb

echo "🔄 Restoring configuration..."
cp "./backups/${BACKUP_NAME}/config.toml" ./
cp "./backups/${BACKUP_NAME}/docker-compose.yml" ./

# Start services
echo "🚀 Starting services..."
docker-compose up -d

# Verify recovery
echo "✅ Verifying recovery..."
sleep 30

if curl -f http://localhost:8000/health && curl -f http://localhost:8001/health; then
    echo "✅ Recovery completed successfully"
else
    echo "❌ Recovery verification failed"
    exit 1
fi
```

---

## 📈 Scaling & Performance

### 1. Auto-Scaling Configuration

#### Docker Swarm Auto-Scaling
```yaml
# docker-compose.autoscale.yml
services:
  xnai_chainlit_ui:
    image: xnai:chainlit-v0.2.0
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '1.0'
          memory: 1G
        reservations:
          cpus: '0.5'
          memory: 512M
      restart_policy:
        condition: on-failure
    environment:
      - AUTOSCALE=true
      - AUTOSCALE_MIN_REPLICAS=2
      - AUTOSCALE_MAX_REPLICAS=10
      - AUTOSCALE_CPU_THRESHOLD=70
      - AUTOSCALE_MEMORY_THRESHOLD=80

  xnai_rag_api:
    image: xnai:api-v0.2.0
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
      restart_policy:
        condition: on-failure
    environment:
      - AUTOSCALE=true
      - AUTOSCALE_MIN_REPLICAS=2
      - AUTOSCALE_MAX_REPLICAS=8
      - AUTOSCALE_CPU_THRESHOLD=80
      - AUTOSCALE_MEMORY_THRESHOLD=85
```

#### Kubernetes HPA
```yaml
# kubernetes/hpa.yml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: xnai-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: xnai-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: Pods
    pods:
      metric:
        name: http_requests_per_second
      target:
        type: AverageValue
        averageValue: 1000m  # 1000 requests per second per pod
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60
        selectPolicy: Max
```

### 2. Performance Optimization

#### Caching Strategy
```python
# app/XNAi_rag_app/cache.py
from cachetools import TTLCache, LRUCache
from redis.asyncio import Redis

class MultiLevelCache:
    def __init__(self):
        # Local in-memory cache
        self.local_cache = TTLCache(maxsize=1000, ttl=300)  # 5 minute TTL
        
        # Redis distributed cache
        self.redis_cache = Redis(host='redis', port=6379, decode_responses=True)
        
        # Persistent cache for embeddings
        self.embedding_cache = LRUCache(maxsize=10000)
    
    async def get(self, key: str):
        """Get value from multi-level cache"""
        # Check local cache first
        if key in self.local_cache:
            return self.local_cache[key]
        
        # Check Redis cache
        redis_value = await self.redis_cache.get(key)
        if redis_value:
            # Populate local cache
            self.local_cache[key] = redis_value
            return redis_value
        
        return None
    
    async def set(self, key: str, value, ttl: int = 300):
        """Set value in multi-level cache"""
        # Set in local cache
        self.local_cache[key] = value
        
        # Set in Redis cache
        await self.redis_cache.set(key, value, ex=ttl)
    
    async def invalidate_pattern(self, pattern: str):
        """Invalidate cache keys matching pattern"""
        # Invalidate local cache
        keys_to_delete = [k for k in self.local_cache.keys() if pattern in k]
        for key in keys_to_delete:
            del self.local_cache[key]
        
        # Invalidate Redis cache
        keys = await self.redis_cache.keys(pattern)
        if keys:
            await self.redis_cache.delete(*keys)
```

#### Database Optimization
```python
# app/XNAi_rag_app/vectorstore.py
class OptimizedFAISS:
    def __init__(self, index_path: str):
        self.index_path = index_path
        self.index = None
        self.metadata = {}
        
        # Performance optimizations
        faiss.omp_set_num_threads(6)  # AMD Ryzen threads
        self.search_params = faiss.SearchParametersIVF()
        self.search_params.nprobe = 10  # Search more cells for better recall
        
        self.load_index()
    
    def load_index(self):
        """Load FAISS index with optimizations"""
        if os.path.exists(self.index_path):
            self.index = faiss.read_index(self.index_path)
            
            # Enable memory mapping for large indexes
            if self.index.ntotal > 100000:
                faiss.index_cpu_to_gpu(faiss.StandardGpuResources(), 0, self.index)
    
    async def search(self, query_embedding, k=5):
        """Optimized similarity search"""
        # Pre-allocate result arrays
        distances = np.empty((1, k), dtype=np.float32)
        indices = np.empty((1, k), dtype=np.int64)
        
        # Perform search with optimized parameters
        self.index.search(query_embedding.reshape(1, -1), k, distances, indices, self.search_params)
        
        return distances[0], indices[0]
    
    def save_index(self):
        """Save index with compression"""
        if self.index:
            # Use compressed format for large indexes
            if self.index.ntotal > 50000:
                faiss.write_index(self.index, self.index_path + '.compressed')
            else:
                faiss.write_index(self.index, self.index_path)
```

---

## 🔧 Maintenance Procedures

### 1. Routine Maintenance

#### Daily Tasks
```bash
#!/bin/bash
# scripts/daily-maintenance.sh

echo "🗓️ Running daily maintenance tasks..."

# 1. Health checks
echo "🏥 Running health checks..."
if ! curl -f http://localhost:8000/health; then
    echo "❌ API health check failed"
    exit 1
fi

# 2. Log rotation
echo "📝 Rotating logs..."
find ./logs -name "*.log" -mtime +7 -delete

# 3. Cache cleanup
echo "🧹 Cleaning expired cache entries..."
docker exec xnai_redis redis-cli KEYS "cache:*" | xargs -r docker exec xnai_redis redis-cli DEL

# 4. Backup verification
echo "💾 Verifying backup integrity..."
LATEST_BACKUP=$(aws s3 ls s3://${S3_BUCKET}/backups/ | sort | tail -1 | awk '{print $4}')
if [ -z "$LATEST_BACKUP" ]; then
    echo "❌ No recent backup found"
    exit 1
fi

echo "✅ Daily maintenance completed"
```

#### Weekly Tasks
```bash
#!/bin/bash
# scripts/weekly-maintenance.sh

echo "📅 Running weekly maintenance tasks..."

# 1. Full backup
echo "💾 Creating full backup..."
./scripts/backup.sh

# 2. Performance analysis
echo "📊 Analyzing performance trends..."
./scripts/performance-analysis.sh

# 3. Security updates
echo "🔒 Checking for security updates..."
./scripts/security-updates.sh

# 4. Dependency updates
echo "⬆️ Checking for dependency updates..."
./scripts/dependency-updates.sh

# 5. Database optimization
echo "🗄️ Optimizing vector database..."
./scripts/db-optimization.sh

echo "✅ Weekly maintenance completed"
```

### 2. Troubleshooting Guide

#### Common Issues and Solutions

**Issue: High Memory Usage**
```bash
# Diagnosis
docker stats
docker exec xnai_rag_api ps aux --sort=-%mem | head -10

# Solutions
# 1. Restart services
docker-compose restart

# 2. Clear caches
docker exec xnai_redis redis-cli FLUSHALL

# 3. Reduce batch sizes in configuration
# 4. Add memory limits to containers
```

**Issue: Slow Response Times**
```bash
# Diagnosis
curl -w "@curl-format.txt" http://localhost:8000/api/query -X POST -d '{"query":"test"}'

# Check system resources
top -p $(pgrep -f "uvicorn")
iostat -x 1 5

# Solutions
# 1. Scale up API workers
docker service scale xnai_api=4

# 2. Optimize queries
# 3. Add Redis caching
# 4. Check network latency
```

**Issue: Voice Processing Errors**
```bash
# Diagnosis
docker logs xnai_chainlit_ui | grep -i error
docker exec xnai_chainlit_ui curl http://localhost:8001/health

# Check voice service
docker exec xnai_rag_api python -c "from voice_interface import VoiceInterface; print('Voice OK')"

# Solutions
# 1. Restart voice services
docker-compose restart chainlit

# 2. Check model files
ls -la models/ embeddings/

# 3. Verify audio formats
# 4. Check system audio libraries
```

---

## 📚 Operational Runbooks

### 1. Incident Response

#### Critical Incident Process
1. **Detection**: Alert triggered or user report
2. **Assessment**: Determine impact and severity
3. **Communication**: Notify stakeholders
4. **Containment**: Isolate affected systems
5. **Recovery**: Implement fix or rollback
6. **Analysis**: Root cause analysis
7. **Prevention**: Implement safeguards

#### Communication Template
```
🚨 INCIDENT ALERT 🚨

**Incident ID**: INC-2026-001
**Severity**: Critical
**Service**: Xoe-NovAi API
**Start Time**: 2026-01-14 18:00 UTC
**Impact**: API responses failing, affecting all users

**Current Status**: Investigating
**Estimated Resolution**: 30 minutes

**Affected Systems**:
- API Service (8000)
- Voice Processing
- RAG Pipeline

**Workaround**: Use basic text interface

**Updates**: Will provide updates every 15 minutes
```

### 2. Capacity Planning

#### Resource Monitoring
```python
# scripts/capacity-planning.py
import psutil
import time
from prometheus_api_client import PrometheusConnect

class CapacityPlanner:
    def __init__(self):
        self.prometheus = PrometheusConnect(url="http://localhost:9090")
    
    def get_current_capacity(self):
        """Get current system capacity metrics"""
        # CPU usage
        cpu_usage = psutil.cpu_percent(interval=60)
        
        # Memory usage
        memory = psutil.virtual_memory()
        memory_usage = memory.percent
        
        # Disk usage
        disk = psutil.disk_usage('/')
        disk_usage = disk.percent
        
        # Network I/O
        network = psutil.net_io_counters()
        
        return {
            'cpu_usage': cpu_usage,
            'memory_usage': memory_usage,
            'disk_usage': disk_usage,
            'network_bytes_sent': network.bytes_sent,
            'network_bytes_recv': network.bytes_recv
        }
    
    def predict_capacity_needs(self, days=30):
        """Predict future capacity needs based on trends"""
        # Query historical metrics
        cpu_query = f"avg_over_time(cpu_usage_percent[{days}d])"
        memory_query = f"avg_over_time(memory_usage_percent[{days}d])"
        
        cpu_trend = self.prometheus.custom_query(cpu_query)
        memory_trend = self.prometheus.custom_query(memory_query)
        
        # Calculate growth rate
        cpu_growth = self.calculate_growth_rate(cpu_trend)
        memory_growth = self.calculate_growth_rate(memory_trend)
        
        # Predict future needs
        return {
            'cpu_growth_rate': cpu_growth,
            'memory_growth_rate': memory_growth,
            'recommended_cpu': self.current_cpu * (1 + cpu_growth * days / 365),
            'recommended_memory': self.current_memory * (1 + memory_growth * days / 365)
        }
```

---

## 🎯 Success Metrics

### Operational Excellence Targets
- **Uptime**: 99.9% (8.77 hours downtime per year)
- **MTTR**: <15 minutes for critical incidents
- **MTTD**: <2 minutes for critical alerts
- **Change Success Rate**: >99% for deployments
- **Backup Recovery Time**: <1 hour

### Performance Targets
- **Request Latency**: p95 < 500ms
- **Concurrent Users**: 1000+ supported
- **Voice Processing**: <300ms STT, <100ms TTS
- **RAG Retrieval**: <50ms response time
- **Cache Hit Rate**: >90%

### Quality Targets
- **Error Rate**: <0.01% for production
- **Data Loss**: Zero for critical data
- **Security Incidents**: Zero acceptable
- **Compliance**: 100% regulatory compliance

---

**Next Review**: January 21, 2026 (After Phase 1 Implementation)  
**Operational Readiness**: 70% → 95% (Target)  
**Zero-Downtime Capability**: Implemented and Tested

**Document Version**: 1.0  
**Last Updated**: January 14, 2026  
**Next Update**: January 21, 2026
