# 🔧 **PHASE 1: CRITICAL FOUNDATION FIXES**
## **Implementation Guide (Week 1-2)**

**Status:** 🚨 IMMEDIATE PRIORITY - Deployment Blockers
**Timeline:** Week 1-2 (Critical Path)
**Dependencies:** None (Foundation Work)
**Risk Level:** 🔴 HIGH (Deployment Blocking Issues)

**📋 Related Documents:**
- **Main Roadmap:** [`COMPREHENSIVE_STACK_POLISHING_ROADMAP.md`](COMPREHENSIVE_STACK_POLISHING_ROADMAP.md)
- **Progress Tracker:** [`polishing-progress-tracker.md`](polishing-progress-tracker.md)
- **Enterprise Checklist:** [`checklist.md`](checklist.md)
- **Full Stack Audit:** [`FULL_STACK_AUDIT_REPORT.md`](FULL_STACK_AUDIT_REPORT.md)

---

## 📋 **PHASE 1 OVERVIEW**

Phase 1 addresses critical foundation issues that are currently **blocking deployment** and preventing the system from running in production. These fixes are essential prerequisites for all subsequent polishing work.

### **🎯 Phase 1 Objectives:**
1. **Unblock Docker Deployment** - Fix build system issues preventing container startup
2. **Enable AI Scaling** - Implement Ray runtime for horizontal scaling
3. **Add Content Provenance** - Deploy AI watermarking for compliance
4. **Validate System Health** - Complete end-to-end testing and validation

---

## 1.1 🔧 **DOCKER BUILD SYSTEM OVERHAUL**

### **Current Issue:**
- BuildKit compatibility problems preventing container builds
- Makefile using outdated `docker compose` syntax instead of `docker-compose`
- Permission issues requiring sudo for Docker operations

### **Implementation Steps:**

#### **Step 1: Fix Makefile Docker Compose Syntax**
```bash
# Current (Broken):
COMPOSE := sudo DOCKER_BUILDKIT=1 docker compose

# Fix to:
COMPOSE := sudo DOCKER_BUILDKIT=0 docker-compose
```

**Files to Update:**
- `Makefile` (lines 8-15)
- Replace all `docker compose` with `docker-compose`
- Update COMPOSE variable definitions

#### **Step 2: Resolve BuildKit Issues**
**Problem:** BuildKit features like `--mount` require BuildKit to be enabled, but it's causing compatibility issues.

**Solution:** Remove BuildKit-specific features from Dockerfiles:
```dockerfile
# REMOVE these BuildKit features:
RUN --mount=type=cache,target=/var/cache/apt,sharing=locked \
    --mount=type=cache,target=/root/.cache/pip,sharing=locked \
    apt-get update

# REPLACE with traditional approach:
RUN apt-get update && apt-get install -y packages
```

**Files to Update:**
- `Dockerfile.api` (lines 25-35)
- `Dockerfile.chainlit` (lines 20-30)
- Remove all `--mount` directives
- Simplify build caching approach

#### **Step 3: Docker Permissions Automation**
**Current Issue:** Users must manually run `sudo usermod -aG docker $USER` and logout/login.

**Solution:** Create automated setup script:
```bash
#!/bin/bash
# scripts/setup_docker_permissions.sh

# Add user to docker group
sudo usermod -aG docker $USER

# Create docker group if it doesn't exist
sudo groupadd -f docker

# Set proper permissions on docker socket
sudo chmod 666 /var/run/docker.sock

# Enable and start docker service
sudo systemctl enable docker
sudo systemctl start docker

echo "✅ Docker permissions configured"
echo "💡 Logout and login again, or run: newgrp docker"
```

### **Testing & Validation:**
```bash
# Test 1: Verify Docker permissions
docker ps  # Should work without sudo

# Test 2: Verify Makefile syntax
make build  # Should start without syntax errors

# Test 3: Verify container builds
make up  # Should build and start all containers
```

---

## 1.2 🤖 **RAY AI RUNTIME MULTI-NODE ORCHESTRATION**

### **Current Status:**
- Architecture designed but implementation missing
- Required for horizontal scaling capability
- Essential for enterprise AI workloads

### **Implementation Steps:**

#### **Step 1: Ray Runtime Integration**
```python
# app/XNAi_rag_app/ray_runtime.py (NEW FILE)

import ray
from typing import List, Dict, Any
import asyncio
from concurrent.futures import ThreadPoolExecutor

class RayRuntimeManager:
    """Ray AI Runtime for distributed AI processing"""

    def __init__(self, num_cpus: int = None, num_gpus: int = None):
        self.num_cpus = num_cpus
        self.num_gpus = num_gpus
        self.executor = ThreadPoolExecutor(max_workers=4)

    async def initialize_cluster(self):
        """Initialize Ray cluster for distributed processing"""
        if not ray.is_initialized():
            ray.init(
                num_cpus=self.num_cpus,
                num_gpus=self.num_gpus,
                include_dashboard=True,
                dashboard_host="0.0.0.0",
                dashboard_port=8265
            )
        return ray.cluster_resources()

    @ray.remote
    def process_ai_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Distributed AI task processing"""
        # Implement distributed AI processing logic
        pass

    async def scale_ai_workload(self, tasks: List[Dict]) -> List[Dict]:
        """Scale AI processing across multiple nodes"""
        futures = [self.process_ai_task.remote(task) for task in tasks]
        results = await asyncio.gather(*futures)
        return results
```

#### **Step 2: Circuit Breaker Integration**
```python
# Integrate Ray runtime with existing circuit breakers
# app/XNAi_rag_app/circuit_breakers.py (UPDATE)

class RayCircuitBreaker(CircuitBreaker):
    """Circuit breaker for Ray runtime operations"""

    async def execute_with_protection(self, operation):
        """Execute Ray operations with circuit breaker protection"""
        return await self._execute_with_circuit_breaker(operation)
```

#### **Step 3: Docker Configuration**
```yaml
# docker-compose.yml (ADD NEW SERVICE)
services:
  ray-head:
    image: rayproject/ray:latest
    container_name: xnai_ray_head
    command: ["ray", "start", "--head", "--port=6379", "--dashboard-host=0.0.0.0"]
    ports:
      - "8265:8265"  # Ray dashboard
      - "6379:6379"  # Ray port
    volumes:
      - ray_data:/tmp/ray
    networks:
      - xnai_network

  ray-worker:
    image: rayproject/ray:latest
    depends_on:
      - ray-head
    command: ["ray", "start", "--address=ray-head:6379"]
    deploy:
      replicas: 3  # Scale as needed
    volumes:
      - ray_data:/tmp/ray
    networks:
      - xnai_network

volumes:
  ray_data:
    driver: local
```

### **Testing & Validation:**
```python
# Test Ray cluster initialization
from app.XNAi_rag_app.ray_runtime import RayRuntimeManager

runtime = RayRuntimeManager(num_cpus=8, num_gpus=1)
resources = await runtime.initialize_cluster()
print(f"Ray cluster resources: {resources}")

# Test distributed processing
tasks = [{"type": "rag", "data": "..."} for _ in range(10)]
results = await runtime.scale_ai_workload(tasks)
print(f"Processed {len(results)} tasks")
```

---

## 1.3 🔐 **AI MODEL WATERMARKING SYSTEM**

### **Current Status:**
- Research complete, implementation needed
- Required for content provenance and compliance
- Essential for enterprise deployments

### **Implementation Steps:**

#### **Step 1: Watermarking Engine**
```python
# app/XNAi_rag_app/watermarking.py (NEW FILE)

import hashlib
import json
from datetime import datetime
from typing import Dict, Any, Optional
import uuid

class AIWatermarkingEngine:
    """AI Model Watermarking for Content Provenance"""

    def __init__(self, secret_key: str):
        self.secret_key = secret_key

    def generate_watermark(self, content: str, metadata: Dict[str, Any]) -> str:
        """Generate unique watermark for AI-generated content"""
        watermark_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "content_hash": hashlib.sha256(content.encode()).hexdigest(),
            "model_version": metadata.get("model_version"),
            "request_id": str(uuid.uuid4()),
            "organization": metadata.get("organization", "Xoe-NovAi"),
            "compliance_level": "GDPR_SOC2_COMPLIANT"
        }

        # Create cryptographic watermark
        watermark_string = json.dumps(watermark_data, sort_keys=True)
        watermark_hash = hashlib.sha256(
            (watermark_string + self.secret_key).encode()
        ).hexdigest()

        return f"XNWM-{watermark_hash[:16]}"  # Xoe-NovAi WaterMark

    def embed_watermark(self, content: str, watermark: str) -> str:
        """Embed watermark invisibly in content"""
        # Implement invisible watermarking technique
        # Options: zero-width characters, metadata embedding, etc.
        return content + f"<!-- {watermark} -->"

    def verify_watermark(self, content: str) -> Optional[Dict[str, Any]]:
        """Verify and extract watermark information"""
        # Extract and validate watermark
        pass

    def audit_watermark(self, content: str) -> Dict[str, Any]:
        """Comprehensive watermark audit for compliance"""
        return {
            "has_watermark": self._check_watermark_presence(content),
            "watermark_valid": self._validate_watermark_integrity(content),
            "compliance_status": "VERIFIED" if self.verify_watermark(content) else "UNVERIFIED",
            "audit_timestamp": datetime.utcnow().isoformat()
        }
```

#### **Step 2: Integration with RAG Pipeline**
```python
# app/XNAi_rag_app/main.py (UPDATE)

from app.XNAi_rag_app.watermarking import AIWatermarkingEngine

class RAGApplication:
    def __init__(self):
        self.watermarking = AIWatermarkingEngine(
            secret_key=os.getenv("WATERMARK_SECRET_KEY", "default-key")
        )

    async def process_query(self, query: str) -> Dict[str, Any]:
        """Process RAG query with watermarking"""
        # Existing RAG logic...

        # Generate and embed watermark
        metadata = {
            "model_version": "gemma-3-4b-it",
            "query_timestamp": datetime.utcnow().isoformat(),
            "processing_node": socket.gethostname()
        }

        watermark = self.watermarking.generate_watermark(response, metadata)
        watermarked_response = self.watermarking.embed_watermark(response, watermark)

        return {
            "response": watermarked_response,
            "watermark": watermark,
            "audit_info": self.watermarking.audit_watermark(watermarked_response)
        }
```

#### **Step 3: Compliance Monitoring**
```python
# app/XNAi_rag_app/compliance_monitor.py (NEW FILE)

class ComplianceMonitor:
    """Monitor AI content compliance and watermarking"""

    def __init__(self, watermarking_engine: AIWatermarkingEngine):
        self.watermarking = watermarking_engine
        self.compliance_log = []

    async def monitor_content_compliance(self, content: str) -> Dict[str, Any]:
        """Monitor content for compliance requirements"""
        audit_result = self.watermarking.audit_watermark(content)

        compliance_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "content_hash": hashlib.sha256(content.encode()).hexdigest(),
            "audit_result": audit_result,
            "gdpr_compliant": audit_result["compliance_status"] == "VERIFIED",
            "soc2_compliant": self._check_soc2_compliance(content)
        }

        self.compliance_log.append(compliance_record)
        return compliance_record
```

### **Testing & Validation:**
```python
# Test watermarking functionality
watermarking = AIWatermarkingEngine("test-key")

content = "This is AI-generated content"
metadata = {"model_version": "gemma-3-4b-it"}

watermark = watermarking.generate_watermark(content, metadata)
watermarked_content = watermarking.embed_watermark(content, watermark)

audit = watermarking.audit_watermark(watermarked_content)
print(f"Watermark audit: {audit}")
assert audit["compliance_status"] == "VERIFIED"
```

---

## 1.4 ✅ **SYSTEM HEALTH VALIDATION**

### **Implementation Steps:**

#### **Step 1: Comprehensive Health Checks**
```python
# app/XNAi_rag_app/healthcheck.py (ENHANCE)

class ComprehensiveHealthCheck:
    """Enterprise-grade system health validation"""

    async def run_full_system_health_check(self) -> Dict[str, Any]:
        """Complete system health assessment"""
        return {
            "docker_services": await self._check_docker_services(),
            "ray_cluster": await self._check_ray_cluster(),
            "watermarking": await self._check_watermarking_system(),
            "circuit_breakers": await self._check_circuit_breakers(),
            "performance": await self._run_performance_tests(),
            "security": await self._run_security_validation(),
            "compliance": await self._check_compliance_status()
        }
```

#### **Step 2: End-to-End Integration Testing**
```python
# tests/test_end_to_end_integration.py (NEW FILE)

class TestEndToEndIntegration:
    """Complete system integration testing"""

    async def test_full_ai_pipeline(self):
        """Test complete AI pipeline from query to response"""
        # Test Ray distributed processing
        # Test watermarking integration
        # Test circuit breaker protection
        # Test performance under load
        pass

    async def test_system_resilience(self):
        """Test system resilience and failover"""
        # Test service degradation scenarios
        # Test automatic recovery mechanisms
        # Test data consistency across failures
        pass
```

#### **Step 3: Performance Benchmarking**
```python
# scripts/performance_benchmark_phase1.py (NEW FILE)

class Phase1PerformanceBenchmark:
    """Performance benchmarking for Phase 1 completion"""

    async def run_comprehensive_benchmark(self) -> Dict[str, Any]:
        """Complete performance assessment"""
        return {
            "build_performance": await self._benchmark_build_times(),
            "ai_processing": await self._benchmark_ai_throughput(),
            "watermarking_overhead": await self._benchmark_watermarking(),
            "ray_scaling": await self._benchmark_ray_scaling(),
            "system_stability": await self._benchmark_system_stability()
        }
```

---

## 📊 **PHASE 1 SUCCESS METRICS**

### **Completion Criteria:**
- ✅ **Docker Build System:** All containers build and start without errors
- ✅ **Ray Runtime:** Distributed AI processing functional across multiple nodes
- ✅ **Watermarking:** All AI outputs properly watermarked and verifiable
- ✅ **System Health:** 100% of health checks passing, end-to-end tests successful

### **Performance Targets:**
- **Build Time:** < 3 minutes (down from current issues)
- **AI Throughput:** > 50 tokens/second with Ray scaling
- **Watermarking Overhead:** < 1% performance impact
- **System Availability:** 99.9% uptime during testing

### **Quality Gates:**
- **Security:** Zero critical vulnerabilities
- **Compliance:** GDPR/SOC2 compliance verified
- **Testing:** 95%+ test coverage maintained
- **Documentation:** All new features documented

---

## 🚨 **RISK MITIGATION**

### **Critical Risks:**
1. **Docker Build Failures:** Have traditional Docker approach ready as fallback
2. **Ray Integration Issues:** Maintain single-node capability as backup
3. **Watermarking Performance:** Implement optional watermarking for high-throughput scenarios
4. **System Instability:** Comprehensive rollback procedures for all changes

### **Contingency Plans:**
- **Docker Issues:** Pre-built container images as emergency deployment option
- **Ray Problems:** Graceful degradation to single-node processing
- **Watermarking Issues:** Delayed implementation with compliance waivers
- **System Failures:** Complete environment rollback capabilities

---

## 📋 **PHASE 1 IMPLEMENTATION CHECKLIST**

### **Week 1 Tasks:**
- [ ] **Day 1-2:** Docker build system overhaul completed
- [ ] **Day 3-4:** Ray runtime basic integration functional
- [ ] **Day 5-7:** AI watermarking system implemented and tested

### **Week 2 Tasks:**
- [ ] **Day 8-10:** Complete system integration testing
- [ ] **Day 11-12:** Performance benchmarking and optimization
- [ ] **Day 13-14:** Production deployment validation

### **Deliverables:**
- [ ] Working Docker build system (no sudo required)
- [ ] Ray AI runtime with multi-node scaling
- [ ] AI watermarking system with compliance verification
- [ ] Complete system health validation report
- [ ] Performance benchmarks meeting targets
- [ ] Updated documentation for all new features

---

**Phase 1 Lead:** Docker & Infrastructure Team  
**Timeline:** Week 1-2 (January 20-31, 2026)  
**Success Criteria:** All deployment blockers resolved, system fully operational  
**Next Phase:** Performance & Optimization Enhancements
