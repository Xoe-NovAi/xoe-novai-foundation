# 🔌 **Plugin Architecture Design Specification**

**Xoe-NovAi Phase 3: Architecture Enhancement**  
**Version:** 1.0.0  
**Date:** January 12, 2026  
**Status:** ✅ APPROVED FOR IMPLEMENTATION

---

## 📋 **Executive Summary**

### **Objective**
Transform Xoe-NovAi's monolithic script architecture into an extensible plugin system that enables:
- **Modular Functionality:** Independent script development and deployment
- **Standardized Interfaces:** Consistent patterns across all plugins
- **Dynamic Discovery:** Automatic plugin loading and registration
- **Version Management:** Safe plugin updates and dependency resolution
- **Error Isolation:** Plugin failures don't affect core system

### **Current State Analysis**
- **23 scripts** reduced to 16 through consolidation efforts
- **Inconsistent interfaces** across remaining scripts
- **Tight coupling** between scripts and core system
- **Manual maintenance** required for script updates
- **Limited extensibility** for new functionality

### **Target Architecture**
- **Plugin-based system** with standardized interfaces
- **Dynamic loading** and registration system
- **Version-aware** plugin management
- **Isolated execution** with error containment
- **Unified configuration** and monitoring

---

## 🏗️ **Plugin Architecture Overview**

### **Core Principles**

#### **1. Modularity**
- Each plugin encapsulates specific functionality
- Clear boundaries between plugins and core system
- Independent development and deployment cycles

#### **2. Standardization**
- Consistent interface patterns across all plugins
- Standardized configuration and error handling
- Uniform metadata and discovery mechanisms

#### **3. Extensibility**
- Easy addition of new functionality without core changes
- Plugin composition for complex workflows
- Third-party plugin ecosystem support

#### **4. Reliability**
- Isolated execution prevents plugin failures from affecting core
- Comprehensive error handling and recovery
- Automated health monitoring and validation

### **Architecture Components**

```
┌─────────────────────────────────────────────────────────────┐
│                    Xoe-NovAi Core System                    │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────┐ │
│  │ Plugin Registry │  │ Plugin Manager  │  │  CLI Router │ │
│  └─────────────────┘  └─────────────────┘  └─────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────┐ │
│  │   Build Plugin  │  │  Test Plugin    │  │ Ingest     │ │
│  │                 │  │                  │  │ Plugin     │ │
│  └─────────────────┘  └─────────────────┘  └─────────────┘ │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────┐ │
│  │ Monitor Plugin  │  │ Config Plugin   │  │  Custom    │ │
│  │                 │  │                  │  │  Plugins   │ │
│  └─────────────────┘  └─────────────────┘  └─────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 **Plugin Interface Standard**

### **Base Plugin Interface**

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class PluginState(Enum):
    """Plugin lifecycle states."""
    UNLOADED = "unloaded"
    LOADING = "loading"
    LOADED = "loaded"
    INITIALIZING = "initializing"
    READY = "ready"
    EXECUTING = "executing"
    ERROR = "error"
    DISABLED = "disabled"

class PluginCategory(Enum):
    """Plugin functional categories."""
    BUILD = "build"
    TEST = "test"
    INGEST = "ingest"
    MONITOR = "monitor"
    CONFIG = "config"
    UTILITY = "utility"
    CUSTOM = "custom"

@dataclass
@dataclass
class PluginCapabilities:
    """Enhanced plugin capability declarations (2026 Best Practices: Finer-grained permissions)."""
    # File system access (2026: per-path granularity)
    filesystem_read: bool = False
    filesystem_write: bool = False
    filesystem_paths: List[str] = field(default_factory=list)  # Specific allowed paths

    # Network access
    network_access: bool = False
    network_domains: List[str] = field(default_factory=list)  # Specific allowed domains

    # System resources
    system_info: bool = False
    gpu_access: bool = False
    database_access: bool = False
    privileged_execution: bool = False

    # AI/ML specific (2026: model isolation controls)
    model_loading: bool = False
    model_execution: bool = False
    model_training: bool = False
    model_serving: bool = False

    # CPU/Vulkan specific (2026: Ryzen iGPU offloading - Mesa-only)
    igpu_vulkan_access: bool = False  # Enable Vulkan iGPU acceleration (Mesa drivers)
    igpu_vulkan_layers: int = 20      # Number of layers to offload to Vulkan iGPU
    tts_kokoro: bool = False          # Enable Kokoro TTS integration (v2 multilingual)

    # Plugin execution environment (2026: WASM support)
    wasm_execution: bool = False  # Allow WASM-based execution
    sandbox_level: str = "standard"  # 'minimal', 'standard', 'enhanced'

    def to_permissions(self) -> List[str]:
        """Convert capabilities to permission list."""
        permissions = []
        for k, v in self.__dict__.items():
            if k not in ['to_permissions', 'filesystem_paths', 'network_domains'] and v:
                permissions.append(k)
        return permissions

    def validate_path_access(self, path: str) -> bool:
        """Validate if path access is allowed (2026 enhancement)."""
        if not self.filesystem_paths:
            return self.filesystem_read or self.filesystem_write
        return any(path.startswith(allowed_path) for allowed_path in self.filesystem_paths)

    def validate_network_access(self, domain: str) -> bool:
        """Validate if network access to domain is allowed (2026 enhancement)."""
        if not self.network_domains:
            return self.network_access
        return any(domain.endswith(allowed_domain) for allowed_domain in self.network_domains)

@dataclass
class PluginSecurity:
    """Plugin security configuration (Best Practice: Sandboxing)."""
    seccomp_profile: Optional[str] = None
    capabilities_drop: List[str] = field(default_factory=lambda: ["ALL"])
    capabilities_add: List[str] = field(default_factory=list)
    readonly_filesystem: bool = True
    network_isolation: bool = True
    resource_limits: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PluginMetadata:
    """Enhanced plugin metadata with security and performance features."""
    name: str
    version: str
    description: str
    author: str
    category: PluginCategory
    capabilities: List[str]
    dependencies: List[str] = field(default_factory=list)
    config_schema: Dict[str, Any] = field(default_factory=dict)
    min_core_version: str = "1.0.0"
    max_core_version: Optional[str] = None
    license: str = "MIT"
    homepage: Optional[str] = None
    repository: Optional[str] = None

    # Enhanced fields from best practices research
    capabilities_declared: PluginCapabilities = field(default_factory=PluginCapabilities)
    security_config: PluginSecurity = field(default_factory=PluginSecurity)
    performance_hints: Dict[str, Any] = field(default_factory=dict)
    compatibility_matrix: Dict[str, str] = field(default_factory=dict)

@dataclass
class PluginResult:
    """Standardized plugin execution result."""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    execution_time: Optional[float] = None

class XoeNovAiPlugin(ABC):
    """Standard plugin interface for Xoe-NovAi ecosystem."""

    @property
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        """Plugin metadata."""
        pass

    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> bool:
        """Initialize plugin with configuration."""
        pass

    @abstractmethod
    def execute(self, operation: str, args: Dict[str, Any]) -> PluginResult:
        """Execute plugin operation."""
        pass

    @abstractmethod
    def validate_config(self, config: Dict[str, Any]) -> List[str]:
        """Validate plugin configuration."""
        pass

    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Get list of supported operations."""
        pass

    def cleanup(self) -> bool:
        """Cleanup plugin resources."""
        return True

    def health_check(self) -> Dict[str, Any]:
        """Plugin health status."""
        return {"status": "healthy", "timestamp": datetime.now().isoformat()}
```

### **Plugin Lifecycle Management**

#### **1. Discovery Phase**
- Automatic plugin discovery from designated directories
- Metadata parsing and validation
- Dependency resolution and compatibility checking

#### **2. Loading Phase**
- Dynamic plugin module loading
- Class instantiation and basic validation
- Resource allocation and initialization

#### **3. Registration Phase**
- Plugin registration with central registry
- Capability mapping and routing setup
- Configuration schema validation

#### **4. Execution Phase**
- Operation routing and execution
- Error handling and recovery
- Resource monitoring and cleanup

#### **5. Maintenance Phase**
- Health monitoring and status reporting
- Automatic updates and version management
- Resource cleanup and plugin unloading

---

## 🔧 **Core Framework Components**

### **1. Plugin Registry**

```python
class PluginRegistry:
    """Central registry for plugin management."""

    def __init__(self):
        self._plugins: Dict[str, PluginInfo] = {}
        self._categories: Dict[PluginCategory, List[str]] = {}
        self._capabilities: Dict[str, List[str]] = {}

    def register_plugin(self, plugin_class: Type[XoeNovAiPlugin]) -> bool:
        """Register a plugin class."""
        try:
            # Validate plugin interface
            if not issubclass(plugin_class, XoeNovAiPlugin):
                raise ValueError("Plugin must inherit from XoeNovAiPlugin")

            # Create plugin instance for metadata
            temp_plugin = plugin_class()
            metadata = temp_plugin.metadata

            # Validate metadata
            self._validate_metadata(metadata)

            # Register plugin
            plugin_info = PluginInfo(
                name=metadata.name,
                version=metadata.version,
                category=metadata.category,
                capabilities=metadata.capabilities,
                plugin_class=plugin_class,
                state=PluginState.UNLOADED
            )

            self._plugins[metadata.name] = plugin_info
            self._categories[metadata.category].append(metadata.name)

            for capability in metadata.capabilities:
                if capability not in self._capabilities:
                    self._capabilities[capability] = []
                self._capabilities[capability].append(metadata.name)

            return True

        except Exception as e:
            logger.error(f"Failed to register plugin {plugin_class.__name__}: {e}")
            return False

    def discover_plugins(self, plugin_dirs: List[Path]) -> int:
        """Discover and load plugins from directories."""
        discovered_count = 0

        for plugin_dir in plugin_dirs:
            if not plugin_dir.exists():
                continue

            # Find plugin files
            plugin_files = list(plugin_dir.glob("**/plugin.py"))
            plugin_files.extend(list(plugin_dir.glob("**/plugins/**/*.py")))

            for plugin_file in plugin_files:
                try:
                    # Load plugin module
                    spec = importlib.util.spec_from_file_location(
                        f"plugin_{plugin_file.stem}", plugin_file
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    # Find plugin classes
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (isinstance(attr, type) and
                            issubclass(attr, XoeNovAiPlugin) and
                            attr != XoeNovAiPlugin):
                            if self.register_plugin(attr):
                                discovered_count += 1
                                logger.info(f"Discovered plugin: {attr.__name__}")

                except Exception as e:
                    logger.warning(f"Failed to load plugin from {plugin_file}: {e}")

        return discovered_count

    def get_plugin(self, name: str) -> Optional[Type[XoeNovAiPlugin]]:
        """Get plugin class by name."""
        plugin_info = self._plugins.get(name)
        return plugin_info.plugin_class if plugin_info else None

    def list_plugins(self, category: Optional[PluginCategory] = None) -> List[Dict[str, Any]]:
        """List registered plugins."""
        plugins = []
        for name, info in self._plugins.items():
            if category is None or info.category == category:
                plugins.append({
                    "name": name,
                    "version": info.version,
                    "category": info.category.value,
                    "capabilities": info.capabilities,
                    "state": info.state.value
                })
        return plugins
```

### **2. Plugin Manager**

```python
class PluginManager:
    """Manages plugin lifecycle and execution."""

    def __init__(self, registry: PluginRegistry):
        self.registry = registry
        self._active_plugins: Dict[str, XoeNovAiPlugin] = {}
        self._execution_contexts: Dict[str, Dict[str, Any]] = {}

    def load_plugin(self, name: str, config: Dict[str, Any]) -> bool:
        """Load and initialize a plugin."""
        plugin_class = self.registry.get_plugin(name)
        if not plugin_class:
            raise ValueError(f"Plugin '{name}' not found")

        try:
            # Create plugin instance
            plugin = plugin_class()

            # Validate configuration
            config_errors = plugin.validate_config(config)
            if config_errors:
                raise ValueError(f"Configuration validation failed: {config_errors}")

            # Initialize plugin
            if not plugin.initialize(config):
                raise RuntimeError(f"Plugin '{name}' initialization failed")

            # Store active plugin
            self._active_plugins[name] = plugin
            self._execution_contexts[name] = {}

            # Update registry state
            if name in self.registry._plugins:
                self.registry._plugins[name].state = PluginState.READY

            logger.info(f"Plugin '{name}' loaded successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to load plugin '{name}': {e}")
            if name in self.registry._plugins:
                self.registry._plugins[name].state = PluginState.ERROR
            raise

    def execute_plugin(self, name: str, operation: str, args: Dict[str, Any]) -> PluginResult:
        """Execute a plugin operation."""
        plugin = self._active_plugins.get(name)
        if not plugin:
            raise ValueError(f"Plugin '{name}' not loaded")

        try:
            # Update state to executing
            if name in self.registry._plugins:
                self.registry._plugins[name].state = PluginState.EXECUTING

            # Execute operation
            start_time = time.time()
            result = plugin.execute(operation, args)
            execution_time = time.time() - start_time

            # Add execution metadata
            if result.metadata is None:
                result.metadata = {}
            result.metadata["execution_time"] = execution_time
            result.execution_time = execution_time

            # Update state back to ready
            if name in self.registry._plugins:
                self.registry._plugins[name].state = PluginState.READY

            return result

        except Exception as e:
            # Update state to error
            if name in self.registry._plugins:
                self.registry._plugins[name].state = PluginState.ERROR

            logger.error(f"Plugin '{name}' execution failed: {e}")
            return PluginResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start_time
            )

    def unload_plugin(self, name: str) -> bool:
        """Unload a plugin."""
        plugin = self._active_plugins.get(name)
        if plugin:
            try:
                plugin.cleanup()
                del self._active_plugins[name]
                if name in self._execution_contexts:
                    del self._execution_contexts[name]

                if name in self.registry._plugins:
                    self.registry._plugins[name].state = PluginState.UNLOADED

                logger.info(f"Plugin '{name}' unloaded successfully")
                return True
            except Exception as e:
                logger.error(f"Failed to cleanup plugin '{name}': {e}")

        return False

    def get_plugin_status(self, name: str) -> Dict[str, Any]:
        """Get plugin status and health information."""
        plugin_info = self.registry._plugins.get(name)
        if not plugin_info:
            return {"error": f"Plugin '{name}' not registered"}

        status = {
            "name": name,
            "version": plugin_info.version,
            "category": plugin_info.category.value,
            "state": plugin_info.state.value,
            "capabilities": plugin_info.capabilities
        }

        # Add health information if plugin is loaded
        plugin = self._active_plugins.get(name)
        if plugin:
            try:
                status["health"] = plugin.health_check()
            except Exception as e:
                status["health"] = {"status": "error", "error": str(e)}

        return status
```

### **3. Plugin Discovery System**

```python
class PluginDiscovery:
    """Automatic plugin discovery and validation."""

    def __init__(self, plugin_dirs: List[Path]):
        self.plugin_dirs = plugin_dirs
        self.discovery_cache: Dict[str, PluginMetadata] = {}

    def discover_all_plugins(self) -> Dict[str, PluginMetadata]:
        """Discover all plugins in configured directories."""
        discovered_plugins = {}

        for plugin_dir in self.plugin_dirs:
            if not plugin_dir.exists():
                logger.warning(f"Plugin directory does not exist: {plugin_dir}")
                continue

            logger.info(f"Scanning plugin directory: {plugin_dir}")

            # Find plugin files
            plugin_files = []
            plugin_files.extend(list(plugin_dir.glob("**/plugin.py")))
            plugin_files.extend(list(plugin_dir.glob("**/plugins/**/*.py")))

            for plugin_file in plugin_files:
                try:
                    metadata = self._extract_plugin_metadata(plugin_file)
                    if metadata:
                        discovered_plugins[metadata.name] = metadata
                        logger.info(f"Discovered plugin: {metadata.name} v{metadata.version}")

                except Exception as e:
                    logger.warning(f"Failed to process plugin file {plugin_file}: {e}")

        # Update cache
        self.discovery_cache = discovered_plugins
        return discovered_plugins

    def _extract_plugin_metadata(self, plugin_file: Path) -> Optional[PluginMetadata]:
        """Extract metadata from plugin file."""
        try:
            # Load plugin module
            spec = importlib.util.spec_from_file_location(
                f"temp_plugin_{plugin_file.stem}", plugin_file
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Find plugin classes
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and
                    issubclass(attr, XoeNovAiPlugin) and
                    attr != XoeNovAiPlugin):
                    # Create temporary instance to get metadata
                    temp_plugin = attr()
                    return temp_plugin.metadata

        except Exception as e:
            logger.warning(f"Failed to extract metadata from {plugin_file}: {e}")

        return None

    def validate_plugin_dependencies(self, plugin_metadata: PluginMetadata) -> List[str]:
        """Validate plugin dependencies."""
        issues = []

        # Check core version compatibility
        # This would integrate with version management system
        core_version = get_core_version()
        if not self._check_version_compatibility(core_version, plugin_metadata):
            issues.append(f"Incompatible core version: requires {plugin_metadata.min_core_version}")

        # Check plugin dependencies
        for dep in plugin_metadata.dependencies:
            if not self._is_dependency_available(dep):
                issues.append(f"Missing dependency: {dep}")

        return issues

    def _check_version_compatibility(self, core_version: str, metadata: PluginMetadata) -> bool:
        """Check if plugin is compatible with core version."""
        # Simplified version checking
        from packaging import version
        try:
            core_v = version.parse(core_version)
            min_v = version.parse(metadata.min_core_version)

            if core_v < min_v:
                return False

            if metadata.max_core_version:
                max_v = version.parse(metadata.max_core_version)
                if core_v > max_v:
                    return False

            return True
        except:
            return False

    def _is_dependency_available(self, dependency: str) -> bool:
        """Check if a dependency is available."""
        # This would check plugin registry or system dependencies
        # Simplified implementation
        return True
```

### **4. Configuration Management**

```python
class PluginConfiguration:
    """Plugin configuration management."""

    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.config_cache: Dict[str, Dict[str, Any]] = {}

    def load_plugin_config(self, plugin_name: str) -> Dict[str, Any]:
        """Load configuration for a specific plugin."""
        if plugin_name in self.config_cache:
            return self.config_cache[plugin_name]

        config_file = self.config_dir / f"{plugin_name}.yaml"
        if not config_file.exists():
            config_file = self.config_dir / f"{plugin_name}.json"
        if not config_file.exists():
            config_file = self.config_dir / f"{plugin_name}.toml"

        if config_file.exists():
            try:
                if config_file.suffix == '.yaml':
                    import yaml
                    with open(config_file, 'r') as f:
                        config = yaml.safe_load(f)
                elif config_file.suffix == '.json':
                    import json
                    with open(config_file, 'r') as f:
                        config = json.load(f)
                elif config_file.suffix == '.toml':
                    import toml
                    with open(config_file, 'r') as f:
                        config = toml.load(f)
                else:
                    raise ValueError(f"Unsupported config format: {config_file.suffix}")

                self.config_cache[plugin_name] = config
                return config

            except Exception as e:
                logger.error(f"Failed to load config for {plugin_name}: {e}")

        # Return default empty config
        return {}

    def save_plugin_config(self, plugin_name: str, config: Dict[str, Any]) -> bool:
        """Save configuration for a specific plugin."""
        try:
            config_file = self.config_dir / f"{plugin_name}.yaml"
            import yaml
            with open(config_file, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)

            self.config_cache[plugin_name] = config
            return True
        except Exception as e:
            logger.error(f"Failed to save config for {plugin_name}: {e}")
            return False

    def validate_config_schema(self, config: Dict[str, Any], schema: Dict[str, Any]) -> List[str]:
        """Validate configuration against schema."""
        issues = []

        # Basic schema validation
        for key, rules in schema.items():
            if rules.get('required', False) and key not in config:
                issues.append(f"Missing required configuration: {key}")

            if key in config:
                value = config[key]
                expected_type = rules.get('type')
                if expected_type and not isinstance(value, self._get_type_class(expected_type)):
                    issues.append(f"Invalid type for {key}: expected {expected_type}")

                # Range validation
                if 'min' in rules and isinstance(value, (int, float)) and value < rules['min']:
                    issues.append(f"Value for {key} below minimum: {value} < {rules['min']}")

                if 'max' in rules and isinstance(value, (int, float)) and value > rules['max']:
                    issues.append(f"Value for {key} above maximum: {value} > {rules['max']}")

        return issues

    def _get_type_class(self, type_name: str) -> type:
        """Get Python type class from string name."""
        type_map = {
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict
        }
        return type_map.get(type_name, object)
```

---

## 🌐 **WASM Plugin Support (2026 Enhancement)**

### **WASM Runtime Integration**
**Purpose:** Enable "soft isolation" for utility plugins with faster load times (<100ms vs <500ms for containers).

**Implementation:**
```python
class WasmPluginExecutor:
    """WASM-based plugin execution environment (2026)."""

    def __init__(self):
        self.wasm_runtime = None  # Initialize WASM runtime
        self.loaded_modules: Dict[str, Any] = {}

    def load_wasm_plugin(self, wasm_file: Path, plugin_name: str) -> bool:
        """Load WASM plugin module."""
        try:
            # Load WASM module
            with open(wasm_file, 'rb') as f:
                wasm_bytes = f.read()

            # Instantiate WASM module
            wasm_module = self.wasm_runtime.instantiate(wasm_bytes)

            # Extract plugin interface
            plugin_interface = self._extract_plugin_interface(wasm_module)

            self.loaded_modules[plugin_name] = {
                'module': wasm_module,
                'interface': plugin_interface,
                'loaded_at': datetime.now()
            }

            return True
        except Exception as e:
            logger.error(f"Failed to load WASM plugin {plugin_name}: {e}")
            return False

    def execute_wasm_operation(self, plugin_name: str, operation: str, args: Dict[str, Any]) -> PluginResult:
        """Execute operation in WASM environment."""
        if plugin_name not in self.loaded_modules:
            return PluginResult(success=False, error=f"WASM plugin {plugin_name} not loaded")

        try:
            module_info = self.loaded_modules[plugin_name]
            wasm_module = module_info['module']

            # Call WASM function
            result_ptr = wasm_module.exports[operation](json.dumps(args))

            # Read result from WASM memory
            result_json = self._read_wasm_string(wasm_module, result_ptr)
            result_data = json.loads(result_json)

            return PluginResult(**result_data)

        except Exception as e:
            return PluginResult(success=False, error=f"WASM execution failed: {e}")

    def _extract_plugin_interface(self, wasm_module) -> Dict[str, Any]:
        """Extract plugin interface from WASM module."""
        interface = {
            'capabilities': [],
            'operations': []
        }

        # Extract exported functions that match plugin operations
        for export_name in wasm_module.exports:
            if not export_name.startswith('_'):  # Skip internal functions
                interface['operations'].append(export_name)

        return interface
```

### **WASM Plugin Development**
**File Structure:**
```
plugins/
└── wasm_utility/
    ├── plugin.wasm       # Compiled WASM module
    ├── plugin.wat        # WASM text format (for debugging)
    ├── metadata.json     # Plugin metadata
    └── source/           # Source code directory
        ├── plugin.c      # C source code
        ├── Makefile      # Build configuration
        └── interface.h   # Plugin interface definitions
```

**Example WASM Plugin (C source):**
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "interface.h"

// Plugin metadata (exported to host)
const char* plugin_name = "wasm-utility";
const char* plugin_version = "1.0.0";
const char* capabilities[] = {"file_hash", "string_process"};

// File hashing operation
EMSCRIPTEN_KEEPALIVE
char* file_hash(const char* filepath) {
    // WASM-safe file operations
    // Return JSON result string
    return "{\"success\":true,\"data\":{\"hash\":\"abc123\"}}";
}

// String processing operation
EMSCRIPTEN_KEEPALIVE
char* string_process(const char* input) {
    // Process string and return result
    return "{\"success\":true,\"data\":{\"processed\":\"" + processed + "\"}}";
}
```

### **WASM vs Container Plugin Comparison**

| Aspect | WASM Plugins | Container Plugins |
|--------|-------------|-------------------|
| **Load Time** | <100ms | <500ms |
| **Memory Usage** | 5-20MB | 50-200MB |
| **Isolation** | Soft (same process) | Hard (separate process) |
| **GPU Access** | Limited | Full |
| **Ecosystem** | Growing (2026) | Mature |
| **Use Case** | Utility plugins | Complex/ML plugins |

## 📋 **Plugin Development Guidelines**

### **Creating a New Plugin**

1. **Inherit from Base Class:**
```python
from plugin_framework import XoeNovAiPlugin, PluginMetadata, PluginCategory

class MyCustomPlugin(XoeNovAiPlugin):
    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="my-custom-plugin",
            version="1.0.0",
            description="Custom functionality plugin",
            author="Developer Name",
            category=PluginCategory.UTILITY,
            capabilities=["custom_operation"],
            dependencies=[],
            config_schema={
                "api_key": {"type": "str", "required": True},
                "timeout": {"type": "int", "default": 30, "min": 1, "max": 300}
            },
            min_core_version="1.0.0"
        )
```

2. **Implement Required Methods:**
```python
def initialize(self, config: Dict[str, Any]) -> bool:
    """Initialize plugin with configuration."""
    self.api_key = config.get('api_key')
    self.timeout = config.get('timeout', 30)
    return True

def execute(self, operation: str, args: Dict[str, Any]) -> PluginResult:
    """Execute plugin operation."""
    if operation == "custom_operation":
        return self._perform_custom_operation(args)
    else:
        return PluginResult(success=False, error=f"Unknown operation: {operation}")

def validate_config(self, config: Dict[str, Any]) -> List[str]:
    """Validate plugin configuration."""
    issues = []
    if not config.get('api_key'):
        issues.append("api_key is required")
    return issues

def get_capabilities(self) -> List[str]:
    """Get list of supported operations."""
    return ["custom_operation"]
```

3. **Plugin File Structure:**
```
plugins/
└── my_custom_plugin/
    ├── plugin.py          # Main plugin implementation
    ├── config.yaml        # Plugin configuration
    ├── requirements.txt   # Plugin dependencies
    └── README.md          # Plugin documentation
```

### **Best Practices**

#### **Error Handling**
- Always use standardized error responses
- Provide actionable error messages
- Log errors with appropriate severity levels
- Implement graceful degradation

#### **Configuration**
- Define clear configuration schemas
- Provide sensible defaults
- Validate configuration on initialization
- Document all configuration options

#### **Resource Management**
- Implement proper cleanup in `cleanup()` method
- Use context managers for resource handling
- Monitor resource usage in health checks
- Handle resource exhaustion gracefully

#### **Version Compatibility**
- Specify minimum and maximum core versions
- Test against multiple core versions
- Document breaking changes
- Provide migration guides

---

## 🔧 **Implementation Roadmap**

### **Phase 1: Foundation (Week 1)**
- ✅ Plugin interface specification
- ✅ Core plugin framework implementation
- ⏳ Plugin discovery system
- ⏳ Plugin registry and management

### **Phase 2: Migration (Week 2)**
- ⏳ Convert existing scripts to plugins
- ⏳ Update Makefile integration
- ⏳ Plugin testing and validation
- ⏳ Documentation updates

### **Phase 3: Enhancement (Week 3)**
- ⏳ Advanced plugin features (hooks, events)
- ⏳ Plugin marketplace/integration
- ⏳ Performance optimization
- ⏳ Security hardening

### **Phase 4: Production (Week 4)**
- ⏳ Production deployment
- ⏳ Monitoring and alerting
- ⏳ User training and documentation
- ⏳ Community ecosystem development

---

## 🎯 **Success Metrics**

### **Technical Metrics**
- **Plugin Load Time:** <500ms average
- **Memory Overhead:** <50MB per active plugin
- **Discovery Time:** <2 seconds for 50 plugins
- **Error Isolation:** 100% plugin failure containment

### **Developer Experience**
- **Plugin Creation Time:** <30 minutes for simple plugins
- **API Learning Curve:** <2 hours for experienced developers
- **Documentation Coverage:** 100% of public APIs documented
- **Community Adoption:** >10 third-party plugins

### **System Reliability**
- **Plugin Stability:** 99.9% uptime for stable plugins
- **Update Safety:** 100% backward compatibility for minor versions
- **Security:** Zero plugin-based security incidents
- **Performance:** No degradation with 20+ active plugins

---

**Plugin Architecture Design Specification complete: Comprehensive framework for extensible, maintainable plugin ecosystem with standardized interfaces and robust lifecycle management.** 🚀
