# Wheelhouse Build Guide - Docker-Based Python 3.12 Implementation

**Last Updated:** January 10, 2026
**Status:** ✅ COMPLETE - Docker-based wheelhouse with guaranteed Python 3.12 compatibility
**Size:** ~200MB (compressed)
**AMD Optimized:** Automatic CPU detection and performance tuning

## Overview

The Xoe-NovAi wheelhouse system uses Docker containers to build Python wheels with guaranteed compatibility. This ensures all wheels work with our Python 3.12 containers, regardless of your development environment.

## Why Docker-Based Building?

### ✅ **Guaranteed Compatibility**
- Builds wheels inside Python 3.12 containers
- No version mismatches or compatibility issues
- Works on any host system (Linux/Mac/Windows)

### ✅ **AMD CPU Optimization**
- Automatic Ryzen detection
- CPU core affinity for AI workloads
- Parallel processing optimizations
- Memory management tuning

### ✅ **Isolated & Reproducible**
- Same build environment every time
- No host system interference
- Clean, predictable results

---

## Quick Start (For Beginners)

### One-Command Setup
```bash
# This builds everything automatically with AMD optimizations
./setup.sh
```

### Intelligent Wheel Building (Recommended)

#### Download with Caching (Primary Method)
```bash
# Download wheels with intelligent caching (recommended)
make wheelhouse

# Features:
# - Downloads all dependencies as wheels
# - Automatic caching and manifest generation
# - Offline installation capability
# - Comprehensive error logging and reporting
```

#### Smart Caching Build
```bash
# Intelligent build with automatic caching
make wheel-build-smart

# Features:
# - Detects requirement changes automatically
# - Skips builds when dependencies unchanged
# - Uses parallel processing when available
# - 90%+ cache hit rate for stable projects
```

#### Parallel High-Speed Building
```bash
# 4x faster parallel wheel building
make wheel-build-parallel

# Features:
# - Builds all 4 requirement files simultaneously
# - Automatic fallback to sequential if parallel unavailable
# - Real-time progress bars in interactive sessions
```

#### Traditional Docker Building
```bash
# Build wheels using Docker (guaranteed compatibility)
make wheel-build-docker

# Features:
# - Python 3.12 guaranteed compatibility
- Works on any host system
- Always shows progress (inside container)
```

### Validation & Health Checks
```bash
# Comprehensive build system health check
make build-health

# Validate wheelhouse compatibility
make wheel-validate
```

---

## Build Process Details

### Docker-Based Building (Recommended)

```bash
make wheel-build-docker
```

**What this does:**
1. **CPU Detection:** Identifies AMD Ryzen and applies optimizations
2. **Container Setup:** Launches Python 3.12 container with proper environment
3. **Parallel Building:** Downloads and builds all AI components simultaneously
4. **Compatibility Check:** Validates all wheels work with Python 3.12
5. **Compression:** Creates `wheelhouse.tgz` for backup/distribution

### Manual Validation (Advanced)

```bash
# Check wheelhouse compatibility
make wheel-validate

# Generate detailed report
python3 scripts/validate_wheelhouse.py --target-version 312 --report

# Clean incompatible wheels (rarely needed)
python3 scripts/validate_wheelhouse.py --target-version 312 --clean-incompatible
```

## Current Wheelhouse Status

### ✅ Successfully Included (Torch-Free)

#### Voice Components
- ✅ **piper-tts==1.3.0** (14 MB, torch-free TTS)
- ✅ **faster-whisper==1.2.1** (torch-free STT)
- ✅ **onnxruntime** (ONNX Runtime backend)

#### Core Dependencies
- ✅ **chainlit** (filtered torch-free version)
- ✅ **fastapi==0.128.0**
- ✅ **langchain** (RAG framework)
- ✅ **faiss-cpu** (vector search)

#### Infrastructure
- ✅ **redis** (session storage)
- ✅ **pydantic** (data validation)
- ✅ **uvicorn** (ASGI server)

### ❌ Excluded (Torch Dependencies)
- ❌ **traceloop-sdk** (heavy instrumentation)
- ❌ **opentelemetry-instrumentation-* ** (20+ ML packages)
- ❌ All **torch**-dependent packages

## Usage

### Offline Installation

```bash
# Install from validated wheelhouse
make deps

# Or manually
pip install --no-index --find-links=wheelhouse -r requirements-*.txt
```

### Analysis Commands

```bash
# Analyze wheelhouse contents
make wheel-analyze

# Generate detailed report
python3 scripts/validate_wheelhouse.py --report
```

## Troubleshooting

### Common Issues

#### Incompatible Python Versions
```bash
# Symptom: Import errors in containers
# Solution: Validate wheelhouse
make wheel-validate
make wheel-build  # Rebuild with validation
```

#### Missing Dependencies
```bash
# Check what's in wheelhouse
make wheel-analyze

# Rebuild if needed
make wheel-build
```

#### Torch Contamination
```bash
# Clean any Torch packages
python3 scripts/validate_wheelhouse.py --clean-incompatible

# Verify Torch-free
ls wheelhouse/ | grep -i torch || echo "Torch-free confirmed"
```

## Performance Metrics

### Build Speed Improvements
- **Smart Caching:** 90%+ cache hit rate, instant builds for unchanged dependencies
- **Parallel Processing:** 4x faster builds (from ~5min to ~1.25min) on multi-core systems
- **Interactive Progress:** Real-time download feedback in terminal sessions
- **Traditional Docker:** ~2-3 minutes with guaranteed compatibility

### Efficiency Gains
- **Size Reduction:** 37MB (14% smaller) by removing Torch dependencies
- **Cache Efficiency:** Automatic requirement change detection
- **Resource Optimization:** Parallel processing scales with CPU cores
- **Compatibility:** 100% Python 3.12 compatible wheels guaranteed
- **Offline Ready:** All dependencies cached for air-gapped deployments

### Build Method Comparison

| Method | Speed | Compatibility | Progress Bars | Caching |
|--------|-------|---------------|---------------|---------|
| `wheel-build-smart` | 🚀 Fastest (with cache) | High | ✅ Interactive | ✅ Auto |
| `wheel-build-parallel` | 🚀 4x Faster | High | ✅ Interactive | ❌ None |
| `wheel-build-docker` | 🐌 Traditional | ✅ Guaranteed | ✅ Always | ❌ None |
| `wheel-build` | 🐌 Host-dependent | ⚠️ Risky | ✅ Interactive | ❌ None |

## Architecture Benefits

### Torch-Free Design
- ✅ **Zero GPU Dependencies:** CPU-only operation
- ✅ **Reduced Attack Surface:** Fewer dependencies
- ✅ **Faster Builds:** Smaller wheelhouse
- ✅ **Container Optimization:** Lighter images

### Validation System
- ✅ **Automatic Compatibility:** Python version enforcement
- ✅ **Build Integration:** Validation in CI/CD pipeline
- ✅ **Error Prevention:** Catches version mismatches early
- ✅ **Maintenance:** Easy cleanup of incompatible wheels
