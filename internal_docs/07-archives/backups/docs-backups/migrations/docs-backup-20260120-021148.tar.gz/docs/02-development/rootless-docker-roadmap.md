# 🔒 Rootless Docker SBOM Security Roadmap

**Complete Implementation Guide for Rootless Docker + SBOM Security**

**Date**: January 15, 2026
**Priority**: HIGH - Enterprise Security Foundation
**Success Criteria**: Zero critical vulnerabilities, <10% performance overhead, full rootless operation

---

## 📋 **Executive Summary**

This roadmap consolidates Claude's rootless Docker and SBOM implementation specifications with enterprise security requirements to provide a complete, actionable plan for achieving 100% rootless Docker with comprehensive security automation. The focus is on user namespaces, Syft/Trivy integration, GPU passthrough, and enterprise compliance while maintaining performance and functionality.

**Key Implementation Points:**
- **Rootless by Default**: User namespace isolation with security hardening
- **SBOM Automation**: Syft generation with Trivy vulnerability scanning
- **GPU Compatibility**: Maintain Vulkan acceleration in rootless environment
- **CI/CD Integration**: Automated security pipelines and compliance reporting
- **Enterprise Compliance**: SOC2/GDPR automation with audit trails

---

## 🏗️ **Current State Assessment**

### **Current Security State**
- **Container Security**: Non-root USER (1001:1001) but NOT fully rootless
- **SBOM Generation**: None - manual dependency tracking only
- **Vulnerability Scanning**: Basic dependency auditing
- **GPU Access**: Direct device access (requires rootless adaptation)
- **Compliance**: Basic security but no automated SBOM reporting

### **Current Integration Level: Partial**
- ✅ Basic non-root containerization established
- ✅ Security hardening foundations in place
- ❌ User namespace configuration missing
- ❌ SBOM generation not automated
- ❌ Vulnerability scanning not integrated
- ❌ GPU passthrough for rootless untested

---

## 📋 **Implementation Roadmap**

### **Phase 1: Rootless Foundation Setup (Week 1)**

#### **1.1 Docker Daemon Rootless Configuration**

**Objective**: Configure Docker daemon for rootless operation with user namespaces

**📁 File: `/etc/docker/daemon.json` (Host Configuration)**

**Current State** (if exists):
```json
{
  "data-root": "/var/lib/docker"
}
```

**Required Changes**:
```json
{
  "data-root": "/var/lib/docker",
  "userns-remap": "default",
  "no-new-privileges": true,
  "runtimes": {
    "nvidia": {
      "path": "nvidia-container-runtime",
      "runtimeArgs": []
    }
  },
  "default-runtime": "runc",
  "icc": false,
  "userland-proxy": false,
  "live-restore": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

**📁 File: `scripts/setup_rootless.sh` (Automation Script)**

**Create New File**:
```bash
#!/bin/bash
# ============================================================================
# Xoe-NovAi Rootless Docker Setup Script
# ============================================================================
# Purpose: Automate rootless Docker configuration for enterprise compliance
# Guide Reference: 06-rootless-docker-sbom.md
# Last Updated: 2026-01-14
# ============================================================================

set -euo pipefail

echo "🔒 Xoe-NovAi Rootless Docker Setup"
echo "===================================="

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "❌ This script must be run as root (use sudo)"
   exit 1
fi

# 1. Install prerequisites
echo "📦 Installing prerequisites..."
apt-get update
apt-get install -y \
    uidmap \
    dbus-user-session \
    fuse-overlayfs \
    slirp4netns

# 2. Configure user namespace mapping
echo "🔧 Configuring user namespaces..."
if ! grep -q "dockremap" /etc/subuid; then
    echo "dockremap:100000:65536" >> /etc/subuid
    echo "✅ Added subuid mapping"
else
    echo "⚠️ subuid mapping already exists"
fi

if ! grep -q "dockremap" /etc/subgid; then
    echo "dockremap:100000:65536" >> /etc/subgid
    echo "✅ Added subgid mapping"
else
    echo "⚠️ subgid mapping already exists"
fi

# 3. Update daemon.json
echo "🔧 Configuring Docker daemon..."
DAEMON_JSON="/etc/docker/daemon.json"

# Backup existing config
if [[ -f "$DAEMON_JSON" ]]; then
    cp "$DAEMON_JSON" "${DAEMON_JSON}.backup"
    echo "✅ Backed up existing daemon.json"
fi

# Write new config (merge with existing if present)
cat > "$DAEMON_JSON" <<'EOF'
{
  "data-root": "/var/lib/docker",
  "userns-remap": "default",
  "no-new-privileges": true,
  "runtimes": {
    "nvidia": {
      "path": "nvidia-container-runtime",
      "runtimeArgs": []
    }
  },
  "default-runtime": "runc",
  "icc": false,
  "userland-proxy": false,
  "live-restore": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
EOF

echo "✅ Updated daemon.json"

# 4. Restart Docker
echo "🔄 Restarting Docker daemon..."
systemctl restart docker
sleep 5

# 5. Verify configuration
echo "🔍 Verifying rootless configuration..."
if docker info | grep -q "userns"; then
    echo "✅ Rootless Docker enabled successfully"
else
    echo "❌ Rootless verification failed"
    exit 1
fi

# 6. Test container startup
echo "🧪 Testing container with rootless..."
if docker run --rm hello-world > /dev/null 2>&1; then
    echo "✅ Container test passed"
else
    echo "❌ Container test failed"
    exit 1
fi

echo ""
echo "🎉 Rootless Docker setup complete!"
echo ""
echo "Next steps:"
echo "1. Rebuild containers: docker-compose build --no-cache"
echo "2. Validate GPU access: make vulkan-validate"
echo "3. Run security scan: make sbom-scan"

exit 0
```

**Testing**:
```bash
# Apply rootless configuration
sudo ./scripts/setup_rootless.sh

# Verify rootless operation
docker info | grep userns
docker run --rm hello-world
```

#### **1.2 GPU Passthrough Validation**

**Objective**: Ensure Vulkan GPU access works in rootless environment

**📁 File: `docker-compose.yml` (Add GPU Configuration)**

**Modify xnai_rag_api service**:
```yaml
xnai_rag_api:
  # ... existing configuration

  # NEW: GPU passthrough for rootless Vulkan
  deploy:
    resources:
      limits:
        memory: 4G
        cpus: '2.0'
      reservations:
        memory: 2G
        cpus: '1.0'
        devices:
          - driver: nvidia  # GPU driver (use 'amdgpu' for AMD)
            count: 1
            capabilities: [gpu, compute]  # Vulkan compute capability

  # NEW: Device access for rootless
  devices:
    - /dev/dri:/dev/dri  # DRM (Direct Rendering Manager) for Vulkan
    - /dev/kfd:/dev/kfd  # Kernel Fusion Driver for AMD Compute

  # NEW: Capability adjustments for rootless GPU
  cap_add:
    - SYS_ADMIN  # Required for DRM access (minimal privilege)
```

**Testing**:
```bash
# Rebuild and test GPU access
docker-compose build --no-cache
docker-compose up -d
docker exec xnai_rag_api vulkaninfo --summary
```

### **Phase 2: SBOM Generation & Integration (Week 2)**

#### **2.1 Syft SBOM Generation**

**Objective**: Implement automated SBOM generation in build pipeline

**📁 File: `Dockerfile.api` (Add SBOM Generation Stage)**

**After builder stage**:
```dockerfile
# ============================================================================
# SBOM Generation Stage (v0.1.6 - Enterprise Compliance)
# ============================================================================
FROM builder AS sbom-generator

# Install Syft for SBOM generation
RUN curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | \
    sh -s -- -b /usr/local/bin v0.100.0

# Generate SBOM in multiple formats for compliance
WORKDIR /app

# 1. SPDX JSON format (most comprehensive)
RUN syft packages . -o spdx-json > /sbom/xoe-novai-api-sbom.spdx.json

# 2. CycloneDX JSON format (OWASP standard)
RUN syft packages . -o cyclonedx-json > /sbom/xoe-novai-api-sbom.cdx.json

# 3. Table format (human-readable for audits)
RUN syft packages . -o table > /sbom/xoe-novai-api-sbom.txt

# Validate SBOM generation
RUN test -f /sbom/xoe-novai-api-sbom.spdx.json || \
    (echo "❌ SBOM generation failed" && exit 1)

# ============================================================================
# Final Runtime Stage (with SBOM copy)
# ============================================================================
FROM python:3.11-slim-bookworm AS runtime

# ... existing USER, WORKDIR setup

# NEW: Copy SBOM files to container for compliance checks
COPY --from=sbom-generator /sbom /app/sbom/

# Add SBOM metadata to image labels
LABEL org.opencontainers.image.sbom.spdx="/app/sbom/xoe-novai-api-sbom.spdx.json"
LABEL org.opencontainers.image.sbom.cyclonedx="/app/sbom/xoe-novai-api-sbom.cdx.json"

# ... rest of runtime configuration
```

**📁 File: `scripts/generate_sbom.sh` (SBOM Extraction Script)**

**Create New File**:
```bash
#!/bin/bash
# ============================================================================
# Xoe-NovAi SBOM Generation and Validation Script
# ============================================================================
# Purpose: Generate and validate SBOM files for enterprise compliance
# Guide Reference: 06-rootless-docker-sbom.md
# Last Updated: 2026-01-14
# ============================================================================

set -euo pipefail

echo "📋 Xoe-NovAi SBOM Generation"
echo "============================="

# 1. Build containers with SBOM generation
echo "🔨 Building containers with SBOM..."
docker-compose build --no-cache

# 2. Extract SBOM files from containers
echo "📦 Extracting SBOM files..."

mkdir -p sbom

# Extract from RAG API container
if docker run --rm xnai_rag_api test -f /app/sbom/xoe-novai-api-sbom.spdx.json; then
    docker run --rm xnai_rag_api cat /app/sbom/xoe-novai-api-sbom.spdx.json > sbom/api-sbom.spdx.json
    docker run --rm xnai_rag_api cat /app/sbom/xoe-novai-api-sbom.cdx.json > sbom/api-sbom.cdx.json
    echo "✅ Extracted RAG API SBOM"
else
    echo "⚠️ RAG API SBOM not found in container"
fi

# Extract from UI container (if SBOM generation added)
if docker run --rm xnai_chainlit test -f /app/sbom/xoe-novai-ui-sbom.spdx.json 2>/dev/null; then
    docker run --rm xnai_chainlit cat /app/sbom/xoe-novai-ui-sbom.spdx.json > sbom/ui-sbom.spdx.json
    echo "✅ Extracted UI SBOM"
else
    echo "⚠️ UI SBOM not available"
fi

# 3. Validate SBOM files
echo "🔍 Validating SBOM files..."

for sbom_file in sbom/*.spdx.json; do
    if [[ -f "$sbom_file" ]]; then
        echo "Checking $sbom_file..."
        if jq empty "$sbom_file" 2>/dev/null; then
            echo "  ✅ Valid JSON"
            # Extract package count
            package_count=$(jq '.packages | length' "$sbom_file" 2>/dev/null || echo "unknown")
            echo "  📦 Packages: $package_count"
        else
            echo "  ❌ Invalid JSON"
        fi
    fi
done

# 4. Generate compliance report
echo "📊 Generating compliance report..."
REPORT_FILE="sbom/compliance-report-$(date +%Y%m%d-%H%M%S).md"

cat > "$REPORT_FILE" << EOF
# Xoe-NovAi SBOM Compliance Report

**Generated**: $(date -u +%Y-%m-%dT%H:%M:%SZ)
**Environment**: $(uname -a)

## Container Images
$(docker images --filter "reference=xnai*" --format "- {{.Repository}}:{{.Tag}} ({{.Size}})")

## SBOM Files Generated
$(ls -lh sbom/*.spdx.json | awk '{print "- " $9 " (" $5 ")"}' || echo "No SBOM files found")

## Validation Results
$(for sbom_file in sbom/*.spdx.json; do
    if [[ -f "$sbom_file" ]]; then
        echo "### $(basename "$sbom_file")"
        echo "- **Valid JSON**: $(jq empty "$sbom_file" 2>/dev/null && echo "✅" || echo "❌")"
        echo "- **Packages**: $(jq '.packages | length' "$sbom_file" 2>/dev/null || echo "unknown")"
        echo "- **Creation**: $(jq -r '.creationInfo.created' "$sbom_file" 2>/dev/null || echo "unknown")"
    fi
done)

## Next Steps
1. Review SBOM contents for sensitive dependencies
2. Run vulnerability scanning with Trivy
3. Upload to compliance dashboard
4. Schedule automated SBOM regeneration

---
*Generated by Xoe-NovAi SBOM automation*
EOF

echo "✅ Compliance report saved to $REPORT_FILE"

echo ""
echo "🎉 SBOM generation complete!"
echo "Files saved in sbom/ directory"
echo "Compliance report: $REPORT_FILE"

exit 0
```

#### **2.2 Trivy Vulnerability Scanning**

**Objective**: Integrate automated vulnerability scanning with SBOM

**📁 File: `scripts/vulnerability_scan.sh` (Trivy Integration)**

**Create New File**:
```bash
#!/bin/bash
# ============================================================================
# Xoe-NovAi Vulnerability Scanning Script
# ============================================================================
# Purpose: Automated vulnerability scanning with Trivy integration
# Guide Reference: 06-rootless-docker-sbom.md
# Last Updated: 2026-01-14
# ============================================================================

set -euo pipefail

echo "🔍 Xoe-NovAi Vulnerability Scan"
echo "==============================="

# Check if Trivy is installed
if ! command -v trivy &> /dev/null; then
    echo "❌ Trivy not installed. Installing..."
    # Install Trivy (Ubuntu/Debian)
    sudo apt-get update
    sudo apt-get install -y wget apt-transport-https
    wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | sudo apt-key add -
    echo "deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" | sudo tee -a /etc/apt/sources.list.d/trivy.list
    sudo apt-get update
    sudo apt-get install -y trivy
    echo "✅ Trivy installed"
fi

# 1. Scan running containers
echo "🔎 Scanning running containers..."

# Get container IDs
CONTAINERS=$(docker ps --format "{{.ID}}:{{.Names}}")

if [[ -z "$CONTAINERS" ]]; then
    echo "⚠️ No running containers found"
else
    echo "$CONTAINERS" | while IFS=: read -r container_id container_name; do
        echo "Scanning $container_name ($container_id)..."

        # Run Trivy scan
        SCAN_OUTPUT="security/trivy-${container_name}-$(date +%Y%m%d-%H%M%S).json"

        mkdir -p security

        if trivy image --format json --output "$SCAN_OUTPUT" "$container_name" 2>/dev/null; then
            echo "  ✅ Scan completed: $SCAN_OUTPUT"

            # Extract critical/high vulnerabilities
            critical_count=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "CRITICAL")] | length' "$SCAN_OUTPUT" 2>/dev/null || echo "0")
            high_count=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "HIGH")] | length' "$SCAN_OUTPUT" 2>/dev/null || echo "0")

            echo "  🚨 Critical: $critical_count, High: $high_count"

            if [[ "$critical_count" -gt 0 ]]; then
                echo "  ❌ CRITICAL VULNERABILITIES FOUND!"
                exit 1
            fi

            if [[ "$high_count" -gt 5 ]]; then
                echo "  ⚠️ HIGH VULNERABILITY COUNT: $high_count"
            fi

        else
            echo "  ❌ Scan failed for $container_name"
        fi
    done
fi

# 2. Scan SBOM files (if available)
echo "📋 Scanning SBOM files..."

if [[ -d "sbom" ]] && [[ "$(ls sbom/*.spdx.json 2>/dev/null | wc -l)" -gt 0 ]]; then
    for sbom_file in sbom/*.spdx.json; do
        echo "Scanning $sbom_file..."

        # Trivy can scan SPDX SBOM files
        SBOM_SCAN_OUTPUT="security/trivy-sbom-$(basename "$sbom_file" .spdx.json)-$(date +%Y%m%d-%H%M%S).json"

        if trivy sbom --format json --output "$SBOM_SCAN_OUTPUT" "$sbom_file" 2>/dev/null; then
            echo "  ✅ SBOM scan completed: $SBOM_SCAN_OUTPUT"

            # Check for critical vulnerabilities in SBOM
            critical_count=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "CRITICAL")] | length' "$SBOM_SCAN_OUTPUT" 2>/dev/null || echo "0")

            if [[ "$critical_count" -gt 0 ]]; then
                echo "  ❌ CRITICAL VULNERABILITIES IN SBOM!"
                exit 1
            fi

        else
            echo "  ❌ SBOM scan failed for $(basename "$sbom_file")"
        fi
    done
else
    echo "⚠️ No SBOM files found in sbom/ directory"
fi

# 3. Generate security report
echo "📊 Generating security report..."
REPORT_FILE="security/security-report-$(date +%Y%m%d-%H%M%S).md"

cat > "$REPORT_FILE" << EOF
# Xoe-NovAi Security Vulnerability Report

**Generated**: $(date -u +%Y-%m-%dT%H:%M:%SZ)
**Scanner**: Trivy $(trivy version --format json | jq -r '.Version' 2>/dev/null || echo "unknown")

## Scan Summary

### Container Scans
$(if [[ -n "$CONTAINERS" ]]; then
    echo "| Container | Critical | High | Medium | Low |"
    echo "|-----------|----------|------|--------|-----|"
    for scan_file in security/trivy-*-$(date +%Y%m%d)*.json; do
        if [[ -f "$scan_file" ]]; then
            container_name=$(basename "$scan_file" | sed 's/trivy-\(.*\)-[0-9]*.json/\1/')
            critical=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "CRITICAL")] | length' "$scan_file" 2>/dev/null || echo "0")
            high=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "HIGH")] | length' "$scan_file" 2>/dev/null || echo "0")
            medium=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "MEDIUM")] | length' "$scan_file" 2>/dev/null || echo "0")
            low=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "LOW")] | length' "$scan_file" 2>/dev/null || echo "0")
            echo "| $container_name | $critical | $high | $medium | $low |"
        fi
    done
else
    echo "No container scans performed"
fi)

### SBOM Scans
$(if [[ -d "sbom" ]] && [[ "$(ls sbom/*.spdx.json 2>/dev/null | wc -l)" -gt 0 ]]; then
    ls sbom/*.spdx.json | while read -r sbom_file; do
        echo "- $(basename "$sbom_file")"
    done
else
    echo "No SBOM scans performed"
fi)

## Risk Assessment

### Critical Findings
$(if [[ -f "security/trivy-xnai_rag_api-$(date +%Y%m%d)*.json" ]]; then
    critical_vulns=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "CRITICAL")] | .[] | {id: .VulnerabilityID, package: .PkgName, fixed: .FixedVersion}' "security/trivy-xnai_rag_api-$(date +%Y%m%d)*.json" 2>/dev/null || echo "[]")
    if [[ "$critical_vulns" != "[]" ]]; then
        echo "$critical_vulns" | jq -r '. | "- **\(.id)** in \(.package) (Fixed: \(.fixed // "Unknown"))"'
    else
        echo "No critical vulnerabilities found ✅"
    fi
else
    echo "No scan results available"
fi)

## Recommendations

1. **Immediate Actions**
   - Address all critical vulnerabilities
   - Update base images to latest versions
   - Review dependency licenses in SBOM

2. **Monitoring Setup**
   - Schedule daily vulnerability scans
   - Set up alerts for new critical vulnerabilities
   - Integrate with enterprise security dashboard

3. **Compliance Requirements**
   - Maintain SBOM files for audit purposes
   - Document vulnerability remediation process
   - Report security metrics to stakeholders

---
*Generated by Xoe-NovAi security automation*
EOF

echo "✅ Security report saved to $REPORT_FILE"

echo ""
echo "🎉 Vulnerability scan complete!"
echo "Results saved in security/ directory"
echo "Security report: $REPORT_FILE"

# Exit with error if critical vulnerabilities found
if [[ -f "security/trivy-xnai_rag_api-$(date +%Y%m%d)*.json" ]]; then
    critical_count=$(jq '[.Results[].Vulnerabilities[]? | select(.Severity == "CRITICAL")] | length' "security/trivy-xnai_rag_api-$(date +%Y%m%d)*.json" 2>/dev/null || echo "0")
    if [[ "$critical_count" -gt 0 ]]; then
        echo "❌ CRITICAL VULNERABILITIES DETECTED - ACTION REQUIRED"
        exit 1
    fi
fi

echo "✅ All security checks passed"

exit 0
```

### **Phase 3: CI/CD Security Integration (Week 3)**

#### **3.1 GitHub Actions Security Pipeline**

**Objective**: Automate security scanning and compliance reporting in CI/CD

**📁 File: `.github/workflows/sbom-security.yml` (Create New Workflow)**

```yaml
name: SBOM Security Scan

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  schedule:
    - cron: '0 0 * * 0'  # Weekly on Sunday

jobs:
  sbom-generation:
    name: Generate and Scan SBOM
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write  # For uploading SARIF results

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Build containers with SBOM
        run: |
          docker-compose build --no-cache

      - name: Extract SBOM files
        run: |
          mkdir -p sbom
          docker run --rm xnai_rag_api:latest cat /app/sbom/xoe-novai-api-sbom.spdx.json > sbom/api-sbom.spdx.json

      - name: Upload SBOM as artifact
        uses: actions/upload-artifact@v4
        with:
          name: xoe-novai-sbom
          path: sbom/*.spdx.json

      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'image'
          image-ref: 'xnai_rag_api:latest'
          format: 'sarif'
          output: 'trivy-results.sarif'
          severity: 'CRITICAL,HIGH'

      - name: Upload Trivy results to GitHub Security
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: 'trivy-results.sarif'

      - name: Generate compliance report
        run: |
          make sbom-report

      - name: Upload compliance report
        uses: actions/upload-artifact@v4
        with:
          name: sbom-compliance-report
          path: reports/sbom/report.md

      - name: Check for critical vulnerabilities
        run: |
          CRITICAL=$(docker run --rm aquasec/trivy image --severity CRITICAL --format json xnai_rag_api:latest | jq '[.Results[].Vulnerabilities[]] | length')
          echo "Critical vulnerabilities: $CRITICAL"
          if [ "$CRITICAL" -gt 0 ]; then
            echo "❌ Critical vulnerabilities found!"
            exit 1
          fi
          echo "✅ No critical vulnerabilities"
```

#### **3.2 Makefile Security Targets**

**Objective**: Provide convenient security management commands

**📁 File: `Makefile` (Add Security Targets)**

```makefile
# ============================================================================
# Security & SBOM Targets (v0.1.6)
# ============================================================================

.PHONY: rootless-setup
rootless-setup: ## Setup rootless Docker configuration
	@echo "🔒 Setting up rootless Docker..."
	@if [ "$$(id -u)" = "0" ]; then \
		./scripts/setup_rootless.sh; \
	else \
		echo "❌ Must run as root (use sudo)"; \
		exit 1; \
	fi
	@echo "✅ Rootless setup complete"

.PHONY: sbom-generate
sbom-generate: ## Generate SBOM for all containers
	@echo "📋 Generating SBOM files..."
	@echo "Note: SBOMs are generated during 'docker-compose build'"
	@docker images --filter "reference=xnai*" --format "{{.Repository}}:{{.Tag}}" | \
	  while read -r image; do \
	    echo "Extracting SBOM from $$image..."; \
	    docker run --rm $$image cat /app/sbom/xoe-novai-api-sbom.spdx.json > "sbom/$$image-sbom.spdx.json" 2>/dev/null || echo "⚠️ SBOM not found in $$image"; \
	  done
	@echo "✅ SBOM files extracted to sbom/ directory"

.PHONY: sbom-scan
sbom-scan: ## Scan SBOM for vulnerabilities with Trivy
	@echo "🔍 Scanning SBOM for vulnerabilities..."
	@if ! command -v trivy &> /dev/null; then \
	  echo "❌ Trivy not installed. Install: https://trivy.dev/install/"; \
	  exit 1; \
	fi
	@echo "Scanning xnai_rag_api image..."
	@trivy image --severity HIGH,CRITICAL xnai_rag_api:latest
	@echo ""
	@echo "Scanning xnai_chainlit_ui image..."
	@trivy image --severity HIGH,CRITICAL xnai_chainlit_ui:latest
	@echo "✅ Vulnerability scan complete"

.PHONY: sbom-validate
sbom-validate: ## Validate SBOM compliance
	@echo "✅ Validating SBOM files..."
	@for sbom in sbom/*.spdx.json; do \
	  echo "Checking $$sbom..."; \
	  jq empty "$$sbom" && echo "  ✅ Valid JSON" || echo "  ❌ Invalid JSON"; \
	done
	@echo "✅ SBOM validation complete"

.PHONY: sbom-report
sbom-report: ## Generate comprehensive SBOM compliance report
	@echo "📊 Generating SBOM compliance report..."
	@mkdir -p reports/sbom
	@echo "# Xoe-NovAi SBOM Compliance Report" > reports/sbom/report.md
	@echo "**Generated**: $$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> reports/sbom/report.md
	@echo "" >> reports/sbom/report.md
	@echo "## Container Images" >> reports/sbom/report.md
	@docker images --filter "reference=xnai*" --format "- {{.Repository}}:{{.Tag}} ({{.Size}})" >> reports/sbom/report.md
	@echo "" >> reports/sbom/report.md
	@echo "## SBOM Files Generated" >> reports/sbom/report.md
	@ls -lh sbom/*.spdx.json | awk '{print "- " $9 " (" $5 ")"}' >> reports/sbom/report.md
	@echo "" >> reports/sbom/report.md
	@echo "## Vulnerability Scan Results" >> reports/sbom/report.md
	@trivy image --severity HIGH,CRITICAL --format json xnai_rag_api:latest | \
	  jq -r '.Results[].Vulnerabilities | length' | \
	  awk '{print "- Critical/High Vulnerabilities: " $$1}' >> reports/sbom/report.md
	@cat reports/sbom/report.md
	@echo "✅ Report saved to reports/sbom/report.md"

.PHONY: security-full-scan
security-full-scan: sbom-generate sbom-scan sbom-validate sbom-report ## Run complete security assessment
	@echo "🔐 Complete security assessment finished"
	@echo "Reports available in:"
	@echo "  - sbom/ (SBOM files)"
	@echo "  - security/ (vulnerability scans)"
	@echo "  - reports/sbom/ (compliance reports)"

.PHONY: rootless-validate
rootless-validate: ## Validate rootless Docker configuration
	@echo "🔍 Validating rootless Docker setup..."
	@docker info | grep -q "userns" && echo "✅ User namespaces enabled" || (echo "❌ User namespaces not enabled" && exit 1)
	@docker run --rm hello-world > /dev/null 2>&1 && echo "✅ Rootless container execution works" || (echo "❌ Rootless execution failed" && exit 1)
	@echo "✅ Rootless validation complete"
```

### **Phase 4: Enterprise Compliance & Chaos Testing (Week 4)**

#### **4.1 Chaos Engineering for Security**

**Objective**: Validate security resilience under failure conditions

**📁 File: `scripts/chaos_rootless_test.sh` (Security Chaos Testing)**

```bash
#!/bin/bash
# ============================================================================
# Xoe-NovAi Rootless Docker Chaos Engineering Test
# ============================================================================
# Purpose: Validate security and stability of rootless Docker configuration
# Guide Reference: 06-rootless-docker-sbom.md
# Last Updated: 2026-01-14
# ============================================================================

set -eo pipefail

echo "🔥 Rootless Docker Chaos Engineering Test"
echo "=========================================="

# Test 1: Privilege Escalation Prevention
echo ""
echo "Test 1: Privilege Escalation Prevention"
echo "----------------------------------------"
docker run --rm xnai_rag_api:latest whoami | grep -q "appuser" && \
  echo "✅ Container runs as non-root user" || \
  (echo "❌ Container running as root!" && exit 1)

# Test 2: GPU Access with Rootless
echo ""
echo "Test 2: GPU Access Validation"
echo "------------------------------"
docker exec xnai_rag_api vulkaninfo --summary > /dev/null 2>&1 && \
  echo "✅ Vulkan accessible in rootless mode" || \
  echo "⚠️ Vulkan not accessible (GPU optional)"

# Test 3: File System Isolation
echo ""
echo "Test 3: File System Isolation"
echo "------------------------------"
docker run --rm xnai_rag_api:latest touch /etc/test 2>&1 | grep -q "Permission denied" && \
  echo "✅ Write protection on system directories" || \
  (echo "❌ System directories writable!" && exit 1)

# Test 4: Network Isolation
echo ""
echo "Test 4: Network Isolation"
echo "-------------------------"
docker network ls | grep -q "xnai_network" && \
  echo "✅ Custom network isolated" || \
  (echo "❌ Network isolation failed!" && exit 1)

# Test 5: SBOM Availability
echo ""
echo "Test 5: SBOM Availability"
echo "-------------------------"
docker run --rm xnai_rag_api:latest test -f /app/sbom/xoe-novai-api-sbom.spdx.json && \
  echo "✅ SBOM file present in container" || \
  (echo "❌ SBOM file missing!" && exit 1)

# Test 6: Container Restart Under Load
echo ""
echo "Test 6: Container Stability Under Load"
echo "---------------------------------------"
echo "Sending 50 rapid requests..."
for i in {1..50}; do
  curl -s -X POST http://localhost:8000/query \
    -H "Content-Type: application/json" \
    -d '{"query":"test","use_rag":false,"max_tokens":10}' > /dev/null &
done
wait
docker ps | grep -q "xnai_rag_api" && \
  echo "✅ Container stable under load" || \
  (echo "❌ Container crashed!" && exit 1)

# Test 7: Memory Limit Enforcement
echo ""
echo "Test 7: Memory Limit Enforcement"
echo "---------------------------------"
MEMORY_LIMIT=$(docker inspect xnai_rag_api | jq -r '.[0].HostConfig.Memory')
echo "Memory limit: $((MEMORY_LIMIT / 1024 / 1024))MB"
[ "$MEMORY_LIMIT" -le 4294967296 ] && \
  echo "✅ Memory limit enforced (≤4GB)" || \
  (echo "❌ Memory limit too high!" && exit 1)

echo ""
echo "🎉 All chaos tests passed!"
echo "Rootless Docker configuration validated."

exit 0
```

#### **4.2 Performance Impact Assessment**

**Objective**: Validate that security measures don't impact performance significantly

**📁 File: `scripts/benchmark_security_performance.py`**

```python
#!/usr/bin/env python3
"""
Security Performance Impact Benchmarking
Measures performance overhead of rootless Docker and SBOM security
"""

import time
import statistics
import subprocess
import requests
from typing import Dict, Any, List

class SecurityPerformanceBenchmarker:
    """Benchmark security feature performance impact"""

    def __init__(self, api_url: str = "http://localhost:8000"):
        self.api_url = api_url

    def benchmark_container_startup(self) -> Dict[str, Any]:
        """Benchmark container startup time with security features"""
        startup_times = []

        print("🏃 Testing container startup performance...")

        for i in range(5):
            # Measure container startup time
            start = time.time()

            # Start container
            subprocess.run([
                "docker-compose", "up", "-d", "xnai_rag_api"
            ], capture_output=True)

            # Wait for health check
            for _ in range(30):  # 30 second timeout
                try:
                    response = requests.get(f"{self.api_url}/health", timeout=1)
                    if response.status_code == 200:
                        startup_time = time.time() - start
                        startup_times.append(startup_time)
                        break
                except:
                    pass
                time.sleep(1)
            else:
                print(f"⚠️ Container startup timeout on attempt {i+1}")
                continue

            # Clean up
            subprocess.run([
                "docker-compose", "down"
            ], capture_output=True)

        if startup_times:
            avg_startup = statistics.mean(startup_times)
            return {
                "average_startup_time": avg_startup,
                "startup_times": startup_times,
                "within_target": avg_startup < 30  # 30 second target
            }
        else:
            return {"error": "Container startup failed"}

    def benchmark_api_performance(self) -> Dict[str, Any]:
        """Benchmark API performance with security features"""
        queries = [
            "What is Xoe-NovAi?",
            "How does RAG work?",
            "What are the security features?"
        ]

        response_times = []

        print("🔍 Testing API performance with security...")

        for i in range(10):
            for query in queries:
                start = time.time()
                response = requests.post(
                    f"{self.api_url}/query",
                    json={"query": query, "use_rag": True}
                )
                response_time = time.time() - start

                if response.status_code == 200:
                    response_times.append(response_time)
                else:
                    print(f"⚠️ API call failed: {response.status_code}")

        if response_times:
            avg_response_time = statistics.mean(response_times)
            p95_response_time = statistics.quantiles(response_times, n=20)[18]

            return {
                "average_response_time": avg_response_time,
                "p95_response_time": p95_response_time,
                "total_requests": len(response_times),
                "within_target": avg_response_time < 1.0  # 1 second target
            }
        else:
            return {"error": "API performance test failed"}

    def benchmark_security_overhead(self) -> Dict[str, Any]:
        """Benchmark overall security feature overhead"""
        print("🔐 Running comprehensive security benchmark...")

        startup_results = self.benchmark_container_startup()
        api_results = self.benchmark_api_performance()

        results = {
            "timestamp": time.time(),
            "startup_performance": startup_results,
            "api_performance": api_results,
            "security_overhead_assessment": self._assess_overhead(startup_results, api_results)
        }

        print("📊 Security Performance Results:")
        print(f"   Container Startup: {startup_results.get('average_startup_time', 'N/A'):.2f}s")
        print(f"   API Response (avg): {api_results.get('average_response_time', 'N/A'):.3f}s")
        print(f"   API Response (P95): {api_results.get('p95_response_time', 'N/A'):.3f}s")

        return results

    def _assess_overhead(self, startup: Dict, api: Dict) -> Dict[str, Any]:
        """Assess security overhead impact"""
        assessment = {
            "acceptable_overhead": True,
            "recommendations": []
        }

        # Check startup time
        if startup.get("average_startup_time", 60) > 45:
            assessment["acceptable_overhead"] = False
            assessment["recommendations"].append("Optimize container startup time")

        # Check API performance
        if api.get("average_response_time", 2.0) > 1.5:
            assessment["acceptable_overhead"] = False
            assessment["recommendations"].append("Optimize API response time")

        # Overall assessment
        if assessment["acceptable_overhead"]:
            assessment["conclusion"] = "Security features have acceptable performance impact"
        else:
            assessment["conclusion"] = "Security features may impact performance - optimization needed"

        return assessment

if __name__ == "__main__":
    benchmarker = SecurityPerformanceBenchmarker()
    results = benchmarker.benchmark_security_overhead()

    assessment = results["security_overhead_assessment"]

    print("
🎯 Security Overhead Assessment:"    if assessment["acceptable_overhead"]:
        print("✅ Security overhead within acceptable limits")
    else:
        print("⚠️ Security overhead may impact performance")

    if assessment["recommendations"]:
        print("💡 Recommendations:")
        for rec in assessment["recommendations"]:
            print(f"   - {rec}")

    print(f"📋 Conclusion: {assessment['conclusion']}")
```

---

## 📊 **Success Metrics & Validation**

### **Security Targets**
- **Zero Critical Vulnerabilities**: Automated scanning with Trivy
- **Rootless Operation**: User namespace isolation validated
- **SBOM Compliance**: SPDX and CycloneDX formats generated
- **Performance Overhead**: <10% impact on operations

### **Quality Assurance**
- **Chaos Testing**: Security resilience under failure conditions
- **CI/CD Integration**: Automated security pipelines
- **Compliance Reporting**: Enterprise audit trail maintenance
- **Vulnerability Management**: Regular scanning and remediation

### **Enterprise Compliance**
- **SOC2/GDPR Ready**: Automated compliance checking
- **Audit Trail**: Complete security event logging
- **SBOM Management**: Standardized bill of materials
- **Container Security**: Rootless isolation and minimal privileges

---

## 🚨 **Risk Mitigation & Contingencies**

### **High-Risk Scenarios**

**1. GPU Access Loss**
- **Risk**: Vulkan acceleration unavailable in rootless mode
- **Mitigation**: Comprehensive GPU device passthrough configuration
- **Contingency**: CPU-only fallback with clear performance trade-offs

**2. Performance Degradation**
- **Risk**: Security features impact response times significantly
- **Mitigation**: Performance benchmarking and optimization
- **Contingency**: Selective security feature enablement

**3. Vulnerability Discovery**
- **Risk**: Critical vulnerabilities found in dependencies
- **Mitigation**: Regular automated scanning and alerts
- **Contingency**: Emergency patching procedures and rollback plans

### **Implementation Checklist**

#### **Pre-Implementation**
- [ ] Docker daemon rootless configuration planned
- [ ] GPU passthrough compatibility verified
- [ ] SBOM generation tools selected (Syft/Trivy)
- [ ] Security baseline performance established

#### **Phase 1: Foundation**
- [ ] Rootless Docker daemon configured
- [ ] GPU device access validated
- [ ] Basic SBOM generation working
- [ ] Container builds successful

#### **Phase 2: Security Integration**
- [ ] SBOM generation automated in Dockerfiles
- [ ] Trivy vulnerability scanning integrated
- [ ] SBOM files properly formatted and validated
- [ ] Security scanning producing clean results

#### **Phase 3: CI/CD Automation**
- [ ] GitHub Actions security workflow created
- [ ] Automated SBOM generation in pipeline
- [ ] Vulnerability scanning integrated
- [ ] Security reports generated automatically

#### **Phase 4: Enterprise Validation**
- [ ] Chaos testing for security resilience
- [ ] Performance impact assessment completed
- [ ] Compliance reporting operational
- [ ] Enterprise audit trails functional

---

## 🎯 **Implementation Status**

**Current Status**: READY FOR EXECUTION
**Next Steps**:
1. Begin with rootless Docker daemon setup
2. Implement SBOM generation in build pipeline
3. Integrate Trivy vulnerability scanning
4. Create CI/CD security automation
5. Validate enterprise compliance and performance

**Success Criteria Met**:
- [ ] Rootless Docker configuration operational
- [ ] SBOM generation automated and compliant
- [ ] Vulnerability scanning integrated
- [ ] GPU access maintained in rootless mode
- [ ] Performance overhead <10%
- [ ] Enterprise compliance requirements satisfied

This roadmap provides the complete technical implementation guide for achieving 100% rootless Docker with enterprise SBOM security while maintaining performance and compliance standards. 🔒
