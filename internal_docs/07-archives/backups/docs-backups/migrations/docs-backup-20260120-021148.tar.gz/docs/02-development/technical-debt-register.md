# 📋 Xoe-NovAi Technical Debt Register
## Production Integration Technical Debt Tracking

**Last Updated**: January 14, 2026  
**Version**: v0.1.5 → v0.2.0 (Target)  
**Total Debt Items**: 15  
**Critical Items**: 4  
**Estimated Resolution Time**: 3 weeks

---

## 🚨 Critical Technical Debt (Must Fix - Phase 1)

### 1. Security: Weak REDIS_PASSWORD
**Priority**: 🔴 CRITICAL  
**Impact**: High security risk, potential unauthorized access  
**Location**: `.env` file  
**Current State**: Sequential digits "1234567890123456"  
**Target Resolution**: Phase 1, Week 1

**Details**:
- REDIS_PASSWORD uses predictable sequential digits
- No entropy, easily brute-forced
- Redis is exposed to internal network but still a security risk

**Solution**:
```bash
# Generate secure password
REDIS_PASSWORD=$(openssl rand -base64 32)
echo "REDIS_PASSWORD=$REDIS_PASSWORD" >> .env
```

**Validation**:
- [ ] Password contains mixed case, numbers, symbols
- [ ] Password length >= 32 characters
- [ ] Redis authentication test passes

---

### 2. Security: Hardcoded APP_UID/GID
**Priority**: 🔴 CRITICAL  
**Impact**: Permission issues, potential container failures  
**Location**: `.env` file  
**Current State**: APP_UID=1001, APP_GID=1001 (hardcoded)  
**Target Resolution**: Phase 1, Week 1

**Details**:
- Container user (1001) may not match host user
- Causes permission denied errors on mounted volumes
- Breaks file operations in library/, knowledge/, logs/

**Solution**:
```bash
# Set dynamic values
APP_UID=$(id -u)
APP_GID=$(id -g)
echo "APP_UID=$APP_UID" >> .env
echo "APP_GID=$APP_GID" >> .env
```

**Validation**:
- [ ] Container user matches host user
- [ ] File operations work in all mounted volumes
- [ ] No permission denied errors in logs

---

### 3. Dependencies: Missing Core Packages
**Priority**: 🔴 CRITICAL  
**Impact**: System instability, missing functionality  
**Location**: `requirements-api.in`, `pyproject.toml`  
**Current State**: Missing langchain-community, faiss-cpu, anyio, pycircuitbreaker, opentelemetry-sdk  
**Target Resolution**: Phase 1, Week 1

**Missing Dependencies**:
- `langchain-community>=0.0.20` - Required for FAISS integration
- `faiss-cpu>=1.8.0` - Core RAG component
- `anyio>=4.0.0` - 2026 async standard
- `pycircuitbreaker>=1.0.0` - Modern async circuit breaker
- `opentelemetry-sdk>=1.20.0` - Observability framework

**Solution**:
```toml
# Add to pyproject.toml
[project.dependencies]
langchain-community = ">=0.0.20"
faiss-cpu = ">=1.8.0"
anyio = ">=4.0.0"
pycircuitbreaker = ">=1.0.0"
opentelemetry-sdk = ">=1.20.0"
```

**Validation**:
- [ ] All dependencies install successfully
- [ ] No import errors in application
- [ ] FAISS integration works
- [ ] Circuit breakers function properly

---

### 4. Architecture: Mixed Sync/Async Patterns
**Priority**: 🔴 CRITICAL  
**Impact**: Performance degradation, threadpool overhead  
**Location**: `app/XNAi_rag_app/main.py`  
**Current State**: Mix of sync endpoints with async operations  
**Target Resolution**: Phase 2, Week 2

**Details**:
- FastAPI endpoints are async but call sync operations
- LLM loading is blocking
- File I/O operations are synchronous
- Causes threadpool exhaustion under load

**Solution**:
```python
# Convert blocking operations to async
async def load_llm_async():
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, get_llm)

# Use async file operations
async def read_file_async(path):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, Path(path).read_text)
```

**Validation**:
- [ ] All endpoints are truly async
- [ ] No blocking operations in request handlers
- [ ] Performance improvement measured
- [ ] Threadpool usage optimized

---

## 🟡 High Priority Technical Debt (Should Fix - Phase 2)

### 5. Performance: No iGPU Acceleration
**Priority**: 🟡 HIGH  
**Impact**: Suboptimal performance on AMD Ryzen systems  
**Location**: `config.toml`, `app/XNAi_rag_app/dependencies.py`  
**Current State**: CPU-only inference  
**Target Resolution**: Phase 2, Week 2

**Details**:
- AMD Ryzen 5700U has Vega iGPU that's not utilized
- LLM inference runs on CPU only
- Missed performance opportunity (2-3x potential improvement)

**Solution**:
```python
# Enable iGPU offloading
llm_params = {
    'model_path': model_path,
    'n_gpu_layers': -1,  # Offload all layers to iGPU
    'f16_kv': True,
    'use_mlock': True,
    'use_mmap': True,
}
```

**Validation**:
- [ ] iGPU memory usage confirmed
- [ ] Performance improvement measured
- [ ] No stability issues
- [ ] Memory usage optimized

---

### 6. Observability: Limited Monitoring
**Priority**: 🟡 HIGH  
**Impact**: Poor operational visibility, difficult debugging  
**Location**: `app/XNAi_rag_app/metrics.py`  
**Current State**: Basic Prometheus metrics only  
**Target Resolution**: Phase 2, Week 2

**Details**:
- No distributed tracing
- Limited error tracking
- No performance correlation
- Basic health checks only

**Solution**:
```python
# Add OpenTelemetry instrumentation
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

# Add spans to key functions
@asynccontextmanager
async def lifespan(app: FastAPI):
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("llm_initialization"):
        # LLM loading
    with tracer.start_as_current_span("vectorstore_loading"):
        # Vectorstore loading
```

**Validation**:
- [ ] Distributed tracing operational
- [ ] Performance metrics comprehensive
- [ ] Error tracking functional
- [ ] Dashboard operational

---

### 7. Testing: Basic Test Coverage
**Priority**: 🟡 HIGH  
**Impact**: Risk of regressions, poor quality assurance  
**Location**: `tests/` directory  
**Current State**: Basic unit tests only  
**Target Resolution**: Phase 3, Week 3

**Details**:
- No integration tests
- No property-based testing
- No load testing
- Limited edge case coverage

**Solution**:
```python
# Add comprehensive testing
import pytest
from hypothesis import given, strategies as st

class TestVoiceInterface:
    @given(audio=st.binary(min_size=1000))
    async def test_stt_latency(self, audio):
        start = time.time()
        await self.transcribe(audio)
        assert time.time() - start < 0.3  # <300ms latency
```

**Validation**:
- [ ] 90% test coverage achieved
- [ ] Integration tests comprehensive
- [ ] Property-based tests added
- [ ] Load testing implemented

---

## 🟢 Medium Priority Technical Debt (Nice to Fix - Phase 3)

### 8. Performance: Static FAISS Indexing
**Priority**: 🟢 MEDIUM  
**Impact**: No change detection, manual reindexing required  
**Location**: `app/XNAi_rag_app/ingest_library.py`  
**Current State**: Static indexing, no incremental updates  
**Target Resolution**: Phase 3, Week 3

**Details**:
- FAISS index rebuilt from scratch on changes
- No incremental updates
- Manual reindexing required
- Poor user experience for content updates

**Solution**:
```python
# Implement incremental indexing
class IncrementalFAISS:
    def add_document(self, text, metadata):
        # Add to existing index
        embedding = self.embeddings.embed_query(text)
        self.index.add(np.array([embedding]))
        self.metadata.append(metadata)
    
    def save_incremental(self):
        # Save only changes
        faiss.write_index(self.index, self.index_path)
```

**Validation**:
- [ ] Incremental updates work
- [ ] Performance improved for updates
- [ ] Data consistency maintained
- [ ] User experience improved

---

### 9. Architecture: Single-Worker Deployment
**Priority**: 🟢 MEDIUM  
**Impact**: Limited scalability, single point of failure  
**Location**: `docker-compose.yml`  
**Current State**: Single worker per service  
**Target Resolution**: Phase 3, Week 3

**Details**:
- Chainlit runs with single worker
- No load balancing
- Limited concurrent users
- Single point of failure

**Solution**:
```yaml
# Multi-worker configuration
services:
  chainlit:
    deploy:
      replicas: 3
    environment:
      - WORKERS=3
```

**Validation**:
- [ ] Multi-worker deployment operational
- [ ] Load balancing functional
- [ ] Concurrent user capacity increased
- [ ] High availability achieved

---

### 10. Security: Missing Input Validation
**Priority**: 🟢 MEDIUM  
**Impact**: Potential injection attacks, data corruption  
**Location**: `app/XNAi_rag_app/main.py`  
**Current State**: Basic input validation only  
**Target Resolution**: Phase 3, Week 3

**Details**:
- No Pydantic schemas for complex inputs
- Limited input sanitization
- No rate limiting per user
- Potential for malicious input

**Solution**:
```python
# Add comprehensive input validation
from pydantic import BaseModel, Field, validator

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000)
    use_rag: bool = Field(True)
    max_tokens: int = Field(512, ge=1, le=2048)
    
    @validator('query')
    def validate_query(cls, v):
        if not v.strip():
            raise ValueError('Query cannot be empty')
        return v
```

**Validation**:
- [ ] Input validation comprehensive
- [ ] Rate limiting implemented
- [ ] Security vulnerabilities patched
- [ ] Error handling improved

---

## 🔵 Low Priority Technical Debt (Future Considerations)

### 11. Documentation: Incomplete MkDocs Structure
**Priority**: 🔵 LOW  
**Impact**: Poor user experience, maintenance difficulty  
**Location**: `docs/` directory  
**Current State**: Missing Diátaxis quadrants  
**Target Resolution**: Phase 3, Week 3

**Details**:
- Missing tutorials quadrant
- Incomplete how-to guides
- Limited explanation content
- Poor navigation structure

**Solution**:
```markdown
# Complete Diátaxis structure
docs/
├── tutorials/     # Step-by-step learning
├── how-to/        # Task-based instructions  
├── reference/     # Technical specifications
└── explanation/   # Conceptual understanding
```

**Validation**:
- [ ] All quadrants present
- [ ] Content comprehensive
- [ ] Navigation intuitive
- [ ] User experience improved

---

### 12. Performance: No Caching Strategy
**Priority**: 🔵 LOW  
**Impact**: Repeated computations, slower response times  
**Location**: `app/XNAi_rag_app/main.py`  
**Current State**: No caching implemented  
**Target Resolution**: Future enhancement

**Details**:
- No query result caching
- No embedding caching
- No LLM response caching
- Repeated expensive computations

**Solution**:
```python
# Implement multi-level caching
class CacheManager:
    def __init__(self):
        self.local_cache = TTLCache(maxsize=1000, ttl=3600)
        self.redis_cache = redis.Redis()
    
    async def get_cached_result(self, key):
        # Check local cache first, then Redis
```

**Validation**:
- [ ] Caching strategy implemented
- [ ] Performance improved
- [ ] Cache hit rates measured
- [ ] Memory usage optimized

---

### 13. Architecture: No Circuit Breaker Fallbacks
**Priority**: 🔵 LOW  
**Impact**: Poor user experience during failures  
**Location**: `app/XNAi_rag_app/main.py`  
**Current State**: Basic circuit breakers only  
**Target Resolution**: Future enhancement

**Details**:
- No graceful degradation
- Limited fallback options
- Poor error recovery
- User experience degradation during outages

**Solution**:
```python
# Implement multi-level fallbacks
class CircuitBreakerWithFallback:
    async def call_with_fallback(self, func, fallback_func):
        try:
            return await func()
        except CircuitBreakerError:
            return await fallback_func()
```

**Validation**:
- [ ] Fallback mechanisms operational
- [ ] User experience maintained
- [ ] Error recovery improved
- [ ] System resilience enhanced

---

### 14. Testing: No Property-Based Testing
**Priority**: 🔵 LOW  
**Impact**: Missed edge cases, potential bugs  
**Location**: `tests/` directory  
**Current State**: Traditional unit tests only  
**Target Resolution**: Future enhancement

**Details**:
- No Hypothesis-based testing
- Limited edge case coverage
- Manual test case creation
- Potential for missed bugs

**Solution**:
```python
# Add property-based testing
@given(st.text(min_size=1, max_size=1000))
def test_query_processing_properties(query):
    # Test properties that should always hold
    result = process_query(query)
    assert isinstance(result, str)
    assert len(result) > 0
```

**Validation**:
- [ ] Property-based tests added
- [ ] Edge cases covered
- [ ] Bug detection improved
- [ ] Test coverage enhanced

---

### 15. Performance: No Resource Monitoring
**Priority**: 🔵 LOW  
**Impact**: Poor resource utilization, potential OOM errors  
**Location**: `app/XNAi_rag_app/metrics.py`  
**Current State**: Basic metrics only  
**Target Resolution**: Future enhancement

**Details**:
- No memory pressure monitoring
- No CPU utilization tracking
- No disk space monitoring
- No network usage tracking

**Solution**:
```python
# Add comprehensive resource monitoring
class ResourceMonitor:
    def __init__(self):
        self.memory_threshold = 0.8
        self.cpu_threshold = 0.8
    
    def check_resources(self):
        memory_percent = psutil.virtual_memory().percent / 100
        cpu_percent = psutil.cpu_percent() / 100
        
        if memory_percent > self.memory_threshold:
            self.trigger_memory_cleanup()
```

**Validation**:
- [ ] Resource monitoring operational
- [ ] Alerts configured
- [ ] Resource usage optimized
- [ ] System stability improved

---

## 📊 Debt Resolution Tracking

### Phase 1: Critical Security & Dependencies (Week 1)
| **Item** | **Status** | **ETA** | **Owner** |
|----------|------------|---------|-----------|
| Weak REDIS_PASSWORD | ⏳ Pending | Day 1 | Dev Team |
| Hardcoded APP_UID/GID | ⏳ Pending | Day 1 | Dev Team |
| Missing Core Dependencies | ⏳ Pending | Day 2 | Dev Team |
| Mixed Sync/Async Patterns | ⏳ Pending | Day 7 | Dev Team |

### Phase 2: Performance & Observability (Week 2)
| **Item** | **Status** | **ETA** | **Owner** |
|----------|------------|---------|-----------|
| No iGPU Acceleration | ⏳ Pending | Day 1 | Dev Team |
| Limited Monitoring | ⏳ Pending | Day 2 | Dev Team |
| Basic Test Coverage | ⏳ Pending | Day 7 | QA Team |

### Phase 3: Architecture & Documentation (Week 3)
| **Item** | **Status** | **ETA** | **Owner** |
|----------|------------|---------|-----------|
| Static FAISS Indexing | ⏳ Pending | Day 1 | Dev Team |
| Single-Worker Deployment | ⏳ Pending | Day 2 | DevOps Team |
| Missing Input Validation | ⏳ Pending | Day 3 | Security Team |
| Incomplete MkDocs Structure | ⏳ Pending | Day 4 | Documentation Team |

### Future Enhancements (Post-Production)
| **Item** | **Status** | **Priority** | **Timeline** |
|----------|------------|--------------|--------------|
| No Caching Strategy | ⏳ Pending | Low | Q1 2026 |
| No Circuit Breaker Fallbacks | ⏳ Pending | Low | Q1 2026 |
| No Property-Based Testing | ⏳ Pending | Low | Q1 2026 |
| No Resource Monitoring | ⏳ Pending | Low | Q2 2026 |

---

## 🎯 Debt Reduction Strategy

### Immediate Actions (This Week)
1. **Security First**: Address all critical security issues
2. **Dependencies**: Install missing core packages
3. **Validation**: Test all changes thoroughly

### Short-term Goals (Next 2 Weeks)
1. **Performance**: Implement iGPU acceleration
2. **Observability**: Add comprehensive monitoring
3. **Testing**: Enhance test coverage

### Long-term Goals (Next Month)
1. **Architecture**: Improve scalability and resilience
2. **Documentation**: Complete user and developer guides
3. **Quality**: Implement advanced testing strategies

### Success Metrics
- **Security**: Zero critical vulnerabilities
- **Performance**: 40% throughput improvement
- **Reliability**: 99.5% uptime target
- **Quality**: 90% test coverage
- **Documentation**: 100% Diátaxis completion

---

**Next Review**: January 21, 2026 (After Phase 1)  
**Debt Reduction Target**: 80% of critical debt resolved  
**Overall Goal**: 95% production readiness achieved

**Document Version**: 1.0  
**Last Updated**: January 14, 2026  
**Next Update**: January 21, 2026
