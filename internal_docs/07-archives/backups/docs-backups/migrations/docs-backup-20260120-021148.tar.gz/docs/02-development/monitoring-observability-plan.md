# 📊 Xoe-NovAi Monitoring & Observability Plan
## Production Integration Observability Strategy

**Last Updated**: January 14, 2026  
**Version**: v0.1.5 → v0.2.0 (Target)  
**Observability Maturity**: Level 1 → Level 4 (Target)  
**Monitoring Coverage**: 30% → 100% (Target)

---

## 📋 Observability Overview

### Current State Assessment
- **Logging**: Basic structured logging only
- **Metrics**: Limited Prometheus metrics
- **Tracing**: No distributed tracing
- **Alerting**: Basic health checks
- **Dashboards**: No comprehensive dashboards

### Target State (Post-Implementation)
- **Logging**: Comprehensive structured logging with correlation IDs
- **Metrics**: Full OpenTelemetry metrics collection
- **Tracing**: Complete distributed tracing across all services
- **Alerting**: Intelligent alerting with SLA-based thresholds
- **Dashboards**: Real-time operational dashboards

---

## 🎯 Observability Objectives

### 1. Comprehensive Visibility
**Goal**: Full observability across all system components

**Standards**:
- 100% request tracing across service boundaries
- Complete metrics coverage for all critical paths
- Structured logging with consistent correlation IDs
- Real-time performance monitoring

**Metrics**:
- Trace coverage: 100% of requests
- Metric collection: All critical components
- Log correlation: 100% of requests
- Dashboard refresh: Real-time (<5s)

### 2. Proactive Alerting
**Goal**: Detect and resolve issues before user impact

**Standards**:
- SLA-based alerting thresholds
- Intelligent noise reduction
- Escalation policies for critical issues
- Automated incident response

**Metrics**:
- Alert accuracy: >95% (low false positives)
- Mean Time To Detection (MTTD): <2 minutes
- Mean Time To Resolution (MTTR): <15 minutes
- Alert fatigue: <5% noise rate

### 3. Performance Optimization
**Goal**: Continuous performance monitoring and optimization

**Standards**:
- Performance SLA monitoring
- Resource utilization tracking
- Bottleneck identification
- Capacity planning insights

**Metrics**:
- Response time percentiles: p50, p95, p99
- Throughput tracking: Requests per second
- Resource utilization: CPU, memory, disk, network
- Performance regression detection: <1% degradation

### 4. User Experience Monitoring
**Goal**: Monitor end-user experience and satisfaction

**Standards**:
- Voice interface quality monitoring
- RAG response quality tracking
- User session analytics
- Error rate monitoring by user impact

**Metrics**:
- User satisfaction: Voice quality scores
- Session success rate: >95%
- Error impact: <1% user-facing errors
- Feature usage: Adoption tracking

---

## 📊 Monitoring Architecture

### 1. OpenTelemetry Integration

#### Application Instrumentation
```python
# app/XNAi_rag_app/main.py
from opentelemetry import trace, metrics
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.redis import RedisInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

# Initialize tracing and metrics
tracer = trace.get_tracer(__name__)
meter = metrics.get_meter(__name__)

# Create metrics
request_counter = meter.create_counter(
    "xnai_requests_total",
    description="Total number of requests"
)

response_latency = meter.create_histogram(
    "xnai_response_latency_seconds",
    description="Response latency in seconds"
)

token_rate = meter.create_gauge(
    "xnai_token_rate_tokens_per_second",
    description="Token generation rate"
)

# Instrument FastAPI
FastAPIInstrumentor.instrument_app(app)

# Instrument Redis
RedisInstrumentor().instrument()

# Instrument HTTP clients
HTTPXClientInstrumentor().instrument()
```

#### Custom Spans for Key Operations
```python
# app/XNAi_rag_app/main.py
@asynccontextmanager
async def lifespan(app: FastAPI):
    # LLM initialization span
    with tracer.start_as_current_span("llm_initialization") as span:
        try:
            global llm
            llm = get_llm()
            span.set_attribute("llm.model", "smollm2-135m-instruct")
            span.set_attribute("llm.quantization", "Q5_K_XL")
            span.set_status(trace.Status(trace.StatusCode.OK))
        except Exception as e:
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            raise
    
    # Vectorstore loading span
    with tracer.start_as_current_span("vectorstore_loading") as span:
        try:
            global vectorstore
            vectorstore = get_vectorstore(embeddings)
            span.set_attribute("vectorstore.type", "faiss")
            span.set_attribute("vectorstore.documents", vectorstore.index.ntotal)
            span.set_status(trace.Status(trace.StatusCode.OK))
        except Exception as e:
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            raise
    
    yield
```

#### Voice Interface Instrumentation
```python
# app/XNAi_rag_app/voice_interface.py
class VoiceInterface:
    async def transcribe(self, audio: bytes) -> str:
        with tracer.start_as_current_span("voice.stt.transcribe") as span:
            span.set_attribute("audio.size_bytes", len(audio))
            span.set_attribute("stt.provider", self.stt_provider.value)
            
            start_time = time.time()
            try:
                transcript = await self.stt_model.transcribe(audio)
                span.set_attribute("transcript.length", len(transcript))
                span.set_status(trace.Status(trace.StatusCode.OK))
                return transcript
            except Exception as e:
                span.record_exception(e)
                span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
                raise
            finally:
                span.set_attribute("stt.latency_seconds", time.time() - start_time)
    
    async def synthesize(self, text: str) -> bytes:
        with tracer.start_as_current_span("voice.tts.synthesize") as span:
            span.set_attribute("text.length", len(text))
            span.set_attribute("tts.provider", self.tts_provider.value)
            
            start_time = time.time()
            try:
                audio = await self.tts_model.synthesize(text)
                span.set_attribute("audio.size_bytes", len(audio))
                span.set_status(trace.Status(trace.StatusCode.OK))
                return audio
            except Exception as e:
                span.record_exception(e)
                span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
                raise
            finally:
                span.set_attribute("tts.latency_seconds", time.time() - start_time)
```

### 2. Prometheus Metrics Enhancement

#### Custom Metrics Collection
```python
# app/XNAi_rag_app/metrics.py
from prometheus_client import Counter, Histogram, Gauge, Info
import time

# Request metrics
REQUESTS_TOTAL = Counter(
    'xnai_requests_total',
    'Total number of requests',
    ['method', 'endpoint', 'status_code']
)

RESPONSE_LATENCY = Histogram(
    'xnai_response_latency_seconds',
    'Response latency in seconds',
    ['method', 'endpoint'],
    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
)

# Voice-specific metrics
VOICE_TRANSCRIPTIONS_TOTAL = Counter(
    'xnai_voice_transcriptions_total',
    'Total number of voice transcriptions',
    ['stt_provider', 'status']
)

VOICE_SYNTHESIS_TOTAL = Counter(
    'xnai_voice_synthesis_total',
    'Total number of voice syntheses',
    ['tts_provider', 'status']
)

VOICE_LATENCY = Histogram(
    'xnai_voice_latency_seconds',
    'Voice processing latency',
    ['operation'],  # 'transcribe' or 'synthesize'
    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
)

# RAG-specific metrics
RAG_RETRIEVALS_TOTAL = Counter(
    'xnai_rag_retrievals_total',
    'Total number of RAG retrievals',
    ['status']
)

RAG_RETRIEVAL_LATENCY = Histogram(
    'xnai_rag_retrieval_latency_seconds',
    'RAG retrieval latency',
    buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.0]
)

# LLM-specific metrics
LLM_GENERATIONS_TOTAL = Counter(
    'xnai_llm_generations_total',
    'Total number of LLM generations',
    ['model', 'status']
)

TOKEN_RATE = Gauge(
    'xnai_token_rate_tokens_per_second',
    'Current token generation rate'
)

# System metrics
MEMORY_USAGE = Gauge(
    'xnai_memory_usage_bytes',
    'Current memory usage in bytes'
)

CPU_USAGE = Gauge(
    'xnai_cpu_usage_percent',
    'Current CPU usage percentage'
)

# Circuit breaker metrics
CIRCUIT_BREAKER_STATE = Gauge(
    'xnai_circuit_breaker_state',
    'Circuit breaker state (0=closed, 1=open, 2=half-open)',
    ['breaker_name']
)

CIRCUIT_BREAKER_FAILURES = Counter(
    'xnai_circuit_breaker_failures_total',
    'Total number of circuit breaker failures',
    ['breaker_name']
)
```

#### Metrics Collection Middleware
```python
# app/XNAi_rag_app/main.py
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Record request
        REQUESTS_TOTAL.labels(
            method=request.method,
            endpoint=request.url.path,
            status_code=0  # Will be updated after response
        ).inc()
        
        # Process request
        response = await call_next(request)
        
        # Record response metrics
        duration = time.time() - start_time
        RESPONSE_LATENCY.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(duration)
        
        REQUESTS_TOTAL.labels(
            method=request.method,
            endpoint=request.url.path,
            status_code=response.status_code
        ).inc()
        
        return response
```

### 3. Structured Logging with Correlation

#### Correlation ID Middleware
```python
# app/XNAi_rag_app/logging_config.py
import uuid
import logging
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

class CorrelationIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Generate or extract correlation ID
        correlation_id = request.headers.get('X-Correlation-ID', str(uuid.uuid4()))
        
        # Add to request state
        request.state.correlation_id = correlation_id
        
        # Add to logging context
        logging_context = {
            'correlation_id': correlation_id,
            'request_id': correlation_id,
            'user_agent': request.headers.get('User-Agent', 'unknown'),
            'client_ip': request.client.host if request.client else 'unknown'
        }
        
        # Process request with context
        with logging_context_manager(logging_context):
            response = await call_next(request)
            response.headers['X-Correlation-ID'] = correlation_id
            return response

class LoggingContextManager:
    def __init__(self, context):
        self.context = context
    
    def __enter__(self):
        # Add context to logger
        logger = logging.getLogger()
        old_factory = logger.makeRecord
        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            for key, value in self.context.items():
                setattr(record, key, value)
            return record
        logger.makeRecord = record_factory
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Restore original factory
        logger = logging.getLogger()
        logger.makeRecord = logger.makeRecord.__self__.makeRecord
```

#### Enhanced Log Configuration
```python
# app/XNAi_rag_app/logging_config.py
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
            'thread': record.thread,
            'process': record.process
        }
        
        # Add correlation ID if available
        if hasattr(record, 'correlation_id'):
            log_entry['correlation_id'] = record.correlation_id
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 
                          'filename', 'module', 'exc_info', 'exc_text', 'stack_info',
                          'lineno', 'funcName', 'created', 'msecs', 'relativeCreated',
                          'thread', 'threadName', 'processName', 'process', 'message']:
                log_entry[key] = value
        
        return json.dumps(log_entry)

def setup_logging():
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    
    # Create JSON formatter
    json_formatter = JSONFormatter()
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(json_formatter)
    root_logger.addHandler(console_handler)
    
    # File handler
    file_handler = logging.FileHandler('/app/XNAi_rag_app/logs/xnai.log')
    file_handler.setFormatter(json_formatter)
    root_logger.addHandler(file_handler)
    
    # Suppress noisy loggers
    logging.getLogger('uvicorn.access').setLevel(logging.WARNING)
    logging.getLogger('uvicorn.error').setLevel(logging.WARNING)
    logging.getLogger('asyncio').setLevel(logging.WARNING)
```

### 4. Health Checks and Readiness Probes

#### Comprehensive Health Check System
```python
# app/XNAi_rag_app/healthcheck.py
import asyncio
import time
from typing import Dict, Any, List, Tuple
from dataclasses import dataclass

@dataclass
class HealthCheckResult:
    name: str
    status: str  # 'healthy', 'unhealthy', 'degraded'
    message: str
    duration_ms: float
    details: Dict[str, Any] = None

class HealthChecker:
    def __init__(self):
        self.checks = {
            'llm': self.check_llm,
            'embeddings': self.check_embeddings,
            'memory': self.check_memory,
            'redis': self.check_redis,
            'vectorstore': self.check_vectorstore,
            'ryzen': self.check_ryzen,
            'crawler': self.check_crawler,
            'telemetry': self.check_telemetry
        }
    
    async def run_health_checks(self, targets: List[str] = None, critical_only: bool = False) -> Dict[str, Tuple[bool, str]]:
        """Run health checks and return results"""
        if targets is None:
            targets = list(self.checks.keys())
        
        results = {}
        
        for target in targets:
            if target in self.checks:
                try:
                    start_time = time.time()
                    result = await self.checks[target]()
                    duration = (time.time() - start_time) * 1000
                    
                    results[target] = (
                        result.status in ['healthy', 'degraded'],
                        f"{result.message} (took {duration:.1f}ms)"
                    )
                except Exception as e:
                    results[target] = (False, f"Health check failed: {str(e)}")
        
        return results
    
    async def check_llm(self) -> HealthCheckResult:
        """Check LLM availability and performance"""
        start_time = time.time()
        
        try:
            if llm is None:
                return HealthCheckResult(
                    name='llm',
                    status='unhealthy',
                    message='LLM not initialized',
                    duration_ms=(time.time() - start_time) * 1000
                )
            
            # Test LLM response
            test_prompt = "Hello"
            response = llm.invoke(test_prompt, max_tokens=10)
            
            if len(response) > 0:
                return HealthCheckResult(
                    name='llm',
                    status='healthy',
                    message='LLM responding normally',
                    duration_ms=(time.time() - start_time) * 1000,
                    details={'response_length': len(response)}
                )
            else:
                return HealthCheckResult(
                    name='llm',
                    status='degraded',
                    message='LLM responding but empty response',
                    duration_ms=(time.time() - start_time) * 1000
                )
        
        except Exception as e:
            return HealthCheckResult(
                name='llm',
                status='unhealthy',
                message=f'LLM error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_memory(self) -> HealthCheckResult:
        """Check memory usage and thresholds"""
        import psutil
        
        start_time = time.time()
        memory = psutil.virtual_memory()
        
        memory_percent = memory.percent
        memory_gb = memory.used / (1024 ** 3)
        
        if memory_percent > 90:
            status = 'unhealthy'
            message = f'Critical memory usage: {memory_percent:.1f}% ({memory_gb:.1f}GB)'
        elif memory_percent > 80:
            status = 'degraded'
            message = f'High memory usage: {memory_percent:.1f}% ({memory_gb:.1f}GB)'
        else:
            status = 'healthy'
            message = f'Memory usage normal: {memory_percent:.1f}% ({memory_gb:.1f}GB)'
        
        return HealthCheckResult(
            name='memory',
            status=status,
            message=message,
            duration_ms=(time.time() - start_time) * 1000,
            details={
                'memory_percent': memory_percent,
                'memory_gb': memory_gb,
                'total_gb': memory.total / (1024 ** 3)
            }
        )
    
    async def check_redis(self) -> HealthCheckResult:
        """Check Redis connectivity and performance"""
        import redis.asyncio as aioredis
        
        start_time = time.time()
        
        try:
            # Test Redis connection
            redis_client = aioredis.from_url("redis://redis:6379")
            await redis_client.ping()
            
            # Test Redis performance
            test_key = f"health_check_{int(time.time())}"
            await redis_client.set(test_key, "test_value", ex=60)
            value = await redis_client.get(test_key)
            await redis_client.delete(test_key)
            
            if value == b"test_value":
                return HealthCheckResult(
                    name='redis',
                    status='healthy',
                    message='Redis responding normally',
                    duration_ms=(time.time() - start_time) * 1000
                )
            else:
                return HealthCheckResult(
                    name='redis',
                    status='degraded',
                    message='Redis connectivity issues',
                    duration_ms=(time.time() - start_time) * 1000
                )
        
        except Exception as e:
            return HealthCheckResult(
                name='redis',
                status='unhealthy',
                message=f'Redis error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_vectorstore(self) -> HealthCheckResult:
        """Check vectorstore availability and performance"""
        start_time = time.time()
        
        try:
            if vectorstore is None:
                return HealthCheckResult(
                    name='vectorstore',
                    status='unhealthy',
                    message='Vectorstore not initialized',
                    duration_ms=(time.time() - start_time) * 1000
                )
            
            # Test vectorstore search
            test_query = "test"
            docs = vectorstore.similarity_search(test_query, k=1)
            
            if docs:
                return HealthCheckResult(
                    name='vectorstore',
                    status='healthy',
                    message=f'Vectorstore responding with {len(docs)} results',
                    duration_ms=(time.time() - start_time) * 1000,
                    details={'results_count': len(docs)}
                )
            else:
                return HealthCheckResult(
                    name='vectorstore',
                    status='degraded',
                    message='Vectorstore responding but no results',
                    duration_ms=(time.time() - start_time) * 1000
                )
        
        except Exception as e:
            return HealthCheckResult(
                name='vectorstore',
                status='unhealthy',
                message=f'Vectorstore error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_ryzen(self) -> HealthCheckResult:
        """Check AMD Ryzen optimizations"""
        start_time = time.time()
        
        try:
            # Check CPU info
            with open('/proc/cpuinfo', 'r') as f:
                cpuinfo = f.read()
            
            if 'AMD' in cpuinfo:
                # Check if optimizations are active
                import os
                openblas_threads = os.getenv('OPENBLAS_NUM_THREADS', '1')
                n_threads = os.getenv('N_THREADS', '1')
                
                return HealthCheckResult(
                    name='ryzen',
                    status='healthy',
                    message=f'AMD CPU detected, optimizations active (BLAS: {openblas_threads}, N: {n_threads})',
                    duration_ms=(time.time() - start_time) * 1000,
                    details={
                        'cpu_vendor': 'AMD',
                        'openblas_threads': openblas_threads,
                        'n_threads': n_threads
                    }
                )
            else:
                return HealthCheckResult(
                    name='ryzen',
                    status='degraded',
                    message='Non-AMD CPU detected, optimizations may not be optimal',
                    duration_ms=(time.time() - start_time) * 1000
                )
        
        except Exception as e:
            return HealthCheckResult(
                name='ryzen',
                status='unhealthy',
                message=f'Ryzen check error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_crawler(self) -> HealthCheckResult:
        """Check crawler service availability"""
        start_time = time.time()
        
        try:
            # Test crawler connectivity
            import httpx
            
            async with httpx.AsyncClient() as client:
                response = await client.get("http://crawler:8000/health", timeout=5.0)
                
                if response.status_code == 200:
                    return HealthCheckResult(
                        name='crawler',
                        status='healthy',
                        message='Crawler service responding',
                        duration_ms=(time.time() - start_time) * 1000
                    )
                else:
                    return HealthCheckResult(
                        name='crawler',
                        status='degraded',
                        message=f'Crawler service unhealthy (status: {response.status_code})',
                        duration_ms=(time.time() - start_time) * 1000
                    )
        
        except Exception as e:
            return HealthCheckResult(
                name='crawler',
                status='unhealthy',
                message=f'Crawler check error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_telemetry(self) -> HealthCheckResult:
        """Check telemetry and metrics collection"""
        start_time = time.time()
        
        try:
            # Check if metrics endpoint is available
            import httpx
            
            async with httpx.AsyncClient() as client:
                response = await client.get("http://localhost:8002/metrics", timeout=5.0)
                
                if response.status_code == 200:
                    return HealthCheckResult(
                        name='telemetry',
                        status='healthy',
                        message='Telemetry metrics available',
                        duration_ms=(time.time() - start_time) * 1000
                    )
                else:
                    return HealthCheckResult(
                        name='telemetry',
                        status='degraded',
                        message=f'Telemetry metrics unavailable (status: {response.status_code})',
                        duration_ms=(time.time() - start_time) * 1000
                    )
        
        except Exception as e:
            return HealthCheckResult(
                name='telemetry',
                status='unhealthy',
                message=f'Telemetry check error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )
    
    async def check_embeddings(self) -> HealthCheckResult:
        """Check embeddings service"""
        start_time = time.time()
        
        try:
            if embeddings is None:
                return HealthCheckResult(
                    name='embeddings',
                    status='unhealthy',
                    message='Embeddings not initialized',
                    duration_ms=(time.time() - start_time) * 1000
                )
            
            # Test embedding generation
            test_text = "test"
            embedding = embeddings.embed_query(test_text)
            
            if len(embedding) > 0:
                return HealthCheckResult(
                    name='embeddings',
                    status='healthy',
                    message=f'Embeddings working (dimension: {len(embedding)})',
                    duration_ms=(time.time() - start_time) * 1000,
                    details={'embedding_dimension': len(embedding)}
                )
            else:
                return HealthCheckResult(
                    name='embeddings',
                    status='degraded',
                    message='Embeddings returning empty vectors',
                    duration_ms=(time.time() - start_time) * 1000
                )
        
        except Exception as e:
            return HealthCheckResult(
                name='embeddings',
                status='unhealthy',
                message=f'Embeddings error: {str(e)}',
                duration_ms=(time.time() - start_time) * 1000
            )

# Global health checker instance
health_checker = HealthChecker()
```

---

## 🚨 Alerting Strategy

### 1. SLA-Based Alerting

#### Alert Configuration
```yaml
# alerting/alert_rules.yml
groups:
  - name: xnai_performance
    rules:
      - alert: HighResponseTime
        expr: histogram_quantile(0.95, xnai_response_latency_seconds_bucket) > 2.0
        for: 2m
        labels:
          severity: warning
          service: xnai
        annotations:
          summary: "High response time detected"
          description: "95th percentile response time is {{ $value }}s"
      
      - alert: HighErrorRate
        expr: rate(xnai_requests_total{status_code=~"5.."}[5m]) / rate(xnai_requests_total[5m]) > 0.05
        for: 1m
        labels:
          severity: critical
          service: xnai
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value | humanizePercentage }}"
      
      - alert: MemoryUsageHigh
        expr: xnai_memory_usage_bytes / 1024 / 1024 / 1024 > 4.5
        for: 5m
        labels:
          severity: warning
          service: xnai
        annotations:
          summary: "High memory usage detected"
          description: "Memory usage is {{ $value }}GB"
      
      - alert: LLMNotResponding
        expr: up{job="xnai_llm"} == 0
        for: 1m
        labels:
          severity: critical
          service: xnai
        annotations:
          summary: "LLM service not responding"
          description: "LLM service has been down for more than 1 minute"
  
  - name: xnai_voice
    rules:
      - alert: VoiceLatencyHigh
        expr: histogram_quantile(0.95, xnai_voice_latency_seconds_bucket{operation="transcribe"}) > 0.5
        for: 2m
        labels:
          severity: warning
          service: xnai_voice
        annotations:
          summary: "High voice transcription latency"
          description: "Voice transcription latency is {{ $value }}s"
      
      - alert: VoiceServiceDown
        expr: up{job="xnai_voice"} == 0
        for: 30s
        labels:
          severity: critical
          service: xnai_voice
        annotations:
          summary: "Voice service down"
          description: "Voice service has been down for more than 30 seconds"
  
  - name: xnai_rag
    rules:
      - alert: RAGLatencyHigh
        expr: histogram_quantile(0.95, xnai_rag_retrieval_latency_seconds_bucket) > 1.0
        for: 2m
        labels:
          severity: warning
          service: xnai_rag
        annotations:
          summary: "High RAG retrieval latency"
          description: "RAG retrieval latency is {{ $value }}s"
      
      - alert: VectorstoreDown
        expr: up{job="xnai_vectorstore"} == 0
        for: 1m
        labels:
          severity: critical
          service: xnai_rag
        annotations:
          summary: "Vectorstore service down"
          description: "Vectorstore service has been down for more than 1 minute"
```

### 2. Intelligent Alerting

#### Alert Noise Reduction
```python
# alerting/alert_manager.py
class AlertManager:
    def __init__(self):
        self.alert_history = {}
        self.suppression_rules = {
            'maintenance_window': self.is_maintenance_window,
            'known_issue': self.is_known_issue,
            'flapping_detection': self.is_flapping
        }
    
    def is_maintenance_window(self, alert_name: str) -> bool:
        """Check if alert is during maintenance window"""
        import datetime
        now = datetime.datetime.now()
        # Maintenance window: Sunday 2-4 AM
        if now.weekday() == 6 and 2 <= now.hour < 4:
            return True
        return False
    
    def is_known_issue(self, alert_name: str) -> bool:
        """Check if alert is for known issue"""
        known_issues = [
            'temporary_network_glitch',
            'scheduled_maintenance'
        ]
        return alert_name in known_issues
    
    def is_flapping(self, alert_name: str) -> bool:
        """Detect alert flapping (rapid state changes)"""
        if alert_name not in self.alert_history:
            return False
        
        history = self.alert_history[alert_name]
        if len(history) < 5:
            return False
        
        # Check if alert has changed state more than 3 times in last 10 minutes
        recent_changes = [h for h in history if time.time() - h['timestamp'] < 600]
        state_changes = sum(1 for i in range(1, len(recent_changes)) 
                          if recent_changes[i]['state'] != recent_changes[i-1]['state'])
        
        return state_changes > 3
    
    def should_suppress_alert(self, alert_name: str, alert_data: dict) -> bool:
        """Determine if alert should be suppressed"""
        for rule_name, rule_func in self.suppression_rules.items():
            if rule_func(alert_name):
                return True
        return False
    
    def process_alert(self, alert_name: str, alert_data: dict):
        """Process incoming alert"""
        if self.should_suppress_alert(alert_name, alert_data):
            logging.info(f"Suppressing alert: {alert_name}")
            return
        
        # Record alert history
        if alert_name not in self.alert_history:
            self.alert_history[alert_name] = []
        
        self.alert_history[alert_name].append({
            'timestamp': time.time(),
            'state': alert_data.get('state', 'firing'),
            'severity': alert_data.get('severity', 'unknown')
        })
        
        # Send alert
        self.send_alert(alert_name, alert_data)
    
    def send_alert(self, alert_name: str, alert_data: dict):
        """Send alert to appropriate channels"""
        severity = alert_data.get('severity', 'unknown')
        
        if severity == 'critical':
            self.send_slack_alert(alert_name, alert_data)
            self.send_email_alert(alert_name, alert_data)
            self.send_pagerduty_alert(alert_name, alert_data)
        elif severity == 'warning':
            self.send_slack_alert(alert_name, alert_data)
        else:
            logging.info(f"Alert processed: {alert_name}")
```

### 3. Escalation Policies

#### Escalation Configuration
```yaml
# alerting/escalation.yml
escalation_policies:
  critical:
    - level: 1
      targets: ["on_call_engineer"]
      wait_time: 5m
    - level: 2
      targets: ["team_lead"]
      wait_time: 10m
    - level: 3
      targets: ["engineering_manager"]
      wait_time: 15m
  
  warning:
    - level: 1
      targets: ["on_call_engineer"]
      wait_time: 15m
    - level: 2
      targets: ["team_lead"]
      wait_time: 30m

notification_channels:
  slack:
    webhook_url: "https://hooks.slack.com/services/..."
    channel: "#xnai-alerts"
  
  email:
    smtp_server: "smtp.company.com"
    recipients: ["oncall@company.com"]
  
  pagerduty:
    integration_key: "your-pagerduty-key"
    service_key: "xnai-production"
```

---

## 📈 Dashboard Configuration

### 1. Grafana Dashboard Setup

#### Main Dashboard Configuration
```json
{
  "dashboard": {
    "title": "Xoe-NovAi Production Monitoring",
    "tags": ["xnai", "production"],
    "timezone": "UTC",
    "panels": [
      {
        "title": "System Overview",
        "type": "stat",
        "targets": [
          {
            "expr": "up{job=~'xnai.*'}",
            "legendFormat": "{{job}}"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "mappings": [
              {"options": {"0": {"text": "DOWN"}}, "type": "value"},
              {"options": {"1": {"text": "UP"}}, "type": "value"}
            ]
          }
        }
      },
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(xnai_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ]
      },
      {
        "title": "Response Time Percentiles",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.50, rate(xnai_response_latency_seconds_bucket[5m]))",
            "legendFormat": "p50"
          },
          {
            "expr": "histogram_quantile(0.95, rate(xnai_response_latency_seconds_bucket[5m]))",
            "legendFormat": "p95"
          },
          {
            "expr": "histogram_quantile(0.99, rate(xnai_response_latency_seconds_bucket[5m]))",
            "legendFormat": "p99"
          }
        ]
      },
      {
        "title": "Voice Processing Metrics",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(xnai_voice_transcriptions_total[5m])",
            "legendFormat": "STT Rate"
          },
          {
            "expr": "rate(xnai_voice_synthesis_total[5m])",
            "legendFormat": "TTS Rate"
          },
          {
            "expr": "histogram_quantile(0.95, rate(xnai_voice_latency_seconds_bucket[5m]))",
            "legendFormat": "Voice Latency p95"
          }
        ]
      },
      {
        "title": "RAG Performance",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(xnai_rag_retrievals_total[5m])",
            "legendFormat": "RAG Retrieval Rate"
          },
          {
            "expr": "histogram_quantile(0.95, rate(xnai_rag_retrieval_latency_seconds_bucket[5m]))",
            "legendFormat": "RAG Latency p95"
          }
        ]
      },
      {
        "title": "System Resources",
        "type": "graph",
        "targets": [
          {
            "expr": "xnai_memory_usage_bytes / 1024 / 1024 / 1024",
            "legendFormat": "Memory (GB)"
          },
          {
            "expr": "xnai_cpu_usage_percent",
            "legendFormat": "CPU (%)"
          }
        ]
      },
      {
        "title": "Circuit Breaker Status",
        "type": "stat",
        "targets": [
          {
            "expr": "xnai_circuit_breaker_state",
            "legendFormat": "{{breaker_name}}"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "mappings": [
              {"options": {"0": {"text": "CLOSED"}}, "type": "value"},
              {"options": {"1": {"text": "OPEN"}}, "type": "value"},
              {"options": {"2": {"text": "HALF-OPEN"}}, "type": "value"}
            ]
          }
        }
      }
    ]
  }
}
```

### 2. Voice-Specific Dashboard

#### Voice Quality Monitoring
```json
{
  "dashboard": {
    "title": "Xoe-NovAi Voice Interface Monitoring",
    "tags": ["xnai", "voice"],
    "panels": [
      {
        "title": "Voice Processing Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(xnai_voice_transcriptions_total[5m])",
            "legendFormat": "STT Rate"
          },
          {
            "expr": "rate(xnai_voice_synthesis_total[5m])",
            "legendFormat": "TTS Rate"
          }
        ]
      },
      {
        "title": "Voice Latency Breakdown",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.50, rate(xnai_voice_latency_seconds_bucket{operation=\"transcribe\"}[5m]))",
            "legendFormat": "STT p50"
          },
          {
            "expr": "histogram_quantile(0.95, rate(xnai_voice_latency_seconds_bucket{operation=\"transcribe\"}[5m]))",
            "legendFormat": "STT p95"
          },
          {
            "expr": "histogram_quantile(0.50, rate(xnai_voice_latency_seconds_bucket{operation=\"synthesize\"}[5m]))",
            "legendFormat": "TTS p50"
          },
          {
            "expr": "histogram_quantile(0.95, rate(xnai_voice_latency_seconds_bucket{operation=\"synthesize\"}[5m]))",
            "legendFormat": "TTS p95"
          }
        ]
      },
      {
        "title": "Voice Quality Metrics",
        "type": "stat",
        "targets": [
          {
            "expr": "xnai_voice_quality_score",
            "legendFormat": "Quality Score"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "min": 0,
            "max": 100,
            "thresholds": {
              "steps": [
                {"color": "red", "value": 0},
                {"color": "yellow", "value": 70},
                {"color": "green", "value": 90}
              ]
            }
          }
        }
      }
    ]
  }
}
```

---

## 🔧 Implementation Plan

### Phase 1: Foundation (Week 1)
- [ ] **OpenTelemetry Integration**
  - Add OpenTelemetry dependencies
  - Instrument FastAPI application
  - Add custom spans for key operations
  - Configure tracing exporters

- [ ] **Enhanced Metrics Collection**
  - Implement custom Prometheus metrics
  - Add metrics middleware
  - Configure metric collection intervals
  - Set up metrics validation

- [ ] **Structured Logging**
  - Implement correlation ID middleware
  - Create JSON log formatter
  - Add structured logging configuration
  - Set up log aggregation

### Phase 2: Advanced Monitoring (Week 2)
- [ ] **Comprehensive Health Checks**
  - Implement all health check functions
  - Add health check endpoints
  - Configure health check intervals
  - Set up health check alerting

- [ ] **Alerting System**
  - Configure Prometheus alerting rules
  - Set up AlertManager
  - Implement intelligent alerting
  - Configure escalation policies

- [ ] **Voice Interface Monitoring**
  - Add voice-specific metrics
  - Implement voice quality monitoring
  - Add voice latency tracking
  - Configure voice-specific alerts

### Phase 3: Dashboards & Optimization (Week 3)
- [ ] **Grafana Dashboards**
  - Create main system dashboard
  - Build voice-specific dashboard
  - Add RAG performance dashboard
  - Configure dashboard sharing

- [ ] **Performance Optimization**
  - Optimize metric collection overhead
  - Tune alert thresholds
  - Implement dashboard caching
  - Add performance monitoring

- [ ] **Documentation & Training**
  - Document monitoring procedures
  - Create runbooks for common issues
  - Train team on dashboard usage
  - Document alert response procedures

---

## 📊 Success Metrics

### Observability Maturity Metrics
- **Trace Coverage**: 100% of requests traced
- **Metric Collection**: All critical components monitored
- **Log Correlation**: 100% of requests have correlation IDs
- **Dashboard Refresh**: Real-time updates (<5s)

### Operational Metrics
- **Mean Time To Detection (MTTD)**: <2 minutes
- **Mean Time To Resolution (MTTR)**: <15 minutes
- **Alert Accuracy**: >95% (low false positives)
- **System Visibility**: 100% component coverage

### Performance Metrics
- **Monitoring Overhead**: <1% system performance impact
- **Dashboard Load Time**: <3 seconds
- **Alert Response Time**: <5 minutes for critical alerts
- **Data Retention**: 30 days for detailed metrics, 1 year for aggregates

---

**Next Review**: January 21, 2026 (After Phase 1 Implementation)  
**Observability Maturity Target**: Level 4 (Predictive and Automated)  
**Monitoring Coverage Target**: 100% of critical components

**Document Version**: 1.0  
**Last Updated**: January 14, 2026  
**Next Update**: January 21, 2026
