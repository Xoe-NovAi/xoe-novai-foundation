# Xoe-NovAi MkDocs Enterprise Implementations Manual v3.0

## Part 3: Extended Diátaxis Framework Implementation

**Estimated Time**: 90 minutes  
**Prerequisite**: Part 2 (Foundation Setup)  
**Outcome**: 20 structured content areas (5 domains × 4 quadrants)

---

## 📐 Understanding Extended Diátaxis for Xoe-NovAi

### Standard Diátaxis Framework

The Diátaxis framework organizes documentation into 4 quadrants based on user needs:

```
                PRACTICAL
                    │
        ┌───────────┼───────────┐
        │ TUTORIALS │  HOW-TO   │
LEARNING├───────────┼───────────┤ PROBLEM-SOLVING
        │EXPLANATION│ REFERENCE │
        └───────────┼───────────┘
                    │
              THEORETICAL
```

1. **Tutorials**: Learning-oriented, hands-on lessons for beginners
2. **How-To Guides**: Problem-solving, task-oriented steps for practitioners
3. **Reference**: Information-oriented, technical lookup for experts
4. **Explanation**: Understanding-oriented, conceptual depth for all levels

### Xoe-NovAi Extension: 5 Domains

Xoe-NovAi extends Diátaxis with 5 specialized domains from the stack architecture:

```
5 DOMAINS × 4 QUADRANTS = 20 CONTENT AREAS

1. VOICE AI DOMAIN
   ├─ Tutorials (learn voice commands)
   ├─ How-to (optimize STT/TTS)
   ├─ Reference (API/config)
   └─ Explanation (pipeline architecture)

2. RAG ARCHITECTURE DOMAIN  
   ├─ Tutorials (create RAG pipeline)
   ├─ How-to (tune retrieval)
   ├─ Reference (FAISS API)
   └─ Explanation (hybrid search theory)

3. SECURITY DOMAIN
   ├─ Tutorials (implement circuit breaker)
   ├─ How-to (SOC2 compliance)
   ├─ Reference (security API)
   └─ Explanation (zero-trust principles)

4. PERFORMANCE DOMAIN
   ├─ Tutorials (benchmarking basics)
   ├─ How-to (optimize Vulkan)
   ├─ Reference (performance metrics)
   └─ Explanation (optimization strategies)

5. LIBRARY CURATION DOMAIN
   ├─ Tutorials (curation workflow)
   ├─ How-to (assess quality)
   ├─ Reference (curator API)
   └─ Explanation (curation architecture)
```

---

## 🗂️ Complete Directory Structure

### Full Documentation Hierarchy

```bash
docs/
├─ index.md                          # Landing page
├─ tags.md                           # Tag index (auto-generated)
│
├─ tutorials/                        # QUADRANT 1: Learning-oriented
│  ├─ index.md                       # Tutorial hub
│  ├─ getting-started.md             # Quick start guide
│  │
│  ├─ voice-ai/                      # Domain 1: Voice AI
│  │  ├─ index.md
│  │  ├─ first-voice-app.md          # Build your first voice command
│  │  ├─ stt-optimization.md         # Optimize Whisper STT
│  │  └─ tts-kokoro.md               # Integrate Kokoro v2 TTS
│  │
│  ├─ rag/                           # Domain 2: RAG Architecture
│  │  ├─ index.md
│  │  ├─ first-rag-pipeline.md       # Create RAG from scratch
│  │  ├─ neural-bm25.md              # Implement Neural BM25
│  │  └─ faiss-indexing.md           # Build FAISS index
│  │
│  ├─ security/                      # Domain 3: Security
│  │  ├─ index.md
│  │  ├─ circuit-breaker.md          # Implement fault tolerance
│  │  └─ zero-trust.md               # Zero-trust setup
│  │
│  ├─ performance/                   # Domain 4: Performance
│  │  ├─ index.md
│  │  ├─ benchmarking.md             # Performance testing basics
│  │  └─ vulkan-acceleration.md      # Enable Vulkan GPU
│  │
│  └─ library/                       # Domain 5: Library Curation
│     ├─ index.md
│     ├─ first-curation.md           # Curate your first content
│     └─ metadata-enrichment.md      # Add LLM metadata
│
├─ how-to/                           # QUADRANT 2: Problem-solving
│  ├─ index.md                       # How-to hub
│  ├─ voice-ai/
│  │  ├─ index.md
│  │  ├─ reduce-latency.md           # Achieve <300ms STT latency
│  │  ├─ noise-reduction.md          # Improve VAD accuracy
│  │  └─ multilingual.md             # Support 5 languages
│  ├─ rag/
│  │  ├─ index.md
│  │  ├─ improve-recall.md           # Boost retrieval accuracy
│  │  ├─ query-expansion.md          # Implement query variants
│  │  └─ hybrid-search.md            # Combine BM25 + FAISS
│  ├─ security/
│  │  ├─ index.md
│  │  ├─ soc2-compliance.md          # Achieve SOC2 certification
│  │  ├─ audit-logging.md            # Implement audit trails
│  │  └─ rbac-setup.md               # Configure role-based access
│  ├─ performance/
│  │  ├─ index.md
│  │  ├─ optimize-memory.md          # Stay under 4GB budget
│  │  ├─ gpu-offload.md              # Vulkan GPU acceleration
│  │  └─ batch-processing.md         # Optimize throughput
│  └─ library/
│     ├─ index.md
│     ├─ quality-assessment.md       # Evaluate content quality
│     ├─ deduplication.md            # Remove duplicate content
│     └─ ethical-sourcing.md         # Copyright compliance
│
├─ reference/                        # QUADRANT 3: Information lookup
│  ├─ index.md                       # Reference hub
│  ├─ voice-ai/
│  │  ├─ index.md
│  │  ├─ piper-api.md                # Piper ONNX TTS API
│  │  ├─ whisper-config.md           # Whisper configuration
│  │  └─ kokoro-params.md            # Kokoro v2 parameters
│  ├─ rag/
│  │  ├─ index.md
│  │  ├─ faiss-api.md                # FAISS Python API
│  │  ├─ qdrant-api.md               # Qdrant vector DB API
│  │  └─ embeddings-models.md        # Available embedding models
│  ├─ security/
│  │  ├─ index.md
│  │  ├─ circuit-breaker-api.md      # pycircuitbreaker API
│  │  └─ security-headers.md         # HTTP security headers
│  ├─ performance/
│  │  ├─ index.md
│  │  ├─ benchmarks.md               # Performance benchmarks
│  │  └─ vulkan-api.md               # Vulkan compute API
│  └─ library/
│     ├─ index.md
│     ├─ curation-api.md             # Curator service API
│     └─ metadata-schema.md          # Metadata JSON schema
│
└─ explanation/                      # QUADRANT 4: Understanding concepts
   ├─ index.md                       # Explanation hub
   ├─ voice-ai/
   │  ├─ index.md
   │  ├─ voice-pipeline.md           # Voice processing architecture
   │  ├─ latency-breakdown.md        # Where latency comes from
   │  └─ prosody-enhancement.md      # TTS naturalness techniques
   ├─ rag/
   │  ├─ index.md
   │  ├─ hybrid-search-theory.md     # Why BM25 + vectors works
   │  ├─ chunking-strategies.md      # Document chunking approaches
   │  └─ graph-rag.md                # GraphRAG knowledge graphs
   ├─ security/
   │  ├─ index.md
   │  ├─ zero-trust.md               # Zero-trust principles
   │  └─ threat-model.md             # Xoe-NovAi threat model
   ├─ performance/
   │  ├─ index.md
   │  ├─ optimization-strategy.md    # Performance optimization approach
   │  └─ hardware-selection.md       # Choosing hardware for Xoe-NovAi
   └─ library/
      ├─ index.md
      ├─ curation-philosophy.md      # Why curation matters
      └─ quality-metrics.md          # Measuring content quality
```

**Total Pages**: 100+ (20 hubs + 80+ content pages)

---

## 📝 Frontmatter Schema (Critical!)

### Standard Metadata Template

**Every page must include this frontmatter**:

```yaml
---
title: "Page Title (SEO-optimized, <60 chars)"
description: "Short description for search results (120-160 chars)"
quadrant: tutorials          # tutorials|how-to|reference|explanation
domain: voice-ai             # voice-ai|rag|security|performance|library
expertise_level: beginner    # beginner|intermediate|advanced|expert
tags: 
  - voice
  - optimization
  - latency
last_updated: "2026-01-19"
status: stable               # draft|review|stable|deprecated
prerequisites:
  - "tutorials/getting-started.md"
related_pages:
  - "how-to/voice-ai/reduce-latency.md"
  - "explanation/voice-ai/voice-pipeline.md"
estimated_time: "20 minutes"  # For tutorials/how-to
---
```

### Frontmatter Field Definitions

**Required Fields**:
- `title`: Page title for navigation and SEO
- `description`: Meta description for search engines
- `quadrant`: Diátaxis category
- `domain`: Xoe-NovAi domain specialization
- `expertise_level`: Reader skill level
- `tags`: Topic tags (3-5 recommended)

**Optional Fields**:
- `last_updated`: ISO date (auto-filled by git-revision-date plugin)
- `status`: Content lifecycle stage
- `prerequisites`: Links to prerequisite pages
- `related_pages`: Cross-references
- `estimated_time`: Reading/completion time
- `authors`: Contributors (for multi-author docs)

### Example: Tutorial Page

**`docs/tutorials/voice-ai/first-voice-app.md`**:

```markdown
---
title: "Build Your First Voice Command (20 min)"
description: "Create a working voice-controlled Python app using Xoe-NovAi's Piper TTS and Whisper STT in under 20 minutes"
quadrant: tutorials
domain: voice-ai
expertise_level: beginner
tags:
  - tutorial
  - voice
  - hands-on
  - piper
  - whisper
status: stable
prerequisites:
  - "tutorials/getting-started.md"
related_pages:
  - "how-to/voice-ai/reduce-latency.md"
  - "explanation/voice-ai/voice-pipeline.md"
  - "reference/voice-ai/piper-api.md"
estimated_time: "20 minutes"
---

# Build Your First Voice Command

Learn to create a working voice-controlled app in 20 minutes.

## What You'll Build

A Python application that:
- Listens for voice input via microphone
- Processes speech with Whisper STT (<300ms latency)
- Generates natural responses with Piper TTS
- Responds with synthesized voice output

## Prerequisites

- Python 3.12+ installed
- Microphone and speakers
- 5 minutes for setup
- Basic Python knowledge helpful but not required

## Step-by-Step

### 1. Install Xoe-NovAi Voice Components

```bash
pip install xoe-novai[voice]
```

### 2. Create Your First Voice App

```python
from xoe_novai import VoiceApp

# Initialize voice application
app = VoiceApp(
    stt_model="whisper-distil-large-v3-turbo",
    tts_model="piper-kokoro-v2-en",
    latency_target=300  # ms
)

# Listen and respond
print("Speak now...")
response = app.listen_and_respond()
print(f"You said: {response.transcript}")
print(f"Latency: {response.latency_ms}ms")
```

### 3. Run and Test

```bash
python voice_app.py
```

**Expected Output**:
```
Speak now...
You said: "What is the weather today?"
Latency: 287ms
[Voice response plays through speakers]
```

## Success Criteria

✅ Voice input recognized with <300ms latency  
✅ Natural TTS output generated  
✅ Round-trip time <500ms total  

## Next Steps

Now that you have a working voice app, explore:

- **[Reduce Latency](../../how-to/voice-ai/reduce-latency.md)**: Optimize to <100ms
- **[Multi-Language Support](multilingual.md)**: Add 5 languages
- **[Voice Pipeline Architecture](../../explanation/voice-ai/voice-pipeline.md)**: Understand internals

## Troubleshooting

**Issue**: No microphone detected  
**Solution**: Check `app.list_audio_devices()` and set `input_device_id`

**Issue**: High latency (>500ms)  
**Solution**: See [Performance Tuning Guide](../../how-to/voice-ai/reduce-latency.md)

---

**Time**: 20 min | **Difficulty**: ⭐ Beginner | **Domain**: Voice AI
```

---

## 🎨 Visual Indicators for Diátaxis

### Custom CSS for Quadrant Styling

**Create `docs/assets/stylesheets/diataxis.css`**:

```css
/* Diátaxis visual indicators */
:root {
  --diataxis-tutorial: #4caf50;      /* Green - learning */
  --diataxis-howto: #ff9800;         /* Orange - problem-solving */
  --diataxis-reference: #2196f3;     /* Blue - information */
  --diataxis-explanation: #9c27b0;   /* Purple - understanding */
}

/* Page header color-coding by quadrant */
article[data-md-quadrant="tutorials"] h1::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 12px;
  background-color: var(--diataxis-tutorial);
  vertical-align: middle;
}

article[data-md-quadrant="how-to"] h1::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 12px;
  background-color: var(--diataxis-howto);
  vertical-align: middle;
}

article[data-md-quadrant="reference"] h1::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 12px;
  background-color: var(--diataxis-reference);
  vertical-align: middle;
}

article[data-md-quadrant="explanation"] h1::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 12px;
  background-color: var(--diataxis-explanation);
  vertical-align: middle;
}

/* Quadrant badges */
.quadrant-badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 16px;
  font-size: 0.875rem;
  font-weight: 500;
  margin-left: 8px;
}

.quadrant-badge.tutorials {
  background-color: var(--diataxis-tutorial);
  color: white;
}

.quadrant-badge.how-to {
  background-color: var(--diataxis-howto);
  color: white;
}

.quadrant-badge.reference {
  background-color: var(--diataxis-reference);
  color: white;
}

.quadrant-badge.explanation {
  background-color: var(--diataxis-explanation);
  color: white;
}

/* Domain tags */
.domain-tag {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  background-color: #f5f5f5;
  border-radius: 12px;
  font-size: 0.75rem;
  margin-right: 4px;
}

.domain-tag::before {
  content: "🔖";
  margin-right: 4px;
}

/* Expertise level indicators */
.expertise-beginner::before {
  content: "⭐";
}

.expertise-intermediate::before {
  content: "⭐⭐";
}

.expertise-advanced::before {
  content: "⭐⭐⭐";
}

.expertise-expert::before {
  content: "⭐⭐⭐⭐";
}
```

**Add to `mkdocs.yml`**:

```yaml
extra_css:
  - assets/stylesheets/diataxis.css
```

### JavaScript for Dynamic Metadata

**Create `docs/assets/javascripts/diataxis.js`**:

```javascript
/* Inject Diátaxis metadata into DOM */
document$.subscribe(function() {
  // Get frontmatter metadata
  const meta = document.querySelector('meta[name="quadrant"]');
  const domain = document.querySelector('meta[name="domain"]');
  
  if (meta) {
    // Add quadrant attribute to article
    const article = document.querySelector('article');
    if (article) {
      article.setAttribute('data-md-quadrant', meta.content);
    }
    
    // Add quadrant badge to h1
    const h1 = document.querySelector('article h1');
    if (h1 && !h1.querySelector('.quadrant-badge')) {
      const badge = document.createElement('span');
      badge.className = `quadrant-badge ${meta.content}`;
      badge.textContent = meta.content.replace('-', ' ').toUpperCase();
      h1.appendChild(badge);
    }
  }
  
  if (domain) {
    // Add domain tag
    const h1 = document.querySelector('article h1');
    if (h1 && !h1.querySelector('.domain-tag')) {
      const tag = document.createElement('span');
      tag.className = 'domain-tag';
      tag.textContent = domain.content.replace('-', ' ');
      h1.appendChild(tag);
    }
  }
});
```

**Add to `mkdocs.yml`**:

```yaml
extra_javascript:
  - assets/javascripts/diataxis.js
```

---

## 🗺️ Navigation Configuration

### Complete Navigation Structure

**Update `mkdocs.yml` with full navigation**:

```yaml
nav:
  - Home: index.md
  
  - Tutorials:
      - tutorials/index.md
      - Getting Started: tutorials/getting-started.md
      - Voice AI:
          - tutorials/voice-ai/index.md
          - First Voice App: tutorials/voice-ai/first-voice-app.md
          - STT Optimization: tutorials/voice-ai/stt-optimization.md
          - Kokoro TTS: tutorials/voice-ai/tts-kokoro.md
      - RAG Architecture:
          - tutorials/rag/index.md
          - First RAG Pipeline: tutorials/rag/first-rag-pipeline.md
          - Neural BM25: tutorials/rag/neural-bm25.md
          - FAISS Indexing: tutorials/rag/faiss-indexing.md
      - Security:
          - tutorials/security/index.md
          - Circuit Breaker: tutorials/security/circuit-breaker.md
          - Zero Trust: tutorials/security/zero-trust.md
      - Performance:
          - tutorials/performance/index.md
          - Benchmarking: tutorials/performance/benchmarking.md
          - Vulkan GPU: tutorials/performance/vulkan-acceleration.md
      - Library Curation:
          - tutorials/library/index.md
          - First Curation: tutorials/library/first-curation.md
          - Metadata Enrichment: tutorials/library/metadata-enrichment.md
  
  - How-To Guides:
      - how-to/index.md
      - Voice AI:
          - how-to/voice-ai/index.md
          - Reduce Latency: how-to/voice-ai/reduce-latency.md
          - Noise Reduction: how-to/voice-ai/noise-reduction.md
          - Multilingual: how-to/voice-ai/multilingual.md
      - RAG:
          - how-to/rag/index.md
          - Improve Recall: how-to/rag/improve-recall.md
          - Query Expansion: how-to/rag/query-expansion.md
          - Hybrid Search: how-to/rag/hybrid-search.md
      - Security:
          - how-to/security/index.md
          - SOC2 Compliance: how-to/security/soc2-compliance.md
          - Audit Logging: how-to/security/audit-logging.md
          - RBAC Setup: how-to/security/rbac-setup.md
      - Performance:
          - how-to/performance/index.md
          - Optimize Memory: how-to/performance/optimize-memory.md
          - GPU Offload: how-to/performance/gpu-offload.md
          - Batch Processing: how-to/performance/batch-processing.md
      - Library:
          - how-to/library/index.md
          - Quality Assessment: how-to/library/quality-assessment.md
          - Deduplication: how-to/library/deduplication.md
          - Ethical Sourcing: how-to/library/ethical-sourcing.md
  
  - Reference:
      - reference/index.md
      - Voice AI API:
          - reference/voice-ai/index.md
          - Piper API: reference/voice-ai/piper-api.md
          - Whisper Config: reference/voice-ai/whisper-config.md
          - Kokoro Parameters: reference/voice-ai/kokoro-params.md
      - RAG API:
          - reference/rag/index.md
          - FAISS API: reference/rag/faiss-api.md
          - Qdrant API: reference/rag/qdrant-api.md
          - Embedding Models: reference/rag/embeddings-models.md
      - Security API:
          - reference/security/index.md
          - Circuit Breaker: reference/security/circuit-breaker-api.md
          - Security Headers: reference/security/security-headers.md
      - Performance:
          - reference/performance/index.md
          - Benchmarks: reference/performance/benchmarks.md
          - Vulkan API: reference/performance/vulkan-api.md
      - Library API:
          - reference/library/index.md
          - Curation API: reference/library/curation-api.md
          - Metadata Schema: reference/library/metadata-schema.md
  
  - Explanation:
      - explanation/index.md
      - Voice AI Concepts:
          - explanation/voice-ai/index.md
          - Voice Pipeline: explanation/voice-ai/voice-pipeline.md
          - Latency Breakdown: explanation/voice-ai/latency-breakdown.md
          - Prosody Enhancement: explanation/voice-ai/prosody-enhancement.md
      - RAG Concepts:
          - explanation/rag/index.md
          - Hybrid Search Theory: explanation/rag/hybrid-search-theory.md
          - Chunking Strategies: explanation/rag/chunking-strategies.md
          - Graph RAG: explanation/rag/graph-rag.md
      - Security Concepts:
          - explanation/security/index.md
          - Zero Trust: explanation/security/zero-trust.md
          - Threat Model: explanation/security/threat-model.md
      - Performance Concepts:
          - explanation/performance/index.md
          - Optimization Strategy: explanation/performance/optimization-strategy.md
          - Hardware Selection: explanation/performance/hardware-selection.md
      - Library Concepts:
          - explanation/library/index.md
          - Curation Philosophy: explanation/library/curation-philosophy.md
          - Quality Metrics: explanation/library/quality-metrics.md
  
  - Tags: tags.md
```

---

## ✅ Checkpoint 3: Diátaxis Structure Complete

**Validation Checklist**:

```bash
# 1. Verify directory structure
find docs -type d | sort

# Expected output: 25 directories (5 quadrants × 5 domains)

# 2. Check frontmatter consistency
grep -r "^quadrant:" docs/**/*.md | wc -l
# Should match number of content pages

# 3. Validate navigation
mkdocs build --strict
# Should build without errors

# 4. Test visual indicators
mkdocs serve
# Open http://127.0.0.1:8000 and verify:
# - Color-coded page headers
# - Quadrant badges
# - Domain tags
```

**Success Criteria**:
- [x] 20 content area directories created (5 domains × 4 quadrants)
- [x] Frontmatter schema implemented on all pages
- [x] Navigation configured with 100+ links
- [x] Visual indicators (CSS) working
- [x] Dynamic metadata (JS) injecting
- [x] Build completes with no warnings
- [x] All pages accessible in browser

---

**Next**: [Part 4: Hybrid Search & RAG Architecture →](xoe-mkdocs-manual-part4.md)

Implement FAISS + BM25 hybrid retrieval achieving 95%+ relevance.

---

*Xoe-NovAi MkDocs Enterprise Implementations Manual v3.0*  
*Part 3 of 7: Extended Diátaxis Framework*