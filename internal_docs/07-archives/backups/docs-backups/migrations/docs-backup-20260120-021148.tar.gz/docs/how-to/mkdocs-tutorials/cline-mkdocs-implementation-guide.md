# 🎯 **Cline AI Assistant: Complete Phase 3-4 Documentation Consolidation Guide**

**Version:** 2.0 (Research-Enhanced with 2026 Best Practices)  
**Target:** Xoe-NovAi Documentation System  
**Stack:** MkDocs 1.6.1, Material 10.0.2, Python 3.12  
**Last Updated:** 2026-01-20  

---

## 📋 **PRE-FLIGHT CHECKLIST**

Before starting implementation, verify:

- [ ] **Python Environment**: Python 3.12 with `uv` package manager
- [ ] **Container Runtime**: Podman configured (rootless mode)
- [ ] **Base MkDocs Setup**: Dockerfile.docs and mkdocs.yml exist
- [ ] **Git Repository**: Clean working tree, all changes committed
- [ ] **Backup**: Create backup of current `docs/` directory
- [ ] **Dependencies**: Install research-validated packages

---

## 🚨 **CRITICAL CORRECTIONS FROM GROK REVIEW**

### **1. MkDocs 1.6.1 Validation Configuration**

**ISSUE**: Original plan missing MkDocs 1.6+ granular validation controls.

**ACTION REQUIRED**: Update `mkdocs.yml` immediately.

```yaml
# ============================================================================
# VALIDATION (MkDocs 1.6+ Granular Controls)
# Research Source: MkDocs 1.6 release notes (2026-01-20)
# ============================================================================
validation:
  nav:
    omitted_files: warn          # Files not in nav (catch with --strict)
    not_found: warn              # Broken nav links
    absolute_links: warn         # Absolute nav links
  links:
    not_found: warn              # Broken page links
    absolute_links: relative_to_docs  # NEW in 1.6: Validate absolute links
    anchors: warn                # NEW in 1.6: Validate anchor links
    unrecognized_links: warn     # Unrecognized link formats

# Enable strict mode via CLI or environment variable
strict: !ENV [STRICT_MODE, false]  # Set STRICT_MODE=true in CI
```

**IMPLEMENTATION NOTES**:
- `relative_to_docs` is NEW in MkDocs 1.6 - converts absolute links automatically
- `anchors: warn` catches broken anchor links (#section-name)
- Always use `--strict` flag in CI/CD for zero-tolerance validation

---

### **2. Material for MkDocs 10.0 - Final Feature Release**

**CRITICAL CONTEXT**: Material 10.0 is the **last version with new features**. Post-10.0 = bug fixes only for 12 months minimum.

**ACTION REQUIRED**: Lock Material version and document limitations.

```txt
# requirements-docs.txt
mkdocs-material>=10.0.0,<11.0.0  # LOCKED: Final feature release (Jan 2025)
                                  # Only critical bug fixes after 10.0
                                  # Team focusing on Zensical successor
```

**FUTURE-PROOFING STRATEGY**:
- Monitor [Zensical](https://squidfunk.github.io/) development (Material successor)
- Document all Material 10.0 features in use for migration path
- Add "Future Migration" section to documentation roadmap

---

### **3. Python Frontmatter Integration**

**ISSUE**: Original `ContentClassifier` doesn't preserve existing frontmatter.

**ACTION REQUIRED**: Replace classification script with frontmatter-aware version.

```python
# scripts/classify_content.py - CORRECTED VERSION
import frontmatter
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass

@dataclass
class ContentMetadata:
    domain: str
    quadrant: str
    expertise_level: str
    tags: List[str]
    dependencies: List[str]
    existing_frontmatter: Dict  # NEW: Preserve existing metadata

class ContentClassifier:
    """AI-powered content classification with frontmatter integration"""
    
    DOMAIN_KEYWORDS = {
        'voice-ai': ['voice', 'speech', 'tts', 'stt', 'piper', 'whisper', 'kokoro'],
        'rag-architecture': ['rag', 'retrieval', 'vector', 'embedding', 'faiss', 'qdrant'],
        'security': ['security', 'auth', 'tls', 'encryption', 'audit', 'compliance'],
        'performance': ['performance', 'optimization', 'benchmark', 'latency', 'throughput'],
        'library-curation': ['curation', 'library', 'content', 'quality', 'metadata']
    }
    
    QUADRANT_KEYWORDS = {
        'tutorials': ['getting started', 'first steps', 'hello world', 'quick start', 'learning'],
        'how-to': ['how to', 'guide', 'step-by-step', 'configuration', 'setup', 'achieve'],
        'reference': ['api', 'parameters', 'configuration', 'specs', 'reference', 'command'],
        'explanation': ['why', 'concept', 'theory', 'architecture', 'design', 'understand']
    }
    
    def classify_file(self, file_path: Path) -> ContentMetadata:
        """Classify content using existing frontmatter + keyword analysis
        
        Research Note: python-frontmatter is the standard library for 
        Jekyll-style YAML front matter (eyeseast/python-frontmatter)
        """
        
        # ✅ Parse existing frontmatter first
        try:
            post = frontmatter.load(file_path)
            existing_meta = post.metadata
            content_text = post.content.lower()
        except Exception as e:
            print(f"⚠️  Failed to parse frontmatter in {file_path}: {e}")
            # Fallback: Read as plain text
            content_text = file_path.read_text().lower()
            existing_meta = {}
        
        # Check if already classified (trust existing classification)
        if 'domain' in existing_meta and 'quadrant' in existing_meta:
            print(f"✅ Using existing classification for {file_path.name}")
            return ContentMetadata(
                domain=existing_meta['domain'],
                quadrant=existing_meta['quadrant'],
                expertise_level=existing_meta.get('expertise_level', 'intermediate'),
                tags=existing_meta.get('tags', []),
                dependencies=existing_meta.get('dependencies', []),
                existing_frontmatter=existing_meta
            )
        
        # Otherwise, auto-classify based on content
        domain_scores = {}
        for domain, keywords in self.DOMAIN_KEYWORDS.items():
            score = sum(1 for keyword in keywords 
                       if keyword in content_text or keyword in file_path.name.lower())
            domain_scores[domain] = score
        
        domain = max(domain_scores, key=domain_scores.get)
        if domain_scores[domain] == 0:
            domain = 'general'
        
        # Quadrant classification
        quadrant_scores = {}
        for quadrant, keywords in self.QUADRANT_KEYWORDS.items():
            score = sum(1 for keyword in keywords if keyword in content_text)
            quadrant_scores[quadrant] = score
        
        quadrant = max(quadrant_scores, key=quadrant_scores.get)
        if quadrant_scores[quadrant] == 0:
            # Default based on content structure
            if '```' in content_text or 'example' in content_text:
                quadrant = 'tutorials'
            elif 'steps:' in content_text or 'procedure' in content_text:
                quadrant = 'how-to'
            elif 'class ' in content_text or 'function ' in content_text:
                quadrant = 'reference'
            else:
                quadrant = 'explanation'
        
        # Expertise level
        if 'advanced' in content_text or 'expert' in file_path.name:
            expertise = 'expert'
        elif 'intermediate' in content_text or len(content_text) > 5000:
            expertise = 'intermediate'
        else:
            expertise = 'beginner'
        
        return ContentMetadata(
            domain=domain,
            quadrant=quadrant,
            expertise_level=expertise,
            tags=self.extract_tags(content_text),
            dependencies=self.extract_dependencies(content_text),
            existing_frontmatter=existing_meta
        )
    
    def extract_tags(self, content: str) -> List[str]:
        """Extract relevant tags from content"""
        tags = []
        tag_keywords = {
            'docker': 'docker',
            'kubernetes': 'kubernetes',
            'security': 'security',
            'performance': 'performance',
            'api': 'api',
            'cli': 'cli'
        }
        for keyword, tag in tag_keywords.items():
            if keyword in content:
                tags.append(tag)
        return tags[:5]  # Max 5 tags
    
    def extract_dependencies(self, content: str) -> List[str]:
        """Extract file dependencies for linking"""
        deps = []
        import re
        # Look for relative links
        links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', content)
        for _, link in links:
            if not link.startswith('http') and ('../' in link or '.md' in link):
                deps.append(link)
        return deps[:10]  # Max 10 dependencies
    
    def update_frontmatter(self, file_path: Path, metadata: ContentMetadata):
        """Update frontmatter while preserving existing metadata
        
        Research Note: frontmatter.dump() writes back with preserved formatting
        Uses YAML safe mode by default (YAMLHandler)
        """
        
        # Load existing file
        try:
            post = frontmatter.load(file_path)
        except Exception as e:
            print(f"⚠️  Creating new frontmatter for {file_path}: {e}")
            post = frontmatter.Post('')
            post.content = file_path.read_text()
        
        # Merge new classification with existing metadata
        updated_meta = {
            **metadata.existing_frontmatter,  # Preserve existing
            'domain': metadata.domain,
            'quadrant': metadata.quadrant,
            'expertise_level': metadata.expertise_level,
            'tags': metadata.tags,
            'last_updated': '2026-01-20',
            'status': 'migrated',
            'diátaxis_validated': True  # NEW: Mark as validated
        }
        
        # Only add dependencies if they exist
        if metadata.dependencies:
            updated_meta['dependencies'] = metadata.dependencies
        
        # Update post metadata
        post.metadata = updated_meta
        
        # Write back to file (preserves content)
        with open(file_path, 'w', encoding='utf-8') as f:
            frontmatter.dump(post, f)
        
        print(f"✅ Updated frontmatter: {file_path.name} → {metadata.domain}/{metadata.quadrant}")
```

**DEPENDENCIES UPDATE**:
```txt
# requirements-docs.txt - Add frontmatter support
python-frontmatter>=1.1.0        # Jekyll-style YAML front matter parsing
pyyaml>=6.0                      # YAML processing (required by frontmatter)
```

**INSTALLATION**:
```bash
# Using uv (Xoe-NovAi standard)
uv pip install python-frontmatter>=1.1.0
```

---

### **4. Link Repair System - MkDocs 1.6 Validation Output**

**ISSUE**: Original regex doesn't match MkDocs 1.6 warning format.

**ACTION REQUIRED**: Update `LinkRepairSystem` with correct parsing patterns.

```python
# scripts/repair_links.py - CORRECTED VERSION
import re
from pathlib import Path
from typing import Dict, List, Tuple
from collections import defaultdict

class LinkRepairSystem:
    """Automated link repair using MkDocs 1.6 validation output
    
    Research Note: MkDocs 1.6 introduced granular validation with new warning formats
    - Broken file links: "Doc file 'X' contains a link to 'Y', which is not found"
    - Broken anchors: "contains a link '#Z', but the anchor is not found" (NEW in 1.6)
    - Absolute links: "contains absolute link 'Y'" (if validation.links.absolute_links: warn)
    """
    
    def __init__(self, docs_dir: Path):
        self.docs_dir = docs_dir
        self.link_map = self.build_link_map()
        self.broken_links: List[Tuple[str, str, str]] = []
    
    def build_link_map(self) -> Dict[str, List[str]]:
        """Build comprehensive link mapping from all files"""
        link_map = defaultdict(list)
        
        for md_file in self.docs_dir.rglob('*.md'):
            relative_path = md_file.relative_to(self.docs_dir)
            
            # Add various link formats
            link_map[md_file.name].append(str(relative_path))
            link_map[md_file.stem].append(str(relative_path))
            
            # Add with .md extension
            link_map[f"{md_file.stem}.md"].append(str(relative_path))
            
            # Add directory-based links
            if md_file.name == 'index.md':
                link_map[str(relative_path.parent)].append(str(relative_path))
                link_map[f"{relative_path.parent}/"].append(str(relative_path))
        
        return link_map
    
    def parse_mkdocs_validation_warnings(self, build_output: str) -> List[Dict]:
        """Parse MkDocs 1.6 validation warnings
        
        Example warnings from MkDocs 1.6:
        WARNING - Doc file 'tutorials/index.md' contains a link to 'voice-ai/setup.md', 
                  which is not found in the documentation files.
        WARNING - Doc file 'reference/api.md' contains a link '#nonexistent-anchor', 
                  but the anchor is not found on the page.
        WARNING - Doc file 'how-to/deploy.md' contains absolute link '/tutorials/start.md'
        """
        warnings = []
        
        # Pattern 1: Broken file links
        file_link_pattern = r"WARNING.*?Doc file '([^']+)'.*?link to '([^']+)'.*?not found"
        for match in re.finditer(file_link_pattern, build_output):
            source_file, broken_link = match.groups()
            warnings.append({
                'type': 'broken_file_link',
                'source': source_file,
                'broken_link': broken_link,
                'severity': 'high'
            })
        
        # Pattern 2: Broken anchor links (NEW in MkDocs 1.6)
        anchor_pattern = r"WARNING.*?Doc file '([^']+)'.*?link '([^']+)'.*?anchor.*?not found"
        for match in re.finditer(anchor_pattern, build_output):
            source_file, broken_anchor = match.groups()
            warnings.append({
                'type': 'broken_anchor',
                'source': source_file,
                'broken_link': broken_anchor,
                'severity': 'medium'
            })
        
        # Pattern 3: Absolute links (if validation.links.absolute_links: warn)
        absolute_pattern = r"WARNING.*?Doc file '([^']+)'.*?absolute.*?link.*?'([^']+)'"
        for match in re.finditer(absolute_pattern, build_output):
            source_file, absolute_link = match.groups()
            warnings.append({
                'type': 'absolute_link',
                'source': source_file,
                'broken_link': absolute_link,
                'severity': 'low'
            })
        
        # Pattern 4: Omitted files (not in nav)
        omitted_pattern = r"WARNING.*?'([^']+)'.*?not included in.*?nav"
        for match in re.finditer(omitted_pattern, build_output):
            omitted_file = match.groups()[0]
            warnings.append({
                'type': 'omitted_file',
                'source': None,
                'broken_link': omitted_file,
                'severity': 'low'
            })
        
        return warnings
    
    def repair_links_from_build_output(self, build_output: str):
        """Repair links using MkDocs 1.6 validation warnings"""
        
        warnings = self.parse_mkdocs_validation_warnings(build_output)
        
        print(f"\n🔍 Found {len(warnings)} link warnings to repair\n")
        
        # Group by severity
        high_priority = [w for w in warnings if w['severity'] == 'high']
        medium_priority = [w for w in warnings if w['severity'] == 'medium']
        low_priority = [w for w in warnings if w['severity'] == 'low']
        
        print(f"📊 Severity Breakdown:")
        print(f"  🔴 High (broken links): {len(high_priority)}")
        print(f"  🟡 Medium (broken anchors): {len(medium_priority)}")
        print(f"  🟢 Low (absolute/omitted): {len(low_priority)}\n")
        
        repaired_count = 0
        failed_count = 0
        
        # Process high priority first
        for warning in high_priority:
            if warning['type'] == 'broken_file_link':
                fixed_link = self.find_best_match(warning['broken_link'])
                
                if fixed_link:
                    source_path = self.docs_dir / warning['source']
                    self.apply_link_fix(
                        source_path, 
                        warning['broken_link'], 
                        fixed_link
                    )
                    repaired_count += 1
                    print(f"✅ Fixed: {warning['source']}: {warning['broken_link']} → {fixed_link}")
                else:
                    failed_count += 1
                    print(f"❌ No match found: {warning['broken_link']} in {warning['source']}")
        
        # Process medium priority (anchors)
        for warning in medium_priority:
            if warning['type'] == 'broken_anchor':
                print(f"⚠️  Broken anchor (manual fix needed): {warning['broken_link']} in {warning['source']}")
        
        # Process low priority (absolute/omitted)
        for warning in low_priority:
            if warning['type'] == 'absolute_link':
                relative_link = self.convert_absolute_to_relative(
                    warning['source'], 
                    warning['broken_link']
                )
                if relative_link:
                    source_path = self.docs_dir / warning['source']
                    self.apply_link_fix(
                        source_path,
                        warning['broken_link'],
                        relative_link
                    )
                    repaired_count += 1
                    print(f"✅ Converted absolute: {warning['broken_link']} → {relative_link}")
            elif warning['type'] == 'omitted_file':
                print(f"ℹ️  Omitted from nav: {warning['broken_link']}")
        
        print(f"\n📊 Link Repair Summary:")
        print(f"  ✅ Repaired: {repaired_count}")
        print(f"  ❌ Failed: {failed_count}")
        print(f"  📝 Total warnings: {len(warnings)}\n")
        
        return {
            'repaired': repaired_count,
            'failed': failed_count,
            'warnings': len(warnings)
        }
    
    def find_best_match(self, broken_link: str) -> str:
        """Find best matching link using fuzzy matching"""
        # Clean up the broken link
        clean_link = broken_link.strip('./').strip('/')
        
        # Direct match
        if clean_link in self.link_map:
            return self.link_map[clean_link][0]
        
        # Fuzzy matching by filename
        filename = Path(clean_link).name
        if filename in self.link_map:
            return self.link_map[filename][0]
        
        # Stem matching (without extension)
        stem = Path(clean_link).stem
        if stem in self.link_map:
            return self.link_map[stem][0]
        
        # Directory matching
        for mapped_links in self.link_map.values():
            for link in mapped_links:
                if filename in link or stem in link:
                    return link
        
        return None
    
    def convert_absolute_to_relative(self, source_file: str, absolute_link: str) -> str:
        """Convert absolute link to relative based on source file location"""
        
        # Remove leading slash
        target_path = absolute_link.lstrip('/')
        
        # Calculate relative path from source to target
        source_path = Path(source_file).parent
        try:
            # Try to make relative
            target = Path(target_path)
            common = Path(*source_path.parts[:len(set(source_path.parts) & set(target.parts))])
            
            # Calculate ../ prefix
            depth = len(source_path.parts) - len(common.parts)
            prefix = '../' * depth
            
            # Relative path from common ancestor
            relative_from_common = target.relative_to(common) if common != Path('.') else target
            
            return prefix + str(relative_from_common)
        except ValueError:
            # If can't make relative, just remove leading slash
            return target_path
    
    def apply_link_fix(self, source_file: Path, broken_link: str, fixed_link: str):
        """Apply link fix to source file"""
        
        if not source_file.exists():
            print(f"⚠️  Source file not found: {source_file}")
            return
        
        content = source_file.read_text(encoding='utf-8')
        
        # Replace all occurrences of the broken link
        # Handle both Markdown links and plain references
        patterns = [
            (f']({broken_link})', f']({fixed_link})'),  # Markdown links
            (f'"{broken_link}"', f'"{fixed_link}"'),    # Quoted links
            (f"'{broken_link}'", f"'{fixed_link}'"),    # Single-quoted links
        ]
        
        updated = False
        for old_pattern, new_pattern in patterns:
            if old_pattern in content:
                content = content.replace(old_pattern, new_pattern)
                updated = True
        
        if updated:
            source_file.write_text(content, encoding='utf-8')
```

---

### **5. Rich Library Progress Dashboard**

**ENHANCEMENT**: Add real-time migration tracking with professional UI.

```python
# scripts/migration_dashboard.py - Production-Ready Dashboard
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
    MofNCompleteColumn
)
from rich.table import Table
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from pathlib import Path
import time

console = Console()

class MigrationDashboard:
    """Real-time migration progress dashboard with Rich library
    
    Research Note: Rich 14.1.0 provides production-grade terminal UI
    - Flicker-free progress bars with Live display
    - Custom columns for detailed progress tracking
    - Thread-safe progress updates (safe for concurrent operations)
    """
    
    def __init__(self, total_files: int):
        self.total_files = total_files
        self.migrated = 0
        self.failed = 0
        self.skipped = 0
        self.start_time = time.time()
        
        # Create custom progress bar
        self.progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TextColumn("•"),
            TimeElapsedColumn(),
            TextColumn("•"),
            TimeRemainingColumn(),
            console=console,
            expand=True
        )
        
        self.task_id = None
    
    def start(self):
        """Start progress tracking"""
        self.task_id = self.progress.add_task(
            "[cyan]Migrating documentation...",
            total=self.total_files
        )
    
    def create_summary_table(self) -> Table:
        """Create summary statistics table"""
        table = Table(title="📊 Migration Statistics", show_header=True, header_style="bold magenta")
        
        table.add_column("Metric", style="cyan", no_wrap=True)
        table.add_column("Value", justify="right", style="green")
        table.add_column("Progress", justify="right")
        
        # Progress percentage
        progress_pct = (self.migrated / self.total_files * 100) if self.total_files > 0 else 0
        
        # Elapsed time
        elapsed = time.time() - self.start_time
        elapsed_str = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
        
        # Estimated time remaining
        if self.migrated > 0:
            rate = elapsed / self.migrated
            remaining = (self.total_files - self.migrated) * rate
            eta_str = f"{int(remaining // 60)}m {int(remaining % 60)}s"
        else:
            eta_str = "Calculating..."
        
        # Success rate
        if self.migrated + self.failed > 0:
            success_rate = (self.migrated / (self.migrated + self.failed)) * 100
        else:
            success_rate = 0
        
        table.add_row("Total Files", str(self.total_files), "")
        table.add_row("✅ Migrated", str(self.migrated), f"{progress_pct:.1f}%")
        table.add_row("❌ Failed", str(self.failed), f"{(self.failed/self.total_files*100) if self.total_files > 0 else 0:.1f}%")
        table.add_row("⏭️  Skipped", str(self.skipped), "")
        table.add_row("⏱️  Elapsed Time", elapsed_str, "")
        table.add_row("⏳ ETA", eta_str, "")
        table.add_row("📈 Success Rate", f"{success_rate:.1f}%", "")
        
        return table
    
    def update(self, status: str, file_name: str = ""):
        """Update dashboard based on status"""
        if status == "migrated":
            self.migrated += 1
            self.progress.update(self.task_id, advance=1, description=f"[green]✅ {file_name}")
        elif status == "failed":
            self.failed += 1
            self.progress.update(self.task_id, advance=1, description=f"[red]❌ {file_name}")
        elif status == "skipped":
            self.skipped += 1
            self.progress.update(self.task_id, advance=1, description=f"[yellow]⏭️  {file_name}")
    
    def display_with_live(self):
        """Return Live context manager for real-time display"""
        layout = Layout()
        layout.split_column(
            Layout(self.progress, name="progress"),
            Layout(self.create_summary_table(), name="stats")
        )
        return Live(layout, refresh_per_second=4, console=console)


# Usage in ContentMigrator
class ContentMigrator:
    """Enhanced migrator with Rich dashboard integration"""
    
    def migrate_all_content(self):
        """Complete content migration with real-time dashboard"""
        
        # Count total files
        total_files = sum(1 for _ in self.source_dir.rglob('*.md'))
        
        dashboard = MigrationDashboard(total_files)
        dashboard.start()
        
        with dashboard.display_with_live() as live:
            for root, dirs, files in os.walk(self.source_dir):
                for file in files:
                    if file.endswith('.md'):
                        file_path = Path(root) / file
                        
                        try:
                            # Classify and migrate
                            metadata = self.classifier.classify_file(file_path)
                            target_path = self.get_target_path(metadata, file)
                            self.migrate_file(file_path, target_path, metadata)
                            self.update_frontmatter(target_path, metadata)
                            
                            dashboard.update("migrated", file_path.name)
                            
                        except Exception as e:
                            dashboard.update("failed", file_path.name)
                            console.print(f"[red]❌ Failed: {file_path}[/red]")
                            console.print(f"[red]   Error: {e}[/red]")
                        
                        # Update live dashboard
                        live.update(dashboard.create_summary_table())
        
        # Final summary
        console.print("\n[bold green]✅ Migration Complete![/bold green]")
        console.print(dashboard.create_summary_table())
        
        return {
            'total': total_files,
            'migrated': dashboard.migrated,
            'failed': dashboard.failed,
            'skipped': dashboard.skipped
        }
```

**DEPENDENCIES UPDATE**:
```txt
# requirements-docs.txt - Add Rich for dashboards
rich>=13.9.4                     # Terminal UI and progress bars (latest stable)
```

---

## 📚 **IMPLEMENTATION SEQUENCE**

### **Phase 3.1: Setup & Validation (Day 1)**

```bash
#!/bin/bash
# phase-3-1-setup.sh - Initial setup and validation

set -e  # Exit on error

echo "🚀 Phase 3.1: Setup & Validation"
echo "=================================="

# 1. Backup current documentation
echo "\n📦 Creating backup..."
tar -czf docs-backup-$(date +%Y%m%d-%H%M%S).tar.gz docs/
echo "✅ Backup created"

# 2. Update dependencies
echo "\n📚 Installing research-validated dependencies..."
uv pip install -r requirements-docs.txt
echo "✅ Dependencies installed"

# 3. Verify installations
echo "\n🔍 Verifying installations..."
python3 << 'EOF'
import frontmatter
import rich
from rich.console import Console
import mkdocs

console = Console()

console.print("✅ python-frontmatter:", frontmatter.__version__)
console.print("✅ Rich:", rich.__version__)
console.print("✅ MkDocs:", mkdocs.__version__)

# Verify no torch
import pkgutil
torch_found = any('torch' in p.name.lower() for p in pkgutil.iter_modules())
assert not torch_found, "❌ PyTorch detected!"
console.print("✅ No PyTorch dependency")
EOF

# 4. Update mkdocs.yml with validation config
echo "\n📝 Updating mkdocs.yml validation..."
# (Manually apply the validation configuration)

# 5. Test build
echo "\n🏗️  Testing MkDocs build..."
podman run --rm -v $(pwd):/workspace:Z \
  xoe-novai-docs:latest \
  python -m mkdocs build --strict 2>&1 | tee build-test.log

# 6. Count warnings
WARNINGS=$(grep -c "WARNING" build-test.log || echo "0")
echo "\n📊 Current state: $WARNINGS warnings"

echo "\n✅ Phase 3.1 complete! Ready for migration."
```

---

### **Phase 3.2: Content Classification (Days 2-3)**

```python
# run_classification.py - Classify all existing content
from scripts.classify_content import ContentClassifier
from pathlib import Path

def main():
    docs_dir = Path("docs")
    classifier = ContentClassifier()
    
    results = {
        'tutorials': 0,
        'how-to': 0,
        'reference': 0,
        'explanation': 0,
        'general': 0
    }
    
    domains = {}
    
    print("🔍 Classifying documentation...")
    
    for md_file in docs_dir.rglob("*.md"):
        if 'node_modules' in str(md_file) or '.git' in str(md_file):
            continue
        
        try:
            metadata = classifier.classify_file(md_file)
            
            # Update statistics
            results[metadata.quadrant] += 1
            domains[metadata.domain] = domains.get(metadata.domain, 0) + 1
            
            # Update frontmatter
            classifier.update_frontmatter(md_file, metadata)
            
            print(f"✅ {md_file.name}: {metadata.domain}/{metadata.quadrant}")
            
        except Exception as e:
            print(f"❌ Failed: {md_file}: {e}")
    
    # Print summary
    print("\n📊 Classification Summary:")
    print("\nQuadrants:")
    for quadrant, count in results.items():
        print(f"  {quadrant}: {count}")
    
    print("\nDomains:")
    for domain, count in sorted(domains.items(), key=lambda x: x[1], reverse=True):
        print(f"  {domain}: {count}")

if __name__ == "__main__":
    main()
```

**RUN CLASSIFICATION**:
```bash
python run_classification.py
```

---

### **Phase 3.3: Directory Restructuring (Days 4-5)**

```python
# run_migration.py - Migrate files to Diátaxis structure
from scripts.migrate_content import ContentMigrator
from scripts.migration_dashboard import MigrationDashboard
from pathlib import Path

def main():
    source_dir = Path("docs")
    target_dir = Path("docs-new")
    
    # Create target structure
    quadrants = ['tutorials', 'how-to', 'reference', 'explanation']
    domains = ['voice-ai', 'rag-architecture', 'security', 'performance', 'library-curation']
    
    for quadrant in quadrants:
        for domain in domains:
            (target_dir / quadrant / domain).mkdir(parents=True, exist_ok=True)
    
    # Run migration
    migrator = ContentMigrator(source_dir, target_dir)
    results = migrator.migrate_all_content()
    
    print(f"\n✅ Migration complete:")
    print(f"  Total: {results['total']}")
    print(f"  Migrated: {results['migrated']}")
    print(f"  Failed: {results['failed']}")

if __name__ == "__main__":
    main()
```

---

### **Phase 3.4: Link Repair (Day 6)**

```bash
#!/bin/bash
# run_link_repair.sh - Automated link repair

echo "🔧 Running link repair..."

# 1. Build with strict mode to get warnings
podman run --rm -v $(pwd):/workspace:Z \
  xoe-novai-docs:latest \
  python -m mkdocs build --strict 2>&1 | tee build-warnings.log

# 2. Run link repair script
python3 << 'EOF'
from scripts.repair_links import LinkRepairSystem
from pathlib import Path

docs_dir = Path("docs-new")
repair_system = LinkRepairSystem(docs_dir)

# Read build warnings
with open("build-warnings.log") as f:
    build_output = f.read()

# Repair links
results = repair_system.repair_links_from_build_output(build_output)

print(f"\n✅ Link repair complete:")
print(f"  Repaired: {results['repaired']}")
print(f"  Failed: {results['failed']}")
print(f"  Total warnings: {results['warnings']}")
EOF

echo "✅ Link repair complete!"
```

---

### **Phase 3.5: Validation & Testing (Day 7)**

```bash
#!/bin/bash
# run_validation.sh - Complete validation suite

echo "🧪 Running validation suite..."

# 1. Build test (strict mode)
echo "\n1️⃣ Testing build (strict mode)..."
podman run --rm -v $(pwd)/docs-new:/workspace:Z \
  xoe-novai-docs:latest \
  python -m mkdocs build --strict 2>&1 | tee final-build.log

# 2. Count warnings
WARNINGS=$(grep -c "WARNING" final-build.log || echo "0")
echo "   Warnings: $WARNINGS"

# 3. Performance test
echo "\n2️⃣ Testing build performance..."
time podman run --rm -v $(pwd)/docs-new:/workspace:Z \
  xoe-novai-docs:latest \
  python -m mkdocs build

# 4. Link validation
echo "\n3️⃣ Validating links..."
BROKEN_LINKS=$(grep "not found" final-build.log | wc -l)
echo "   Broken links: $BROKEN_LINKS"

# 5. Navigation validation
echo "\n4️⃣ Validating navigation..."
python3 << 'EOF'
from pathlib import Path

quadrants = ['tutorials', 'how-to', 'reference', 'explanation']
domains = ['voice-ai', 'rag-architecture', 'security', 'performance', 'library-curation']

coverage = {}
for quadrant in quadrants:
    for domain in domains:
        path = Path('docs-new') / quadrant / domain
        has_content = path.exists() and len(list(path.glob('*.md'))) > 0
        coverage[f'{quadrant}/{domain}'] = has_content

# Print coverage
total = len(coverage)
populated = sum(coverage.values())
print(f"\nNavigation coverage: {populated}/{total} ({populated/total*100:.1f}%)")

for area, has_content in coverage.items():
    status = "✅" if has_content else "❌"
    print(f"  {status} {area}")
EOF

echo "\n✅ Validation complete!"
```

---

## 🎯 **SUCCESS CRITERIA**

### **Phase 3 Completion Checklist**

- [ ] **All 569 files classified** with domain + quadrant frontmatter
- [ ] **Directory structure created**: 20 areas (5 domains × 4 quadrants)
- [ ] **Files migrated** to new structure with preserved content
- [ ] **Links repaired**: <50 broken links remaining
- [ ] **Build time**: <15 seconds for clean build
- [ ] **Warnings**: <100 total MkDocs warnings
- [ ] **Navigation coverage**: >80% of 20 areas populated

### **Quality Metrics**

| Metric | Target | Validation |
|--------|--------|------------|
| Frontmatter compliance | 100% | All .md files have domain/quadrant |
| Link repair success | >80% | <50 broken links remaining |
| Build performance | <15s | Time clean build |
| Directory reduction | >75% | From 105 → ~25 directories |
| Navigation coverage | >80% | 16/20 areas with content |

---

## 🚨 **TROUBLESHOOTING**

### **Common Issues & Solutions**

#### **Issue 1: Frontmatter Parsing Errors**

```bash
# Symptom: "Failed to parse frontmatter"
# Cause: Invalid YAML syntax in existing frontmatter

# Solution: Validate YAML
python3 << 'EOF'
import frontmatter
from pathlib import Path

for md_file in Path("docs").rglob("*.md"):
    try:
        post = frontmatter.load(md_file)
    except Exception as e:
        print(f"❌ Invalid frontmatter: {md_file}")
        print(f"   Error: {e}")
EOF
```

#### **Issue 2: Link Repair Not Working**

```bash
# Symptom: Links still broken after repair

# Cause: Link map incomplete or incorrect pattern matching

# Solution: Debug link map
python3 << 'EOF'
from scripts.repair_links import LinkRepairSystem
from pathlib import Path

repair = LinkRepairSystem(Path("docs"))
print(f"Link map size: {len(repair.link_map)}")
print("\nSample mappings:")
for key, values in list(repair.link_map.items())[:10]:
    print(f"  {key} → {values}")
EOF
```

#### **Issue 3: Migration Dashboard Not Displaying**

```bash
# Symptom: Dashboard not rendering or flickering

# Cause: Rich not installed or terminal incompatibility

# Solution: Verify Rich installation and terminal support
python3 -c "from rich.console import Console; Console().print('[bold green]Rich working![/bold green]')"
```

---

## 📖 **RESEARCH REFERENCES**

### **Key Sources Validated**

1. **MkDocs 1.6 Documentation**: Granular validation controls
2. **Material for MkDocs 10.0 Release**: Final feature release announcement
3. **python-frontmatter (eyeseast)**: Standard Jekyll-style frontmatter library
4. **Rich (Textualize)**: Production-grade terminal UI library
5. **Diátaxis Framework**: Systematic documentation structure approach

### **Version Compatibility Matrix**

| Component | Version | Compatibility | Notes |
|-----------|---------|---------------|-------|
| MkDocs | 1.6.1 | ✅ Verified | Granular validation |
| Material | 10.0.2 | ✅ Locked | Final feature release |
| python-frontmatter | >=1.1.0 | ✅ Latest | YAML/JSON/TOML support |
| Rich | >=13.9.4 | ✅ Latest | Thread-safe progress |
| PyYAML | >=6.0 | ✅ Required | Frontmatter dependency |

---

## ✅ **FINAL DEPLOYMENT**

### **Production Deployment Checklist**

```bash
#!/bin/bash
# deploy-production.sh - Final deployment

echo "🚀 Production Deployment"
echo "======================="

# 1. Final validation
echo "\n1️⃣ Running final validation..."
bash run_validation.sh

# 2. Backup old docs
echo "\n2️⃣ Backing up old documentation..."
mv docs docs-old-$(date +%Y%m%d)

# 3. Deploy new structure
echo "\n3️⃣ Deploying new structure..."
mv docs-new docs

# 4. Update mkdocs.yml navigation
echo "\n4️⃣ Updating navigation..."
# (Manually update nav section with new structure)

# 5. Final build test
echo "\n5️⃣ Final build test..."
podman run --rm -v $(pwd):/workspace:Z \
  xoe-novai-docs:latest \
  python -m mkdocs build --strict

# 6. Commit changes
echo "\n6️⃣ Committing to git..."
git add docs/ mkdocs.yml requirements-docs.txt
git commit -m "Phase 3 complete: Diátaxis migration with MkDocs 1.6 validation"

echo "\n✅ Production deployment complete!"
```

---

**END OF IMPLEMENTATION GUIDE**

**Next Steps**:
1. Review this complete guide
2. Execute Phase 3.1 setup script
3. Run classification and migration
4. Validate results against success criteria
5. Deploy to production

**Support**: If issues arise, refer to Troubleshooting section or consult Grok MkDocs Expert for advanced debugging.
