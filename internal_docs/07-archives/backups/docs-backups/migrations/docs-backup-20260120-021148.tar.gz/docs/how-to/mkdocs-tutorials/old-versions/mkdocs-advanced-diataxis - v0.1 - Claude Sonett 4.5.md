# Ultimate MkDocs + Diátaxis Implementation Guide

**Version**: 2.0 Enterprise Edition  
**Target**: Xoe-NovAi Complex AI Stack Documentation  
**Scope**: 1000+ pages, 50GB+ library content, multi-domain expertise

---

## Executive Summary

This guide provides production-ready implementation of MkDocs Material theme with extended Diátaxis framework for complex, multi-domain AI documentation ecosystems.

**Key Achievements**:
- ✅ Extended Diátaxis for domain-specific quadrants
- ✅ Performance optimization for 1000+ pages (<5min builds)
- ✅ Advanced plugin ecosystem with AI integration
- ✅ Progressive disclosure patterns for expertise levels
- ✅ Cross-domain intelligent navigation

---

## 1. MkDocs Material Advanced Configuration

### 1.1 Production-Ready `mkdocs.yml`

```yaml
# =============================================================================
# Xoe-NovAi Enterprise Documentation Configuration
# =============================================================================
site_name: Xoe-NovAi Enterprise Documentation
site_description: Privacy-first local AI assistant – production reference & research archive
site_url: https://docs.xoe-novai.ai
repo_url: https://github.com/your-org/xoe-novai
repo_name: xoe-novai/enterprise
use_directory_urls: true
docs_dir: 'docs'
site_dir: 'site'

# =============================================================================
# THEME: Material for MkDocs - Enterprise Edition
# =============================================================================
theme:
  name: material
  custom_dir: overrides  # Custom templates/extensions
  
  # Automatic light/dark mode + manual toggle
  palette:
    # Auto-detect system preference
    - media: "(prefers-color-scheme)"
      toggle:
        icon: material/brightness-auto
        name: Switch to light mode
    
    # Light mode
    - media: "(prefers-color-scheme: light)"
      scheme: default
      primary: indigo
      accent: amber
      toggle:
        icon: material/brightness-7
        name: Switch to dark mode
    
    # Dark mode
    - media: "(prefers-color-scheme: dark)"
      scheme: slate
      primary: indigo
      accent: amber
      toggle:
        icon: material/brightness-4
        name: Switch to system preference
  
  # Typography
  font:
    text: Inter  # Modern, readable
    code: Fira Code  # Ligatures for code
  
  # Branding
  logo: assets/logo.svg
  favicon: assets/favicon.png
  
  # Icons
  icon:
    repo: fontawesome/brands/github
    edit: material/pencil
    view: material/eye
    tag:
      default: material/tag
      tutorial: material/school
      how-to: material/wrench
      reference: material/book-open-variant
      explanation: material/lightbulb
  
  # Features - CRITICAL for enterprise docs
  features:
    # Navigation
    - navigation.tabs           # Top-level tabs
    - navigation.tabs.sticky    # Sticky tabs on scroll
    - navigation.sections       # Expandable sections
    - navigation.expand         # Auto-expand navigation
    - navigation.indexes        # Section index pages
    - navigation.top            # Back-to-top button
    - navigation.tracking       # Anchor tracking in URL
    - navigation.path           # Breadcrumbs
    - navigation.instant        # Instant loading (SPA-like)
    - navigation.instant.progress  # Progress indicator
    
    # Table of Contents
    - toc.follow                # Auto-scroll ToC
    - toc.integrate             # Integrate ToC in sidebar
    
    # Search
    - search.suggest            # Search suggestions
    - search.highlight          # Highlight search terms
    - search.share              # Share search results
    
    # Header
    - header.autohide           # Auto-hide header on scroll
    
    # Content
    - content.code.copy         # Copy code button
    - content.code.annotate     # Code annotations
    - content.tabs.link         # Link content tabs
    - content.tooltips          # Enhanced tooltips
    - content.action.edit       # Edit page link
    - content.action.view       # View source link
    
    # Performance
    - optimize                  # Optimize builds

# =============================================================================
# PLUGINS: Advanced Features
# =============================================================================
plugins:
  # PHASE 1: Build optimization (80% faster builds)
  - optimize:
      enabled: !ENV [OPTIMIZE, true]
      cache: true
      cache_dir: .cache/optimize
      concurrent: !ENV [BUILD_CONCURRENT, true]
  
  # PHASE 2: Enhanced search (prebuild index)
  - search:
      lang: en
      separator: '[\s\-\.]+'
      prebuild_index: true        # Pre-build search index
      indexing: full              # Full-text indexing
      min_search_length: 2
  
  # PHASE 3: Build caching (33-67x faster incremental builds)
  - build_cache:
      enabled: true
      cache_dir: .cache/mkdocs
      include:
        - requirements-docs.txt
        - scripts/generate_api_docs.py
        - mkdocs.yml
  
  # PHASE 4: Privacy enforcement (no telemetry)
  - privacy:
      enabled: true
      assets: true                # Download external assets
      assets_fetch: true
      assets_fetch_dir: assets/external
  
  # PHASE 5: Tags (for Diátaxis quadrants)
  - tags:
      tags_file: tags.md
      tags_extra_files:
        tutorial: tutorials/index.md
        how-to: how-to/index.md
        reference: reference/index.md
        explanation: explanation/index.md
  
  # PHASE 6: API documentation generation
  - gen-files:
      scripts:
        - scripts/generate_api_docs.py
        - scripts/generate_metrics.py
  
  # PHASE 7: Literate navigation
  - literate-nav:
      nav_file: SUMMARY.md
      implicit_index: true
  
  # PHASE 8: Section indices
  - section-index
  
  # PHASE 9: GLightbox (image zoom)
  - glightbox:
      touchNavigation: true
      loop: false
      effect: zoom
      slide_effect: slide
      width: 100%
      height: auto
      zoomable: true
      draggable: true
  
  # PHASE 10: Social cards (auto-generate preview images)
  - social:
      cards: true
      cards_layout_options:
        background_color: "#1976d2"
        color: "#ffffff"
  
  # PHASE 11: Git revision date (freshness tracking)
  - git-revision-date-localized:
      enable_creation_date: true
      type: timeago
      fallback_to_build_date: true
  
  # PHASE 12: Minification (production builds)
  - minify:
      minify_html: true
      minify_js: true
      minify_css: true
      htmlmin_opts:
        remove_comments: true
      cache_safe: true

# =============================================================================
# MARKDOWN EXTENSIONS: Enhanced Functionality
# =============================================================================
markdown_extensions:
  # Python Markdown
  - abbr                        # Abbreviations
  - admonition                  # Call-outs/admonitions
  - attr_list                   # Add HTML/CSS to Markdown
  - def_list                    # Definition lists
  - footnotes                   # Footnotes
  - md_in_html                  # Markdown in HTML
  - meta                        # Frontmatter metadata
  - tables                      # Tables
  - toc:
      permalink: true           # Permanent links to headers
      permalink_title: Link to this section
      toc_depth: 3
  
  # PyMdown Extensions
  - pymdownx.arithmatex:        # LaTeX math
      generic: true
  
  - pymdownx.betterem:          # Better emphasis
      smart_enable: all
  
  - pymdownx.caret              # Superscript
  - pymdownx.mark               # Highlighting
  - pymdownx.tilde              # Subscript
  
  - pymdownx.critic:            # Track changes
      mode: view
  
  - pymdownx.details            # Collapsible details
  
  - pymdownx.emoji:             # Emoji support
      emoji_index: !!python/name:material.extensions.emoji.twemoji
      emoji_generator: !!python/name:material.extensions.emoji.to_svg
      options:
        custom_icons:
          - overrides/.icons
  
  - pymdownx.highlight:         # Code highlighting
      anchor_linenums: true
      line_spans: __span
      pygments_lang_class: true
      auto_title: true
      linenums: true
      linenums_style: pymdownx-inline
  
  - pymdownx.inlinehilite       # Inline code highlighting
  
  - pymdownx.keys               # Keyboard keys
  
  - pymdownx.magiclink:         # Auto-link URLs
      repo_url_shorthand: true
      user: your-org
      repo: xoe-novai
  
  - pymdownx.smartsymbols       # Smart symbols
  
  - pymdownx.snippets:          # Include external files
      check_paths: true
      base_path: docs
  
  - pymdownx.superfences:       # Nested fences
      custom_fences:
        - name: mermaid
          class: mermaid
          format: !!python/name:pymdownx.superfences.fence_code_format
  
  - pymdownx.tabbed:            # Content tabs
      alternate_style: true
      slugify: !!python/object/apply:pymdownx.slugs.slugify
        kwds:
          case: lower
  
  - pymdownx.tasklist:          # Task lists
      custom_checkbox: true
      clickable_checkbox: false

# =============================================================================
# EXTRA: Additional Configuration
# =============================================================================
extra:
  generator: false              # Remove "Made with MkDocs" badge
  
  # Social links
  social:
    - icon: fontawesome/brands/github
      link: https://github.com/your-org/xoe-novai
      name: GitHub Repository
    - icon: fontawesome/brands/discord
      link: https://discord.gg/your-server
      name: Discord Community
  
  # Version selector (for multi-version docs)
  version:
    provider: mike
    default: latest
  
  # Analytics (optional - privacy-friendly)
  analytics:
    provider: custom  # Use privacy-friendly analytics
    property: !ENV [ANALYTICS_ID, ""]
  
  # Consent (GDPR compliance)
  consent:
    title: Cookie consent
    description: >-
      We use cookies to recognize your repeated visits and preferences, as well
      as to measure the effectiveness of our documentation and whether users
      find what they're searching for. With your consent, you're helping us to
      make our documentation better.
    actions:
      - accept
      - manage

# =============================================================================
# EXTRA CSS/JS: Custom Styling
# =============================================================================
extra_css:
  - assets/stylesheets/extra.css
  - assets/stylesheets/diataxis.css  # Diátaxis visual indicators

extra_javascript:
  - assets/javascripts/extra.js
  - assets/javascripts/mathjax.js    # Math rendering
  - https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js

# =============================================================================
# NAVIGATION: Extended Diátaxis Structure
# =============================================================================
nav:
  - Home: index.md
  
  # QUADRANT 1: Tutorials (Learning-Oriented)
  - Tutorials:
      - tutorials/index.md
      - Quick Start: tutorials/quick-start.md
      - Voice Interface: tutorials/voice-interface.md
      - Docker Setup: tutorials/docker-setup.md
      - First RAG Query: tutorials/first-rag-query.md
      - Voice AI Domain:
          - Building Voice Commands: tutorials/voice-ai/building-voice-commands.md
          - STT Optimization: tutorials/voice-ai/stt-optimization.md
      - RAG Domain:
          - Creating RAG Pipeline: tutorials/rag/creating-rag-pipeline.md
          - Tuning Neural BM25: tutorials/rag/tuning-neural-bm25.md
      - Security Domain:
          - Implementing Circuit Breakers: tutorials/security/circuit-breakers.md
          - Zero-Trust Setup: tutorials/security/zero-trust-setup.md
  
  # QUADRANT 2: How-To Guides (Task-Oriented)
  - How-To Guides:
      - how-to/index.md
      - Performance Tuning: how-to/performance-tuning.md
      - Troubleshooting: how-to/troubleshooting.md
      - Deployment: how-to/deployment.md
      - Voice AI Domain:
          - Optimize STT Latency: how-to/voice-ai/optimize-stt-latency.md
          - Configure Piper ONNX: how-to/voice-ai/configure-piper-onnx.md
      - RAG Domain:
          - Tune Retrieval: how-to/rag/tune-retrieval.md
          - Optimize FAISS Index: how-to/rag/optimize-faiss-index.md
      - Security Domain:
          - SOC2 Compliance: how-to/security/soc2-compliance.md
          - Security Hardening: how-to/security/hardening.md
  
  # QUADRANT 3: Reference (Information-Oriented)
  - Reference:
      - reference/index.md
      - API Documentation: reference/api/
      - Configuration: reference/configuration.md
      - CLI Commands: reference/cli.md
      - Voice AI Domain:
          - STT API: reference/voice-ai/stt-api.md
          - TTS API: reference/voice-ai/tts-api.md
      - RAG Domain:
          - FAISS API: reference/rag/faiss-api.md
          - Neural BM25 API: reference/rag/neural-bm25-api.md
      - Security Domain:
          - Security API: reference/security/security-api.md
          - Compliance Metrics: reference/security/compliance-metrics.md
  
  # QUADRANT 4: Explanation (Understanding-Oriented)
  - Explanation:
      - explanation/index.md
      - System Overview: explanation/system-overview.md
      - Architecture: explanation/architecture.md
      - Design Decisions: explanation/design-decisions.md
      - Security Model: explanation/security-model.md
      - Voice AI Domain:
          - Voice Pipeline Architecture: explanation/voice-ai/voice-pipeline-architecture.md
          - Vulkan Acceleration: explanation/voice-ai/vulkan-acceleration.md
      - RAG Domain:
          - Hybrid Retrieval Theory: explanation/rag/hybrid-retrieval-theory.md
          - Neural BM25 Design: explanation/rag/neural-bm25-design.md
      - Security Domain:
          - Zero-Trust Principles: explanation/security/zero-trust-principles.md
          - Circuit Breaker Pattern: explanation/security/circuit-breaker-pattern.md
  
  # SPECIAL: Research Hub
  - Research Hub:
      - research/index.md
      - Vulkan Inference: research/vulkan-inference.md
      - Kokoro TTS: research/kokoro-tts.md
      - FAISS Architecture: research/faiss-architecture.md
      - Enterprise Modernization: research/enterprise-modernization.md
  
  # SPECIAL: System Prompts
  - System Prompts:
      - system-prompts/index.md
      - Assistants:
          - Claude: system-prompts/assistants/claude/
          - Grok: system-prompts/assistants/grok/
          - Gemini: system-prompts/assistants/gemini/
      - Experts:
          - Voice AI Expert: system-prompts/experts/voice-ai-expert.md
          - RAG Expert: system-prompts/experts/rag-expert.md
          - Security Expert: system-prompts/experts/security-expert.md

# =============================================================================
# VALIDATION & QUALITY
# =============================================================================
validation:
  nav:
    omitted_files: warn
    not_found: warn
    absolute_links: warn
  links:
    not_found: warn
    absolute_links: warn
    unrecognized_links: warn

# Disable strict mode during development
strict: false  # Enable in CI/CD for production
```

---

## 2. Extended Diátaxis Framework Implementation

### 2.1 Domain-Specific Quadrant Extensions

**Standard Diátaxis** → **Extended Multi-Domain Diátaxis**

```
Standard Diátaxis (4 quadrants):
├── Tutorials (learning-oriented)
├── How-To Guides (task-oriented)
├── Reference (information-oriented)
└── Explanation (understanding-oriented)

Extended Diátaxis for Xoe-NovAi (4 quadrants × 5 domains = 20 sections):
├── Voice AI Domain
│   ├── Tutorials: Building voice commands, STT optimization
│   ├── How-To: Optimize latency, configure Piper ONNX
│   ├── Reference: STT API, TTS API, voice config
│   └── Explanation: Voice pipeline architecture, Vulkan acceleration
├── RAG Architecture Domain
│   ├── Tutorials: Creating RAG pipeline, tuning Neural BM25
│   ├── How-To: Tune retrieval, optimize FAISS index
│   ├── Reference: FAISS API, Neural BM25 API
│   └── Explanation: Hybrid retrieval theory, Neural BM25 design
├── Security Domain
│   ├── Tutorials: Implementing circuit breakers, zero-trust setup
│   ├── How-To: SOC2 compliance, security hardening
│   ├── Reference: Security API, compliance metrics
│   └── Explanation: Zero-trust principles, circuit breaker pattern
├── Performance Domain
│   ├── Tutorials: Benchmarking basics, profiling setup
│   ├── How-To: Optimize memory, tune GPU acceleration
│   ├── Reference: Performance metrics, benchmarking API
│   └── Explanation: Optimization strategies, hardware utilization
└── Library Curation Domain
    ├── Tutorials: First curation workflow, metadata enrichment
    ├── How-To: Filter content, assess quality
    ├── Reference: Curation API, curator config
    └── Explanation: Curation architecture, quality frameworks
```

### 2.2 Visual Diátaxis Indicators

**File**: `docs/assets/stylesheets/diataxis.css`

```css
/* =============================================================================
 * Diátaxis Visual Indicators
 * ============================================================================= */

/* Quadrant Color Coding */
:root {
  --diataxis-tutorial: #4caf50;      /* Green - Learning */
  --diataxis-how-to: #ff9800;        /* Orange - Practical */
  --diataxis-reference: #2196f3;     /* Blue - Information */
  --diataxis-explanation: #9c27b0;   /* Purple - Understanding */
}

/* Page Header Indicators */
.md-content__inner h1::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 12px;
  vertical-align: middle;
}

/* Tutorial pages */
article[data-md-quadrant="tutorial"] .md-content__inner h1::before {
  background-color: var(--diataxis-tutorial);
}

/* How-To pages */
article[data-md-quadrant="how-to"] .md-content__inner h1::before {
  background-color: var(--diataxis-how-to);
}

/* Reference pages */
article[data-md-quadrant="reference"] .md-content__inner h1::before {
  background-color: var(--diataxis-reference);
}

/* Explanation pages */
article[data-md-quadrant="explanation"] .md-content__inner h1::before {
  background-color: var(--diataxis-explanation);
}

/* Quadrant Badge in Navigation */
.md-nav__item--quadrant::before {
  content: attr(data-quadrant);
  display: inline-block;
  padding: 2px 6px;
  margin-right: 6px;
  font-size: 0.7em;
  font-weight: 600;
  border-radius: 3px;
  text-transform: uppercase;
}

.md-nav__item--quadrant[data-quadrant="tutorial"]::before {
  background-color: var(--diataxis-tutorial);
  color: white;
}

.md-nav__item--quadrant[data-quadrant="how-to"]::before {
  background-color: var(--diataxis-how-to);
  color: white;
}

.md-nav__item--quadrant[data-quadrant="reference"]::before {
  background-color: var(--diataxis-reference);
  color: white;
}

.md-nav__item--quadrant[data-quadrant="explanation"]::before {
  background-color: var(--diataxis-explanation);
  color: white;
}
```

### 2.3 Frontmatter Schema for Diátaxis

**Every page should include**:

```yaml
---
title: "Optimizing STT Latency"
description: "Step-by-step guide to reduce speech-to-text latency below 320ms"
quadrant: how-to              # tutorial | how-to | reference | explanation
domain: voice-ai              # voice-ai | rag | security | performance | library
expertise_level: intermediate # beginner | intermediate | advanced | expert
tags:
  - voice
  - performance
  - optimization
  - latency
last_updated: "2026-01-16"
status: stable                # draft | review | stable | deprecated
---
```

---

## 3. Performance Optimization for 1000+ Pages

### 3.1 Build Performance Targets

```python
# Performance Benchmarks
build_targets = {
    "initial_build": "<5 minutes (1000+ pages)",
    "incremental_build": "<30 seconds (changed pages only)",
    "search_index_generation": "<2 minutes",
    "plugin_processing": "<1 minute (all plugins)",
}
```

### 3.2 Build Optimization Techniques

**1. Parallel Processing**

```bash
# Enable concurrent builds
export BUILD_CONCURRENT=true
export MKDOCS_WORKERS=8  # Match CPU cores
```

**2. Aggressive Caching**

```yaml
# mkdocs.yml
plugins:
  - build_cache:
      enabled: true
      cache_dir: .cache/mkdocs
      include:
        - requirements-docs.txt
        - scripts/*.py
        - mkdocs.yml
        - docs/**/*.md
```

**3. Lazy Loading Images**

```html
<!-- Use lazy loading for images -->
![Alt text](image.jpg){ loading=lazy }
```

**4. Optimize Search Index**

```yaml
plugins:
  - search:
      prebuild_index: true  # Pre-build during mkdocs build
      indexing: full
      lang: en
```

### 3.3 CI/CD Build Optimization

```yaml
# .github/workflows/docs.yml
name: Build Documentation

on:
  push:
    branches: [main]
    paths:
      - 'docs/**'
      - 'mkdocs.yml'

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0  # Full history for git-revision-date
      
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: 'pip'  # Cache pip dependencies
      
      - name: Cache MkDocs build
        uses: actions/cache@v4
        with:
          path: .cache
          key: mkdocs-${{ hashFiles('mkdocs.yml', 'docs/**/*.md') }}
          restore-keys: mkdocs-
      
      - name: Install dependencies
        run: |
          pip install -r requirements-docs.txt
      
      - name: Build documentation
        run: |
          mkdocs build --strict
      
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v4
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./site
```

---

## 4. Advanced Plugin Integration

### 4.1 Custom RAG Search Plugin (Conceptual)

**File**: `docs/plugins/rag_search_plugin.py`

```python
"""
MkDocs RAG Search Plugin
Integrates semantic search with FAISS vectorstore
"""

from mkdocs.plugins import BasePlugin
from mkdocs.config import config_options
import faiss
import numpy as np

class RAGSearchPlugin(BasePlugin):
    config_scheme = (
        ('faiss_index_path', config_options.Type(str, default='faiss_index')),
        ('embedding_model', config_options.Type(str, default='all-MiniLM-L12-v2')),
        ('top_k', config_options.Type(int, default=5)),
    )
    
    def on_page_content(self, html, page, config, files):
        """Extract and index page content"""
        # Extract text from HTML
        text = self.extract_text(html)
        
        # Generate embedding
        embedding = self.embed(text)
        
        # Add to FAISS index
        self.add_to_index(embedding, page.url)
        
        return html
    
    def on_post_build(self, config):
        """Save FAISS index after build"""
        self.save_index()
```

### 4.2 Freshness Monitoring Plugin

**Automatically detects stale documentation**

```python
"""
MkDocs Freshness Monitoring Plugin
Tracks page freshness and generates reports
"""

from mkdocs.plugins import BasePlugin
from datetime import datetime, timedelta
import json

class FreshnessPlugin(BasePlugin):
    config_scheme = (
        ('threshold_days', config_options.Type(int, default=90)),
        ('report_path', config_options.Type(str, default='docs_freshness_report.json')),
    )
    
    def on_page_markdown(self, markdown, page, config, files):
        """Track page last updated date"""
        meta = page.meta
        last_updated = meta.get('last_updated')
        
        if last_updated:
            age_days = (datetime.now() - datetime.fromisoformat(last_updated)).days
            
            if age_days > self.config['threshold_days']:
                # Mark as stale
                page.meta['freshness_status'] = 'stale'
                page.meta['age_days'] = age_days
        
        return markdown
    
    def on_post_build(self, config):
        """Generate freshness report"""
        self.generate_report()
```

---

## 5. Progressive Disclosure Implementation

### 5.1 Expertise Level Filtering

**User can filter content by expertise level**

```javascript
// docs/assets/javascripts/expertise-filter.js

document$.subscribe(function() {
  // Get user's selected expertise level from localStorage
  const expertiseLevel = localStorage.getItem('expertise_level') || 'intermediate';
  
  // Filter navigation items
  document.querySelectorAll('[data-expertise]').forEach(item => {
    const itemLevel = item.dataset.expertise;
    const levels = ['beginner', 'intermediate', 'advanced', 'expert'];
    const userLevelIndex = levels.indexOf(expertiseLevel);
    const itemLevelIndex = levels.indexOf(itemLevel);
    
    // Hide content above user's level
    if (itemLevelIndex > userLevelIndex) {
      item.style.display = 'none';
    }
  });
});
```

### 5.2 Contextual Navigation

**Smart sidebar that adapts to user journey**

```python
# scripts/generate_contextual_nav.py

def generate_contextual_navigation(current_page, user_history):
    """
    Generate navigation based on user's current page and history
    
    Returns:
        - Related pages in same quadrant
        - Next logical steps in user journey
        - Prerequisites if missing
    """
    
    recommendations = {
        "same_quadrant": [],
        "next_steps": [],
        "prerequisites": [],
    }
    
    # Same quadrant recommendations
    quadrant = current_page.meta.get('quadrant')
    recommendations["same_quadrant"] = get_pages_by_quadrant(quadrant, limit=5)
    
    # Next logical steps
    if quadrant == "tutorial":
        # After tutorial, suggest how-to guides
        recommendations["next_steps"] = get_pages_by_quadrant("how-to", limit=3)
    elif quadrant == "how-to":
        # After how-to, suggest reference
        recommendations["next_steps"] = get_pages_by_quadrant("reference", limit=3)
    
    # Check prerequisites
    required = current_page.meta.get('requires', [])
    for req in required:
        if req not in user_history:
            recommendations["prerequisites"].append(get_page(req))
    
    return recommendations
```

---

## 6. Cross-Domain Intelligent Navigation

### 6.1 Knowledge Graph Integration

**Link related concepts across domains**

```yaml
# docs/knowledge_graph.yml

entities:
  - id: neural_bm25
    name: Neural BM25
    type: concept
    domains: [rag]
    related_to:
      - faiss_index
      - hybrid_retrieval
      - query_expansion
  
  - id: circuit_breaker
    name: Circuit Breaker
    type: pattern
    domains: [security, performance]
    related_to:
      - resilience
      - error_recovery
      - service_health
  
  - id: vulkan_acceleration
    name: Vulkan GPU Acceleration
    type: technique
    domains: [voice-ai, performance]
    related_to:
      - gpu_optimization
      - cooperative_matrices
      - memory_management

relationships:
  - from: neural_bm25
    to: faiss_index
    type: uses
    description: "Neural BM25 uses FAISS for vector storage and retrieval"
  
  - from: circuit_breaker
    to: resilience
    type: implements
    description: "Circuit breaker implements resilience patterns"
```

### 6.2 Automated Cross-References

**Generate "See Also" sections automatically**

```python
# scripts/generate_cross_references.py

def generate_cross_references(page):
    """
    Automatically generate cross-references based on:
    - Shared entities in knowledge graph
    - User behavior patterns (pages read together)
    - Semantic similarity
    """
    
    cross_refs = []
    
    # Knowledge graph relationships
    page_entities = extract_entities(page.content)
    for entity in page_entities:
        related = knowledge_graph.get_related(entity, depth=2)
        cross_refs.extend(get_pages_with_entities(related))
    
    # Behavioral patterns
    common_paths = analytics.get_pages_read_together(page.url)
    cross_refs.extend(common_paths)
    
    # Semantic similarity
    similar = vectorstore.similarity_search(page.embedding, k