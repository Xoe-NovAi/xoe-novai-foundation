# 🎨 Xoe-NovAi Grafana Implementation & Advanced Dashboard Guide v1.0
## Complete Integration for Voice AI RAG Monitoring with Enterprise Best Practices

**Document Version**: 1.0 | **Status**: Production Ready | **Last Updated**: 2026-01-19

---

## 📋 TABLE OF CONTENTS

1. [Grafana Integration Architecture](#grafana-integration-architecture)
2. [Dashboard Design Strategy](#dashboard-design-strategy)
3. [Advanced Templating & Variables](#advanced-templating--variables)
4. [Data Correlation & Linking](#data-correlation--linking)
5. [Voice AI Pipeline Monitoring](#voice-ai-pipeline-monitoring)
6. [RED Method Implementation](#red-method-implementation)
7. [SLO/Error Budget Dashboards](#slo-error-budget-dashboards)
8. [Production Configurations](#production-configurations)

---

## 🏗️ GRAFANA INTEGRATION ARCHITECTURE

### Data Source Configuration

Grafana dashboards connect different panels to different data sources, allowing you to monitor several metrics at once. For instance, one panel can show CPU usage while another tracks memory consumption or network latency.

**File**: `grafana/provisioning/datasources/all-datasources.yml`

```yaml
apiVersion: 1

datasources:
  # Prometheus (Metrics)
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
    jsonData:
      timeInterval: 15s
      tlsSkipVerify: false

  # Loki (Logs)
  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    editable: true
    jsonData:
      maxLines: 1000

  # Tempo (Traces)
  - name: Tempo
    type: tempo
    access: proxy
    url: http://tempo:3200
    editable: true
    jsonData:
      tracesToLogsV2:
        datasourceUid: 'loki-uid'
        tags: ['service', 'job']
        mappedTags:
          - tag: service.name
            field: service
          - tag: service.namespace
            field: namespace
      tracesToMetricsV2:
        datasourceUid: 'prometheus-uid'
      serviceMap:
        datasourceUid: 'prometheus-uid'

  # Pyroscope (Profiles)
  - name: Pyroscope
    type: pyroscope
    access: proxy
    url: http://pyroscope:4040
    editable: true

  # OpenTelemetry Collector (Direct metrics ingestion)
  - name: OTel-Collector
    type: prometheus
    access: proxy
    url: http://otel-collector:9090
    editable: true
    jsonData:
      timeInterval: 5s

deleteDatasources:
  - name: Graphite
    orgId: 1
```

### Dashboard Provisioning

```yaml
# grafana/provisioning/dashboards/provider.yml
apiVersion: 1

providers:
  - name: 'Xoe-NovAi Dashboards'
    orgId: 1
    folder: 'Xoe-NovAi'
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: false
    options:
      path: /etc/grafana/provisioning/dashboards/xoe-novai
```

---

## 🎯 DASHBOARD DESIGN STRATEGY

### Dashboard Hierarchy (Why Structure Matters)

Prevent sprawl by using template variables. For example, you don't need a separate dashboard for each node, you can use query variables. Even better, you can make the data source a template variable too, so you can reuse the same dashboard across different clusters and monitoring backends.

**Xoe-NovAi Dashboard Hierarchy**:

```
Level 1: Executive Dashboard (Business KPIs)
├── Overall System Health
├── Error Budget Burn Rate
├── User Satisfaction (voice quality)
└── Cost/Resource Efficiency

Level 2: Service Dashboards (RED Method per service)
├── RAG API Dashboard
├── Voice Pipeline Dashboard
├── FAISS Search Dashboard
├── Crawler Dashboard
└── Redis Cache Dashboard

Level 3: Deep Dive Dashboards (Component-level)
├── STT Performance
├── TTS Performance
├── LLM Inference
├── Embedding Search
└── Session Management

Level 4: Operational Dashboards
├── Infrastructure (CPU/Memory/Network)
├── Alerting Status
├── SLO Achievement
└── Error Analysis
```

### Dashboard Design Principles

A dashboard should tell a story or answer a question. Try to create a logical progression of data, such as large to small or general to specific. If the dashboard doesn't have a goal, then ask yourself if you really need the dashboard.

**For Xoe-NovAi**:

1. **Executive Dashboard**: "Is my voice AI service healthy?"
2. **Service Dashboards**: "Which component is slow/failing?"
3. **Deep Dive Dashboards**: "What's the root cause?"
4. **Operational Dashboards**: "Do I need to scale?"

---

## 🔧 ADVANCED TEMPLATING & VARIABLES

### Variable Types & Hierarchy

Variables allow you to create more interactive dashboards. Instead of hard-coding things like server names, application names, or sensor names into your queries, you can use a variable in their place. Grafana then replaces the variable with its current value when it queries your data source.

#### Cascading Variables for Xoe-NovAi

```yaml
# grafana/dashboards/voice-pipeline-dashboard.json
{
  "dashboard": {
    "title": "Voice AI Pipeline - Dynamic",
    "templating": {
      "list": [
        {
          "name": "environment",
          "type": "query",
          "datasource": "Prometheus",
          "definition": "label_values(up{job=~'xoe-.*'}, environment)",
          "current": { "value": "production", "text": "production" },
          "multi": false,
          "includeAll": false,
          "sort": 1,
          "refresh": "on_time_range_changed"
        },
        {
          "name": "service",
          "type": "query",
          "datasource": "Prometheus",
          "definition": "label_values(up{environment='$environment'}, job)",
          "current": { "value": "xoe-rag-api", "text": "xoe-rag-api" },
          "multi": false,
          "includeAll": false,
          "sort": 1,
          "refresh": "on_time_range_changed",
          "description": "Service depends on $environment selection"
        },
        {
          "name": "instance",
          "type": "query",
          "datasource": "Prometheus",
          "definition": "label_values(up{job='$service'}, instance)",
          "current": { "value": "rag:8000", "text": "rag:8000" },
          "multi": true,
          "includeAll": true,
          "allValue": ".*",
          "sort": 1,
          "refresh": "on_time_range_changed"
        },
        {
          "name": "voice_component",
          "type": "custom",
          "current": { "value": "stt", "text": "stt" },
          "options": [
            { "value": "stt", "text": "STT (Speech-To-Text)" },
            { "value": "tts", "text": "TTS (Text-To-Speech)" },
            { "value": "embeddings", "text": "Embeddings" },
            { "value": "llm", "text": "LLM Inference" }
          ],
          "multi": false,
          "includeAll": false
        }
      ]
    },
    "panels": [
      {
        "title": "Voice Component Latency - $voice_component",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(voice_${voice_component}_latency_ms_bucket{instance=~'$instance'}[5m]))"
          }
        ]
      }
    ]
  }
}
```

### Advanced Variable Syntax

```promql
# Using variables in expressions
## Basic reference
rate(http_requests_total{job="$service"}[5m])

## Multi-value with regex
label_values(http_requests_total{job=~"$service"}, instance)

## Interpolation with format control
${instance:glob}     # Glob format for multi-value
${service:regex}     # Regex format
${environment:csv}   # Comma-separated values
${component:json}    # JSON format
```

### Performance Optimization

Enabling caching for variables in Grafana settings helps reduce repeated queries. Cached variables store their results temporarily, which cuts down on the need to re-fetch data every time a dashboard loads, improving speed and responsiveness.

```yaml
# Dashboard settings for performance
"refresh": "on_time_range_changed",  # Not on every seconds
"cache": {
  "enabled": true,
  "ttl_seconds": 300  # 5 minute cache
}

# Limit multi-value selections
"multi": true,
"maxSelectedValues": 10  # Prevent overwhelming queries
```

---

## 🔗 DATA CORRELATION & LINKING

### Correlations Setup (Metrics → Logs → Traces)

Grafana can correlate different signals by adding the functionality to link between traces and metrics. Trace to metrics lets you navigate from a trace span to a selected data source.

**File**: `grafana/provisioning/correlations/xoe-novai-correlations.yml`

```yaml
apiVersion: v1

correlations:
  # Prometheus Metrics → Loki Logs
  - name: "Metrics to Logs"
    sourceUID: "prometheus-uid"
    targetUID: "loki-uid"
    description: "Jump from high error rate to error logs"
    field: "job"
    transformations:
      - type: regex
        field: "job"
        expression: "(.*)-.*"
        mapValue: "service"
    query:
      target:
        expr: '{service="$service", level="error"}'

  # Tempo Traces → Loki Logs
  - name: "Traces to Logs"
    sourceUID: "tempo-uid"
    targetUID: "loki-uid"
    description: "From trace to component logs"
    field: "serviceName"
    transformations:
      - type: logfmt
        field: "traceData"
    query:
      target:
        expr: '{job="${serviceName}", trace_id="${traceID}"}'

  # Tempo Traces → Pyroscope Profiles
  - name: "Traces to Profiles"
    sourceUID: "tempo-uid"
    targetUID: "pyroscope-uid"
    description: "Analyze CPU/memory during slow trace"
    field: "traceID"
    query:
      target:
        expr: 'profile?__meta_service_name=xoe-novai&query=traces'

  # Logs → External (Runbooks)
  - name: "Error to Runbook"
    sourceUID: "loki-uid"
    targetUID: "external"
    field: "error_code"
    transformations:
      - type: regex
        field: "msg"
        expression: "error_code=([0-9]+)"
        mapValue: "errorCode"
    query:
      target:
        type: external
        url: "https://wiki.xoe-novai.internal/runbooks/error-${errorCode}"
```

### Panel-Level Data Links

```json
{
  "panel": {
    "title": "RAG API Error Rate",
    "targets": [
      {
        "expr": "rate(http_requests_total{status=~'5..'}[5m])"
      }
    ],
    "fieldConfig": {
      "defaults": {
        "custom": {
          "links": [
            {
              "title": "View error logs",
              "url": "/explore?datasource=Loki&query={job='xoe-rag-api',level='error'}",
              "targetBlank": true
            },
            {
              "title": "View trace",
              "url": "/explore?datasource=Tempo&query=service='xoe-rag-api'",
              "targetBlank": true
            }
          ]
        }
      }
    }
  }
}
```

---

## 🎤 VOICE AI PIPELINE MONITORING

### Component Breakdown Dashboard

Voice AI monitoring is fundamentally different than traditional web applications because you need to track each stage of the voice pipeline independently.

```json
{
  "dashboard": {
    "title": "Voice AI Pipeline - Component Analysis",
    "tags": ["voice", "ai", "latency", "quality"],
    "panels": [
      {
        "type": "row",
        "title": "STT (Speech-to-Text) Component",
        "gridPos": { "h": 1, "w": 24, "x": 0, "y": 0 }
      },
      {
        "type": "graph",
        "title": "STT Latency Distribution",
        "gridPos": { "h": 8, "w": 12, "x": 0, "y": 1 },
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(voice_stt_latency_ms_bucket[5m]))",
            "legendFormat": "P95 latency"
          },
          {
            "expr": "histogram_quantile(0.99, rate(voice_stt_latency_ms_bucket[5m]))",
            "legendFormat": "P99 latency"
          }
        ],
        "alert": {
          "name": "STT P95 > 300ms",
          "conditions": [
            {
              "evaluator": { "params": [300], "type": "gt" },
              "operator": { "type": "and" },
              "query": { "params": ["A", "5m", "now"] },
              "reducer": { "params": [], "type": "avg" },
              "type": "query"
            }
          ]
        }
      },
      {
        "type": "gauge",
        "title": "STT Accuracy (WER %)",
        "gridPos": { "h": 8, "w": 12, "x": 12, "y": 1 },
        "targets": [
          {
            "expr": "avg(voice_stt_wer_percent)"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "max": 10,
            "min": 0,
            "thresholds": {
              "mode": "percentage",
              "steps": [
                { "color": "green", "value": null },
                { "color": "yellow", "value": 5 },
                { "color": "red", "value": 8 }
              ]
            },
            "unit": "percent"
          }
        }
      },
      {
        "type": "row",
        "title": "LLM Inference",
        "gridPos": { "h": 1, "w": 24, "x": 0, "y": 9 }
      },
      {
        "type": "graph",
        "title": "Token Generation Rate",
        "gridPos": { "h": 8, "w": 12, "x": 0, "y": 10 },
        "targets": [
          {
            "expr": "rate(llm_tokens_generated_total[1m])",
            "legendFormat": "Tokens/sec"
          }
        ]
      },
      {
        "type": "graph",
        "title": "Time to First Token (TTFT)",
        "gridPos": { "h": 8, "w": 12, "x": 12, "y": 10 },
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(llm_ttft_ms_bucket[5m]))",
            "legendFormat": "P95 TTFT"
          }
        ]
      },
      {
        "type": "row",
        "title": "TTS (Text-to-Speech)",
        "gridPos": { "h": 1, "w": 24, "x": 0, "y": 18 }
      },
      {
        "type": "graph",
        "title": "TTS Latency",
        "gridPos": { "h": 8, "w": 24, "x": 0, "y": 19 },
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(voice_tts_latency_ms_bucket[5m]))",
            "legendFormat": "P95 TTS latency"
          }
        ]
      }
    ]
  }
}
```

---

## 📊 RED METHOD IMPLEMENTATION

### The RED Method for Xoe-NovAi

The RED method tells you how happy your users are. Dashboard design reflects service hierarchies, with one row per service, where the row order reflects the data flow.

**RED = Rate, Errors, Duration**

```json
{
  "dashboard": {
    "title": "RAG API - RED Method Dashboard",
    "rows": [
      {
        "title": "Rate (Requests per second)",
        "panels": [
          {
            "type": "graph",
            "title": "Request Rate",
            "targets": [
              {
                "expr": "rate(http_requests_total{job='xoe-rag-api'}[1m])",
                "legendFormat": "{{method}} {{path}}"
              }
            ]
          }
        ]
      },
      {
        "title": "Errors (5xx + 4xx errors)",
        "panels": [
          {
            "type": "graph",
            "title": "Error Rate %",
            "targets": [
              {
                "expr": "rate(http_requests_total{job='xoe-rag-api', status=~'[45]..'}[5m]) / rate(http_requests_total{job='xoe-rag-api'}[5m]) * 100",
                "legendFormat": "Error %"
              }
            ]
          },
          {
            "type": "table",
            "title": "Error Breakdown",
            "targets": [
              {
                "expr": "sum by (status) (rate(http_requests_total{job='xoe-rag-api', status=~'[45]..'}[5m]))"
              }
            ]
          }
        ]
      },
      {
        "title": "Duration (Latency percentiles)",
        "panels": [
          {
            "type": "graph",
            "title": "Latency Percentiles",
            "targets": [
              {
                "expr": "histogram_quantile(0.50, rate(request_duration_seconds_bucket[5m]))",
                "legendFormat": "P50"
              },
              {
                "expr": "histogram_quantile(0.95, rate(request_duration_seconds_bucket[5m]))",
                "legendFormat": "P95"
              },
              {
                "expr": "histogram_quantile(0.99, rate(request_duration_seconds_bucket[5m]))",
                "legendFormat": "P99"
              }
            ]
          }
        ]
      }
    ]
  }
}
```

---

## 🎯 SLO/ERROR BUDGET DASHBOARDS

### Error Budget Tracking

```json
{
  "dashboard": {
    "title": "Error Budget & SLO Tracking",
    "panels": [
      {
        "type": "gauge",
        "title": "Error Budget Remaining (28-day)",
        "targets": [
          {
            "expr": "(0.999 - (sum(rate(http_requests_total{status=~'2..'}[28d])) / sum(rate(http_requests_total[28d])))) * 40320",
            "legendFormat": "Minutes remaining"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "max": 40.32,
            "min": 0,
            "thresholds": {
              "mode": "absolute",
              "steps": [
                { "color": "red", "value": null },
                { "color": "yellow", "value": 10 },
                { "color": "green", "value": 20 }
              ]
            }
          }
        }
      },
      {
        "type": "graph",
        "title": "Burn Rate (3-day rolling)",
        "targets": [
          {
            "expr": "(1 - (sum(rate(http_requests_total{status=~'2..'}[3d])) / sum(rate(http_requests_total[3d])))) / ((1 - 0.999) / 28)"
          }
        ],
        "alert": {
          "name": "High Burn Rate",
          "condition": "> 10x (consume 28-day budget in 2.8 days)"
        }
      },
      {
        "type": "table",
        "title": "SLO Achievement by Service",
        "targets": [
          {
            "expr": "sum by (job) (rate(http_requests_total{status=~'2..'}[28d])) / sum by (job) (rate(http_requests_total[28d])) * 100"
          }
        ]
      }
    ]
  }
}
```

---

## ⚙️ PRODUCTION CONFIGURATIONS

### Grafana Environment Setup

```yaml
# .env.grafana
GF_SECURITY_ADMIN_USER=admin
GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD}
GF_USERS_ALLOW_SIGN_UP=false
GF_USERS_ALLOW_ORG_CREATE=false
GF_SERVER_ROOT_URL=http://localhost:3000
GF_SERVER_SERVE_FROM_SUB_PATH=false
GF_LOG_LEVEL=info

# Performance tuning
GF_INSTALL_PLUGINS=grafana-piechart-panel,grafana-worldmap-panel,grafana-clock-panel
GF_INSTALL_PLUGINS_SKIP_UNSIGNED=false

# Database
GF_DATABASE_TYPE=sqlite3
GF_DATABASE_PATH=/var/lib/grafana/grafana.db

# Session
GF_SESSION_PROVIDER=memory
GF_SESSION_PROVIDER_CONFIG=xnai_session

# Alerting
GF_ALERTING_ENABLED=true
GF_ALERTING_EXECUTE_ALERTS=true
GF_SMTP_ENABLED=true
GF_SMTP_HOST=smtp.gmail.com
GF_SMTP_PORT=587
GF_SMTP_USER=${SMTP_USER}
GF_SMTP_PASSWORD=${SMTP_PASSWORD}
GF_SMTP_FROM_ADDRESS=alerts@xoe-novai.local
```

### Docker Compose Configuration

```yaml
services:
  grafana:
    image: grafana/grafana:latest
    container_name: xnai_grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
      - GF_USERS_ALLOW_SIGN_UP=false
      - GF_INSTALL_PLUGINS=grafana-piechart-panel,grafana-worldmap-panel
    volumes:
      - ./grafana/provisioning:/etc/grafana/provisioning:ro
      - ./grafana/dashboards:/etc/grafana/dashboards:ro
      - grafana-data:/var/lib/grafana
      - grafana-logs:/var/log/grafana
    depends_on:
      - prometheus
      - loki
      - tempo
      - pyroscope
    networks:
      - xnai_network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  grafana-data:
  grafana-logs:
```

### Dashboard as Code (JSON-based versioning)

```bash
# Store dashboards in Git
grafana/dashboards/
├── executive-dashboard.json
├── voice-pipeline-dashboard.json
├── rag-api-dashboard.json
├── slo-dashboard.json
└── operational-dashboard.json

# CI/CD integration (deploy on every commit)
# scripts/deploy-dashboards.sh
#!/bin/bash
for dashboard in grafana/dashboards/*.json; do
    curl -X POST http://grafana:3000/api/dashboards/db \
      -H "Authorization: Bearer $GRAFANA_API_TOKEN" \
      -H "Content-Type: application/json" \
      -d @"$dashboard"
done
```

---

## 🚀 BEST PRACTICES CHECKLIST

```
DASHBOARD DESIGN
☐ Each dashboard has a clear purpose
☐ Data flows logically (top to bottom)
☐ Color usage is consistent and meaningful
☐ Panels are sized appropriately
☐ No unnecessary stacking of graphs
☐ Documentation/descriptions on each panel

TEMPLATING & REUSABILITY
☐ Variables prevent dashboard sprawl
☐ Cascading variables for drill-down
☐ Multi-value variables with sensible limits
☐ Variables cached to reduce query load

CORRELATION & LINKING
☐ Metrics → Logs correlation set up
☐ Traces → Logs correlation set up
☐ Traces → Profiles correlation set up
☐ External links to runbooks
☐ Panel-level data links configured

ALERTING STRATEGY
☐ Alerts based on SLO error budgets
☐ Multi-window burn rate alerts
☐ Alert routing to appropriate team
☐ Alert runbooks linked in Grafana

PERFORMANCE OPTIMIZATION
☐ Query optimization (aggregation at source)
☐ Appropriate time ranges set
☐ Unnecessary refreshes disabled
☐ Panel-level caching enabled
☐ Regex filters on variables
☐ No wild card queries in large datasets

VERSION CONTROL
☐ Dashboards stored in Git
☐ JSON-based provisioning
☐ CI/CD for dashboard deployment
☐ Change tracking for dashboards
```

---

## 📈 NEXT STEPS FOR ADVANCED MONITORING

1. **Enable Grafana Assistant** (AI-powered observability, 2025+)
2. **Implement SLOs** as code (Terraform)
3. **Custom plugins** for Xoe-NovAi specific visualizations
4. **Continuous profiling** integration with Pyroscope
5. **Automated incident response** via alerts

---

**Implementation Status**: ✅ Production Ready  
**Grafana Version**: 10.0+  
**Data Sources**: Prometheus + Loki + Tempo + Pyroscope  
**Scalability**: Horizontal (all backend components)  
**Cost**: Free (open-source stack)