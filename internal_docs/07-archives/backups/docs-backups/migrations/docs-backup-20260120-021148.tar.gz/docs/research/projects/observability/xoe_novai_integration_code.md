# 📝 Xoe-NovAi Integration Code & Configuration - Ready to Deploy v1.0

**Status**: Copy-paste ready | **Test Time**: 10 minutes | **Production Ready**: Yes

---

## 1️⃣ UPDATE: main.py (FastAPI Instrumentation)

**File**: `app/XNAi_rag_app/main.py`

**Changes**: Add after line 31 (after imports, before app creation)

```python
# ADD THIS BLOCK (after existing imports)
# ============================================================================
# OPENTELEMETRY FASTAPI INSTRUMENTATION (v0.1.5 - Claude v2 Integration)
# ============================================================================

from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.trace import Span
from typing import Any, Dict

def _instrument_fastapi_hooks():
    """Create instrumentation hooks for FastAPI request tracking."""
    
    def server_request_hook(span: Span, scope: Dict[str, Any]):
        """Add custom attributes from request."""
        if span and span.is_recording():
            path = scope.get("path", "")
            method = scope.get("method", "")
            
            # Component tracking
            if "voice" in path:
                span.set_attribute("component.type", "voice")
            elif "rag" in path or "query" in path:
                span.set_attribute("component.type", "rag")
            elif "stream" in path:
                span.set_attribute("component.type", "streaming")
            elif "health" in path:
                span.set_attribute("component.type", "health")
            
            # Business logic tracking
            if "query" in path and method == "POST":
                span.set_attribute("rag_enabled", "true")
            
            # Request size
            content_length = scope.get("headers", {}).get(b"content-length", [None])[0]
            if content_length:
                try:
                    span.set_attribute("http.request_content_length", int(content_length))
                except (ValueError, TypeError):
                    pass
    
    def client_response_hook(span: Span, scope: Dict[str, Any], message: Dict[str, Any]):
        """Add response metadata."""
        if span and span.is_recording():
            status = message.get("status", 0)
            span.set_attribute("http.status_code", status)
            
            # Error tracking
            if status >= 500:
                span.set_attribute("error", "true")
                span.set_attribute("error.kind", f"SERVER_ERROR_{status}")
            elif status >= 400:
                span.set_attribute("error", "false")
                span.set_attribute("error.kind", f"CLIENT_ERROR_{status}")
    
    return server_request_hook, client_response_hook

# Store hooks globally
_server_hook, _client_hook = _instrument_fastapi_hooks()

# END INSTRUMENTATION SETUP
```

**Then, in the app definition (around line 110-115, after creating FastAPI instance):**

```python
# AFTER: app = FastAPI(title="Xoe-NovAi RAG API", ...)
# ADD THIS:

# Instrument FastAPI immediately after app creation
FastAPIInstrumentor.instrument_app(
    app,
    server_request_hook=_server_hook,
    client_response_hook=_client_hook,
    excluded_urls="^/metrics,^/health"  # Don't trace health checks to reduce noise
)

logger.info("✅ OpenTelemetry FastAPI instrumentation enabled")
```

**In the lifespan startup (around line 175):**

```python
# In the lifespan startup function, ADD:

    # Initialize observability (Week 2 Integration - Claude v2)
    try:
        from observability import setup_ai_observability
        setup_ai_observability()
        logger.info("✅ Claude v2 AI-Native Observability initialized")
    except Exception as e:
        logger.warning(f"⚠️  Observability initialization failed: {e}")
        # Continue without observability - not critical
```

---

## 2️⃣ UPDATE: logging_config.py (Add Trace IDs)

**File**: `app/XNAi_rag_app/logging_config.py`

**Find**: The `XNAiJSONFormatter.json_record()` method (around line 150)

**Replace with**:

```python
def json_record(
    self,
    message: str,
    extra: Dict[str, Any],
    record: logging.LogRecord
) -> Dict[str, Any]:
    """Create JSON log record WITH TRACE CORRELATION."""
    
    # Get current trace context
    try:
        from opentelemetry import trace
        span = trace.get_current_span()
        span_context = span.get_span_context()
        trace_id = format(span_context.trace_id, "032x")
        span_id = format(span_context.span_id, "016x")
        trace_flags = str(span_context.trace_flags.sampled)
    except Exception:
        trace_id = ""
        span_id = ""
        trace_flags = "false"
    
    # Apply PII filtering to message
    filtered_message = self._redact_pii(message)

    log_entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "level": record.levelname,
        "module": record.module,
        "function": record.funcName,
        "line": record.lineno,
        "message": filtered_message,
        
        # CRITICAL: Trace correlation fields
        "trace_id": trace_id,
        "span_id": span_id,
        "trace_flags": trace_flags,
        
        # Stack information
        "stack_version": CONFIG.get('metadata', {}).get('stack_version', 'v0.1.4-stable'),
    }

    # Add process info
    log_entry["process_id"] = record.process
    log_entry["thread_id"] = record.thread

    # Add extra fields from context with PII filtering
    if extra:
        filtered_extra = {}
        for k, v in extra.items():
            if not k.startswith('_') and k not in ['message', 'asctime']:
                filtered_extra[k] = self._redact_pii(v) if isinstance(v, str) else v
        log_entry.update(filtered_extra)

    # Add exception info if present
    if record.exc_info:
        exception_message = str(record.exc_info[1])
        filtered_exception = self._redact_pii(exception_message)
        log_entry["exception"] = {
            "type": record.exc_info[0].__name__,
            "message": filtered_exception,
            "stacktrace": traceback.format_exc()[:500],  # Truncate for size
        }

    return log_entry
```

---

## 3️⃣ NEW FILE: Prometheus Configuration

**Create**: `prometheus/prometheus.yml`

```yaml
# ============================================================================
# Xoe-NovAi Prometheus Configuration v0.1.5
# ============================================================================
# Scrapes metrics from all stack services
# Last Updated: 2026-01-19

global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    cluster: 'xoe-novai'
    environment: 'production'
    stack_version: 'v0.1.5'
    
# Alert managers
alerting:
  alertmanagers:
    - static_configs:
        - targets:
            - alertmanager:9093

# Rule files
rule_files:
  - '/etc/prometheus/rules/*.yml'

scrape_configs:
  # RAG API - Native Prometheus metrics
  - job_name: 'xoe-rag-api'
    scrape_interval: 15s
    scrape_timeout: 10s
    metrics_path: '/metrics'
    static_configs:
      - targets: ['rag:8000']
    relabel_configs:
      - source_labels: [__address__]
        target_label: instance
      - source_labels: [__scheme__]
        target_label: scheme
    metric_relabel_configs:
      # Add service label
      - source_labels: [job]
        target_label: service
        replacement: 'xoe-rag-api'

  # Chainlit UI
  - job_name: 'xoe-ui'
    scrape_interval: 30s
    metrics_path: '/metrics'
    static_configs:
      - targets: ['ui:8001']
    relabel_configs:
      - source_labels: [job]
        target_label: service
        replacement: 'xoe-chainlit'

  # Redis (basic connectivity check)
  - job_name: 'redis'
    scrape_interval: 30s
    static_configs:
      - targets: ['redis:6379']

  # Node Exporter (system metrics)
  - job_name: 'node'
    scrape_interval: 30s
    static_configs:
      - targets: ['node-exporter:9100']

  # cAdvisor (container metrics)
  - job_name: 'cadvisor'
    scrape_interval: 30s
    static_configs:
      - targets: ['cadvisor:8080']
```

**Create**: `prometheus/rules/xoe-novai-slo.yml`

```yaml
# ============================================================================
# Xoe-NovAi SLO & Alert Rules
# ============================================================================

groups:
  - name: xoe-novai-slo
    interval: 1m
    rules:
      # SLO: 99.9% availability
      - alert: HighErrorRate
        expr: |
          (rate(xnai_requests_total{status=~"5.."}[5m]) / 
           rate(xnai_requests_total[5m])) > 0.001
        for: 5m
        labels:
          severity: critical
          service: xoe-rag-api
          slo: availability
        annotations:
          summary: "Error rate exceeds SLO: {{ $value | humanizePercentage }}"
          runbook: "Check logs in Loki for error details"

      # SLO: P95 latency < 1000ms
      - alert: HighLatencyP95
        expr: |
          histogram_quantile(0.95, 
            rate(xnai_response_latency_ms_bucket[5m])) > 1000
        for: 10m
        labels:
          severity: warning
          service: xoe-rag-api
          slo: latency
        annotations:
          summary: "P95 latency high: {{ $value }}ms (SLO: 1000ms)"

      # Voice: STT latency target < 300ms
      - alert: VoiceSTTLatencyHigh
        expr: |
          histogram_quantile(0.95, 
            rate(voice_stt_latency_ms_bucket[5m])) > 300
        for: 5m
        labels:
          severity: warning
          component: voice-stt
        annotations:
          summary: "STT P95 latency: {{ $value }}ms (target: 300ms)"

      # Circuit breaker trips
      - alert: CircuitBreakerOpen
        expr: circuit_breaker_state == 1
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Circuit breaker OPEN: {{ $labels.breaker }}"
          detail: "Service temporarily unavailable due to cascading failures"

      # Memory threshold
      - alert: HighMemoryUsage
        expr: xnai_memory_usage_gb > 4.5
        for: 5m
        labels:
          severity: warning
          component: system
        annotations:
          summary: "Memory usage: {{ $value }}GB (limit: 5GB)"

  - name: xoe-novai-availability
    interval: 1m
    rules:
      # Record availability percentage
      - record: job:availability:percentage
        expr: |
          100 * (
            sum by (job) (rate(xnai_requests_total{status=~"2.."}[5m]))
            /
            sum by (job) (rate(xnai_requests_total[5m]))
          )

      # Record error budget (28-day rolling)
      - record: job:error_budget:minutes_remaining
        expr: |
          (0.999 - (
            sum by (job) (rate(xnai_requests_total{status=~"2.."}[28d]))
            /
            sum by (job) (rate(xnai_requests_total[28d]))
          )) * 40320
```

---

## 4️⃣ NEW FILE: Grafana Loki Data Source Configuration

**Create**: `grafana/provisioning/datasources/loki-datasource.yml`

```yaml
apiVersion: 1

datasources:
  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    isDefault: false
    editable: true
    
    jsonData:
      # CRITICAL: Derived fields for trace correlation
      derivedFields:
        # Extract trace_id from JSON logs
        - name: trace_id
          matcherRegex: '"trace_id":"([^"]*)"'
          url: 'http://tempo:3200/search?traceID=${value}'
          datasourceUid: tempo-uid
          
        # Extract span_id for additional context
        - name: span_id
          matcherRegex: '"span_id":"([^"]*)"'
          url: ''
          
        # Extract service from logs
        - name: service
          matcherRegex: '"service":"([^"]*)"'
          url: ''
      
      # Link logs to traces
      tracesToLogsV2:
        datasourceUid: tempo-uid
        spanStartTimeShift: '30m'
        spanEndTimeShift: '30m'
        tags:
          - tag: 'service'
            field: 'service'
          - tag: 'environment'
            field: 'environment'
        logMessageField: 'message'
        errorStatusPattern: 'error|Error|ERROR'
```

**Create**: `grafana/provisioning/datasources/tempo-datasource.yml`

```yaml
apiVersion: 1

datasources:
  - name: Tempo
    type: tempo
    access: proxy
    url: http://tempo:3200
    isDefault: false
    editable: true
    
    jsonData:
      # Link traces to logs
      tracesToLogsV2:
        datasourceUid: loki-uid
        spanStartTimeShift: '30m'
        spanEndTimeShift: '30m'
        tags:
          - tag: 'service.name'
            field: 'service'
          - tag: 'environment'
            field: 'environment'
      
      # Link traces to profiles
      tracesToMetricsV2:
        datasourceUid: prometheus-uid
      
      # Enable service graph
      serviceMap:
        datasourceUid: prometheus-uid
```

---

## 5️⃣ UPDATE: docker-compose.monitoring.yml

**Add to existing monitoring compose file:**

```yaml
  # OpenTelemetry Collector (optional but recommended)
  otel-collector:
    image: otel/opentelemetry-collector-contrib:latest
    container_name: xnai_otel_collector
    command: ["--config=/etc/otel-collector-config.yaml"]
    volumes:
      - ./otel-collector-config.yaml:/etc/otel-collector-config.yaml:ro
    ports:
      - "4317:4317"   # OTLP gRPC
      - "4318:4318"   # OTLP HTTP
    depends_on:
      - prometheus
      - loki
      - tempo
    networks:
      - monitoring
    restart: unless-stopped
```

**Create**: `otel-collector-config.yaml`

```yaml
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318

processors:
  batch:
    send_batch_size: 1024
    timeout: 10s
  
  attributes:
    actions:
      - key: service.name
        value: xoe-novai
        action: upsert

exporters:
  prometheusremotewrite:
    endpoint: "http://prometheus:9090/api/v1/write"
  
  otlp:
    endpoint: "tempo:4317"
    tls:
      insecure: true
  
  loki:
    endpoint: "http://loki:3100/loki/api/v1/push"

service:
  pipelines:
    metrics:
      receivers: [otlp]
      processors: [batch, attributes]
      exporters: [prometheusremotewrite]
    
    traces:
      receivers: [otlp]
      processors: [batch, attributes]
      exporters: [otlp]
    
    logs:
      receivers: [otlp]
      processors: [batch, attributes]
      exporters: [loki]
```

---

## 6️⃣ ENVIRONMENT VARIABLES (.env)

**Add to your `.env`:**

```bash
# OpenTelemetry Configuration
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
OTEL_SDK_DISABLED=false
OTEL_TRACES_EXPORTER=otlp
OTEL_METRICS_EXPORTER=prometheus

# Logging with trace correlation
OTEL_LOGBACK_MDC_ENABLED=true
OTEL_LOG_LEVEL=INFO

# Prometheus
PROMETHEUS_MULTIPROC_DIR=/prometheus_data
PROMETHEUS_PORT=8002

# Grafana
GF_SECURITY_ADMIN_PASSWORD=admin
GF_USERS_ALLOW_SIGN_UP=false

# Loki
LOKI_LOG_LEVEL=info

# Tempo
TEMPO_SEARCH_MAX_RESULT_LIMIT=1000
```

---

## 🚀 DEPLOYMENT STEPS

```bash
# Step 1: Update code files
# - Update main.py (add instrumentation)
# - Update logging_config.py (add trace IDs)
# - Create prometheus/prometheus.yml
# - Create prometheus/rules/xoe-novai-slo.yml
# - Create grafana datasources

# Step 2: Deploy monitoring stack
docker-compose -f docker-compose.monitoring.yml up -d

# Step 3: Restart application services
docker-compose up -d rag ui

# Step 4: Verify in Grafana
# Visit http://localhost:3000
# - Check data sources are connected
# - View Prometheus targets at http://localhost:9090/targets
# - Import dashboards

# Step 5: Generate some traffic
# Make queries to http://localhost:8000/query
# Check metrics at http://localhost:8000/metrics

# Step 6: View in Grafana
# Metrics: Available immediately in Prometheus data source
# Logs: Check Loki for JSON-formatted logs
# Traces: View in Tempo (if OTel Collector enabled)
```

---

## ✅ VERIFICATION CHECKLIST

```bash
# Verify OpenTelemetry instrumentation
curl http://localhost:8000/metrics | grep -E "xnai_|http_request"

# Verify Prometheus scraping
curl http://localhost:9090/api/v1/targets | jq '.data.activeTargets'

# Verify Loki receiving logs
curl http://localhost:3100/loki/api/v1/query_range?query='{job="xoe-rag-api"}'

# Verify Tempo receiving traces (if enabled)
curl http://localhost:3200/api/traces?limit=10

# Test log → trace correlation
# 1. Make a query: curl -X POST http://localhost:8000/query ...
# 2. Check logs in Loki for trace_id
# 3. Click trace_id link in Grafana to jump to trace
```

---

**All changes are backward-compatible and non-breaking.** Your existing metrics collection continues while new instrumentation is activated side-by-side.

**Estimated deployment time**: 30 minutes including testing