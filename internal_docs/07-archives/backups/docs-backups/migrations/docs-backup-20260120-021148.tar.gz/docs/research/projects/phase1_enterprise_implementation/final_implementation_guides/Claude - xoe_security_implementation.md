# ============================================================================
# INTEGRATION STATUS: CLAUDE IMPLEMENTATION DELIVERABLE
# ============================================================================
# Status: NOT INTEGRATED - Requires implementation into Xoe-NovAi codebase
# Source: Claude Week 3 Session Deliverable - Enterprise Security & Compliance Hardening
# Date Received: January 18, 2026 (Week 3)
# Implementation Priority: CRITICAL (Zero-trust security architecture)
# Estimated Integration Effort: 7-10 days
# Dependencies: Redis Sentinel, mTLS certificates, eBPF probes, ABAC policies
# Integration Checklist:
# - [ ] Implement zero-trust IAM with ABAC policies
# - [ ] Deploy mTLS authentication between services
# - [ ] Configure eBPF security monitoring
# - [ ] Set up SOC2/GDPR compliance controls
# - [ ] Integrate TextSeal watermarking
# - [ ] Deploy enterprise monitoring stack
# - [ ] Validate 98% security posture achievement
# - [ ] Test compliance automation
# - [ ] Implement incident response procedures
# - [ ] Complete security audit and penetration testing
# Integration Complete: [ ] Date: ___________ By: ___________
# ============================================================================

# 🛠️ Xoe-NovAi Security Implementation Manual
**Version**: 1.0.0 | **Date**: January 18, 2026 | **Classification**: Implementation Guide

## Executive Summary

This implementation manual provides step-by-step procedures for deploying Xoe-NovAi's enterprise security architecture. Follow this guide to implement zero-trust security, cryptographic watermarking, and SOC2/GDPR compliance automation.

### Implementation Timeline

| Phase | Duration | Components |
|-------|----------|------------|
| **Phase 1: Prerequisites** | 2 days | Infrastructure setup, certificates, HSM |
| **Phase 2: Zero-Trust** | 3 days | IAM, ABAC, mTLS, eBPF monitoring |
| **Phase 3: TextSeal** | 2 days | Watermarking engine, C2PA integration |
| **Phase 4: Monitoring** | 2 days | Grafana dashboards, alerting, anomaly detection |
| **Phase 5: Compliance** | 3 days | SOC2 controls, GDPR automation |
| **Phase 6: Testing** | 2 days | Security validation, penetration testing |

**Total Duration**: 14 days

---

## Part 1: Prerequisites & Infrastructure Setup

### 1.1 System Requirements

**Hardware Requirements**
```yaml
minimum:
  cpu: 8 cores
  memory: 16 GB
  storage: 500 GB SSD
  network: 1 Gbps

recommended:
  cpu: 16 cores (AMD Ryzen 7 5700U or better)
  memory: 32 GB
  storage: 1 TB NVMe SSD
  network: 10 Gbps
```

**Software Requirements**
```bash
# Operating System
Ubuntu 22.04 LTS or RHEL 9

# Container Runtime
podman >= 4.0
buildah >= 1.28

# Security Tools
openssl >= 3.0
ebpf-tools >= 5.15
openpolicyagent >= 0.50

# Monitoring Stack
prometheus >= 2.40
grafana >= 9.0
alertmanager >= 0.25
```

### 1.2 Installation Steps

#### Step 1: Install Core Dependencies

```bash
#!/bin/bash
# install-security-deps.sh

set -euo pipefail

echo "🔧 Installing Xoe-NovAi Security Dependencies..."

# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install container runtime
sudo apt-get install -y \
    podman \
    buildah \
    podman-compose \
    slirp4netns \
    fuse-overlayfs

# Install security tools
sudo apt-get install -y \
    openssl \
    ca-certificates \
    bpfcc-tools \
    linux-headers-$(uname -r)

# Install monitoring stack
sudo apt-get install -y \
    prometheus \
    prometheus-alertmanager \
    grafana

# Install Policy Engine
wget https://openpolicyagent.org/downloads/latest/opa_linux_amd64
chmod +x opa_linux_amd64
sudo mv opa_linux_amd64 /usr/local/bin/opa

# Verify installations
podman --version
buildah --version
openssl version
opa version
prometheus --version

echo "✅ Dependencies installed successfully!"
```

#### Step 2: Configure Rootless Podman

```bash
#!/bin/bash
# configure-podman.sh

set -euo pipefail

echo "🔧 Configuring Rootless Podman..."

# Enable user namespaces
sudo sysctl -w kernel.unprivileged_userns_clone=1
echo "kernel.unprivileged_userns_clone=1" | sudo tee -a /etc/sysctl.conf

# Configure subuid/subgid
sudo usermod --add-subuids 100000-165535 --add-subgids 100000-165535 $USER

# Initialize Podman for current user
podman system migrate

# Configure Podman storage
mkdir -p ~/.config/containers
cat > ~/.config/containers/storage.conf <<EOF
[storage]
driver = "overlay"
graphroot = "\$HOME/.local/share/containers/storage"
runroot = "/run/user/\$UID/containers"

[storage.options]
mount_program = "/usr/bin/fuse-overlayfs"
EOF

# Enable Podman socket
systemctl --user enable --now podman.socket

# Set Docker compatibility
export DOCKER_HOST=unix:///run/user/$UID/podman/podman.sock

echo "✅ Rootless Podman configured!"
```

#### Step 3: Generate Certificates

```bash
#!/bin/bash
# generate-certificates.sh

set -euo pipefail

echo "🔐 Generating TLS Certificates..."

CERT_DIR="./certs"
mkdir -p $CERT_DIR/{ca,server,client}

# Generate CA private key
openssl genrsa -out $CERT_DIR/ca/ca-key.pem 4096

# Generate CA certificate
openssl req -new -x509 -days 3650 -key $CERT_DIR/ca/ca-key.pem \
    -out $CERT_DIR/ca/ca-cert.pem \
    -subj "/C=US/ST=CA/L=SF/O=XoeNovAi/CN=XoeNovAi-CA"

# Generate server private key
openssl genrsa -out $CERT_DIR/server/server-key.pem 4096

# Generate server CSR
openssl req -new -key $CERT_DIR/server/server-key.pem \
    -out $CERT_DIR/server/server-csr.pem \
    -subj "/C=US/ST=CA/L=SF/O=XoeNovAi/CN=*.xoenovai.local"

# Sign server certificate
openssl x509 -req -days 365 \
    -in $CERT_DIR/server/server-csr.pem \
    -CA $CERT_DIR/ca/ca-cert.pem \
    -CAkey $CERT_DIR/ca/ca-key.pem \
    -CAcreateserial \
    -out $CERT_DIR/server/server-cert.pem \
    -extfile <(printf "subjectAltName=DNS:*.xoenovai.local,DNS:xoenovai.local")

# Set permissions
chmod 600 $CERT_DIR/{ca,server}/*-key.pem
chmod 644 $CERT_DIR/{ca,server}/*-cert.pem

echo "✅ Certificates generated in $CERT_DIR"
```

---

## Part 2: Zero-Trust Security Implementation

### 2.1 Identity & Access Management (IAM)

#### Step 1: Deploy IAM Service

Create the IAM service structure:

```python
# app/security/iam_service.py

from fastapi import FastAPI, HTTPException, Depends, Security
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional
import jwt
import bcrypt
from dataclasses import dataclass

app = FastAPI(title="Xoe-NovAi IAM Service")

# Configuration
SECRET_KEY = os.getenv("JWT_SECRET_KEY")  # Store in secrets manager
ALGORITHM = "RS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 15
REFRESH_TOKEN_EXPIRE_DAYS = 7

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Models
class User(BaseModel):
    username: str
    email: str
    full_name: str
    disabled: bool = False
    roles: list[str] = []
    permissions: list[str] = []

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int

class TokenData(BaseModel):
    username: Optional[str] = None
    scopes: list[str] = []

# User database (replace with actual database)
fake_users_db = {
    "admin": {
        "username": "admin",
        "full_name": "System Administrator",
        "email": "admin@xoenovai.local",
        "hashed_password": bcrypt.hashpw(b"admin123", bcrypt.gensalt()),
        "disabled": False,
        "roles": ["admin"],
        "permissions": ["*"]
    }
}

def verify_password(plain_password: str, hashed_password: bytes) -> bool:
    """Verify password against hash"""
    return bcrypt.checkpw(plain_password.encode(), hashed_password)

def get_password_hash(password: str) -> bytes:
    """Hash password with bcrypt"""
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt())

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token"""
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "access"
    })
    
    # Load private key for RS256
    with open("/etc/xoenovai/certs/jwt-private-key.pem", "rb") as f:
        private_key = f.read()
    
    encoded_jwt = jwt.encode(to_encode, private_key, algorithm=ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: dict):
    """Create JWT refresh token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "refresh"
    })
    
    with open("/etc/xoenovai/certs/jwt-private-key.pem", "rb") as f:
        private_key = f.read()
    
    encoded_jwt = jwt.encode(to_encode, private_key, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    """Get current authenticated user from token"""
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # Load public key for verification
        with open("/etc/xoenovai/certs/jwt-public-key.pem", "rb") as f:
            public_key = f.read()
        
        payload = jwt.decode(token, public_key, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        
        if username is None:
            raise credentials_exception
            
        token_data = TokenData(username=username, scopes=payload.get("scopes", []))
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise credentials_exception
    
    user = fake_users_db.get(username)
    if user is None:
        raise credentials_exception
    
    return User(**user)

async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """Ensure user is active"""
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

@app.post("/token", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """Authenticate user and return tokens"""
    
    user = fake_users_db.get(form_data.username)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    
    if not verify_password(form_data.password, user["hashed_password"]):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    
    # Create access and refresh tokens
    access_token = create_access_token(
        data={"sub": user["username"], "scopes": user["permissions"]}
    )
    refresh_token = create_refresh_token(
        data={"sub": user["username"]}
    )
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )

@app.post("/token/refresh", response_model=Token)
async def refresh_token(refresh_token: str):
    """Refresh access token using refresh token"""
    
    try:
        with open("/etc/xoenovai/certs/jwt-public-key.pem", "rb") as f:
            public_key = f.read()
        
        payload = jwt.decode(refresh_token, public_key, algorithms=[ALGORITHM])
        
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=400, detail="Invalid token type")
        
        username = payload.get("sub")
        user = fake_users_db.get(username)
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Create new access token
        new_access_token = create_access_token(
            data={"sub": username, "scopes": user["permissions"]}
        )
        
        return Token(
            access_token=new_access_token,
            refresh_token=refresh_token,
            expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60
        )
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Refresh token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

@app.get("/users/me", response_model=User)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    """Get current user information"""
    return current_user

@app.post("/users/register")
async def register_user(
    username: str,
    password: str,
    email: str,
    full_name: str
):
    """Register new user"""
    
    if username in fake_users_db:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    hashed_password = get_password_hash(password)
    
    fake_users_db[username] = {
        "username": username,
        "full_name": full_name,
        "email": email,
        "hashed_password": hashed_password,
        "disabled": False,
        "roles": ["user"],
        "permissions": ["voice:use", "rag:query", "llm:inference"]
    }
    
    return {"message": "User registered successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

#### Step 2: Deploy ABAC Policy Engine

```python
# app/security/abac_engine.py

from typing import Dict, Any, List
import requests
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class PolicyDecision:
    """ABAC policy decision"""
    allow: bool
    reason: str
    policies_evaluated: List[str]

class OPAClient:
    """Open Policy Agent client for ABAC"""
    
    def __init__(self, opa_url: str = "http://opa:8181"):
        self.opa_url = opa_url
        self.policy_package = "xoenovai.authz"
    
    async def evaluate_policy(
        self,
        user: Dict[str, Any],
        resource: Dict[str, Any],
        action: str
    ) -> PolicyDecision:
        """Evaluate ABAC policy"""
        
        input_data = {
            "input": {
                "user": user,
                "resource": resource,
                "action": action,
                "time": datetime.utcnow().isoformat(),
                "environment": {
                    "ip_address": request.client.host,
                    "user_agent": request.headers.get("user-agent")
                }
            }
        }
        
        try:
            response = requests.post(
                f"{self.opa_url}/v1/data/{self.policy_package}/allow",
                json=input_data,
                timeout=5
            )
            response.raise_for_status()
            
            result = response.json()
            allow = result.get("result", False)
            
            return PolicyDecision(
                allow=allow,
                reason=f"Policy evaluation: {allow}",
                policies_evaluated=[self.policy_package]
            )
            
        except requests.RequestException as e:
            logger.error(f"OPA policy evaluation failed: {e}")
            # Fail closed - deny access on error
            return PolicyDecision(
                allow=False,
                reason=f"Policy evaluation error: {e}",
                policies_evaluated=[]
            )
    
    async def load_policy(self, policy_id: str, policy_content: str):
        """Load policy into OPA"""
        
        try:
            response = requests.put(
                f"{self.opa_url}/v1/policies/{policy_id}",
                data=policy_content,
                headers={"Content-Type": "text/plain"},
                timeout=5
            )
            response.raise_for_status()
            logger.info(f"Policy {policy_id} loaded successfully")
            
        except requests.RequestException as e:
            logger.error(f"Failed to load policy {policy_id}: {e}")
            raise

# Policy enforcement decorator
def require_permission(permission: str):
    """Decorator to enforce ABAC permissions"""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get current user from context
            current_user = kwargs.get("current_user")
            if not current_user:
                raise HTTPException(status_code=401, detail="Not authenticated")
            
            # Extract resource from request
            resource = {
                "type": func.__name__,
                "id": kwargs.get("resource_id"),
                "attributes": kwargs.get("resource_attributes", {})
            }
            
            # Evaluate policy
            opa = OPAClient()
            decision = await opa.evaluate_policy(
                user=current_user.dict(),
                resource=resource,
                action=permission
            )
            
            if not decision.allow:
                raise HTTPException(
                    status_code=403,
                    detail=f"Access denied: {decision.reason}"
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator
```

#### Step 3: Deploy OPA Policies

```rego
# policies/xoenovai-authz.rego

package xoenovai.authz

import future.keywords.if
import future.keywords.in

# Default deny
default allow = false

# Allow authenticated users to access public resources
allow if {
    is_authenticated
    input.resource.visibility == "public"
}

# Allow users to access their own resources
allow if {
    is_authenticated
    input.user.id == input.resource.owner_id
}

# Allow admins full access
allow if {
    is_authenticated
    "admin" in input.user.roles
}

# Voice service permissions
allow if {
    is_authenticated
    input.action == "voice:use"
    has_permission("voice:use")
    check_rate_limit("voice", 100, "hour")
}

# RAG service permissions
allow if {
    is_authenticated
    input.action == "rag:query"
    has_permission("rag:query")
    input.resource.type == "document"
    resource_accessible
}

# LLM service permissions
allow if {
    is_authenticated
    input.action == "llm:inference"
    has_permission("llm:inference")
    check_compute_quota
}

# Helper functions
is_authenticated if {
    input.user.id != ""
    input.user.token_valid == true
}

has_permission(perm) if {
    perm in input.user.permissions
}

has_permission("*") if {
    "*" in input.user.permissions
}

resource_accessible if {
    input.resource.visibility == "public"
}

resource_accessible if {
    input.user.id == input.resource.owner_id
}

resource_accessible if {
    some group in input.user.groups
    group in input.resource.shared_groups
}

check_rate_limit(service, limit, period) if {
    # Simplified - implement actual rate limit checking
    true
}

check_compute_quota if {
    input.user.compute_quota.remaining >= input.request.estimated_tokens
}
```

Load policies into OPA:

```bash
#!/bin/bash
# deploy-opa-policies.sh

set -euo pipefail

echo "📜 Deploying OPA Policies..."

# Start OPA server
podman run -d \
    --name opa \
    -p 8181:8181 \
    -v $(pwd)/policies:/policies:ro \
    openpolicyagent/opa:latest \
    run --server --addr=:8181 /policies

# Wait for OPA to be ready
sleep 5

# Load main authz policy
curl -X PUT \
    --data-binary @policies/xoenovai-authz.rego \
    http://localhost:8181/v1/policies/xoenovai-authz

echo "✅ OPA policies deployed!"
```

### 2.2 mTLS Service Mesh

#### Step 1: Configure Istio Service Mesh

```yaml
# k8s/istio-config.yaml

apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: default-mtls
  namespace: xoenovai
spec:
  host: "*.xoenovai.svc.cluster.local"
  trafficPolicy:
    tls:
      mode: ISTIO_MUTUAL  # Enforce mTLS
    connectionPool:
      tcp:
        maxConnections: 1000
      http:
        http2MaxRequests: 1000
        maxRequestsPerConnection: 10
    loadBalancer:
      simple: LEAST_REQUEST
    outlierDetection:
      consecutiveErrors: 5
      interval: 30s
      baseEjectionTime: 30s
      maxEjectionPercent: 50
---
apiVersion: security.istio.io/v1beta1
kind:PeerAuthentication
metadata:
  name: default-mtls
  namespace: xoenovai
spec:
  mtls:
    mode: STRICT  # Only allow mTLS connections
---
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: rag-service-authz
  namespace: xoenovai
spec:
  selector:
    matchLabels:
      app: rag-service
  action: ALLOW
  rules:
    - from:
        - source:
            principals: ["cluster.local/ns/xoenovai/sa/api-gateway"]
      to:
        - operation:
            methods: ["GET", "POST"]
            paths: ["/api/v1/query"]
```

Deploy Istio configuration:

```bash
#!/bin/bash
# deploy-istio.sh

set -euo pipefail

echo "🌐 Deploying Istio Service Mesh..."

# Install Istio
istioctl install --set profile=production -y

# Enable sidecar injection for namespace
kubectl label namespace xoenovai istio-injection=enabled

# Apply mTLS configuration
kubectl apply -f k8s/istio-config.yaml

# Verify mTLS is working
kubectl exec -it $(kubectl get pod -l app=rag-service -o jsonpath='{.items[0].metadata.name}') \
    -c istio-proxy -- curl -s http://localhost:15000/config_dump | grep -i tls

echo "✅ Istio service mesh deployed with mTLS!"
```

### 2.3 eBPF Security Monitoring

#### Step 1: Deploy eBPF Monitoring Programs

```python
# app/security/ebpf_monitor.py

from bcc import BPF
import ctypes as ct
from datetime import datetime
import logging
import asyncio

logger = logging.getLogger(__name__)

# eBPF program for system call monitoring
EBPF_PROGRAM = """
#include <uapi/linux/ptrace.h>
#include <linux/sched.h>

struct execve_event {
    u32 pid;
    u32 uid;
    u64 timestamp;
    char command[256];
};

BPF_PERF_OUTPUT(events);
BPF_HASH(suspicious_commands, u32, u64);

int trace_execve(struct pt_regs *ctx) {
    struct execve_event event = {};
    
    // Get process info
    event.pid = bpf_get_current_pid_tgid() >> 32;
    event.uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event.timestamp = bpf_ktime_get_ns();
    
    // Get command
    const char **argv = (const char **)(PT_REGS_PARM2(ctx));
    bpf_probe_read_user_str(&event.command, sizeof(event.command), argv[0]);
    
    // Check for suspicious patterns
    if (is_suspicious(&event)) {
        events.perf_submit(ctx, &event, sizeof(event));
    }
    
    return 0;
}

static inline int is_suspicious(struct execve_event *event) {
    // Detect container escape attempts
    if (bpf_strstr(event->command, "docker") ||
        bpf_strstr(event->command, "podman") ||
        bpf_strstr(event->command, "runc")) {
        return 1;
    }
    
    // Detect privilege escalation
    if (event->uid != 0 &&
        (bpf_strstr(event->command, "sudo") ||
         bpf_strstr(event->command, "su"))) {
        return 1;
    }
    
    return 0;
}

// Helper to find substring
static inline int bpf_strstr(const char *haystack, const char *needle) {
    #pragma unroll
    for (int i = 0; i < 256; i++) {
        if (haystack[i] == '\\0') return 0;
        int match = 1;
        #pragma unroll
        for (int j = 0; j < 16; j++) {
            if (needle[j] == '\\0') return 1;
            if (haystack[i+j] != needle[j]) {
                match = 0;
                break;
            }
        }
        if (match) return 1;
    }
    return 0;
}
"""

class ExecveEvent(ct.Structure):
    """Execve event structure"""
    _fields_ = [
        ("pid", ct.c_uint32),
        ("uid", ct.c_uint32),
        ("timestamp", ct.c_uint64),
        ("command", ct.c_char * 256)
    ]

class eBPFMonitor:
    """eBPF-based security monitoring"""
    
    def __init__(self, alert_callback=None):
        self.bpf = BPF(text=EBPF_PROGRAM)
        self.alert_callback = alert_callback
        
        # Attach to tracepoint
        self.bpf.attach_tracepoint(
            tp="syscalls:sys_enter_execve",
            fn_name="trace_execve"
        )
        
        logger.info("eBPF security monitor started")
    
    def process_event(self, cpu, data, size):
        """Process eBPF event"""
        event = ct.cast(data, ct.POINTER(ExecveEvent)).contents
        
        alert = {
            "timestamp": datetime.fromtimestamp(event.timestamp / 1e9),
            "pid": event.pid,
            "uid": event.uid,
            "command": event.command.decode('utf-8', 'replace'),
            "severity": "high",
            "type": "suspicious_execution"
        }
        
        logger.warning(f"Suspicious execution detected: {alert}")
        
        if self.alert_callback:
            asyncio.create_task(self.alert_callback(alert))
    
    def start_monitoring(self):
        """Start event monitoring loop"""
        self.bpf["events"].open_perf_buffer(self.process_event)
        
        logger.info("eBPF monitoring active")
        
        while True:
            try:
                self.bpf.perf_buffer_poll()
            except KeyboardInterrupt:
                logger.info("Stopping eBPF monitor")
                break
```

Deploy eBPF monitor:

```bash
#!/bin/bash
# deploy-ebpf-monitor.sh

set -euo pipefail

echo "🔍 Deploying eBPF Security Monitor..."

# Install BCC tools
sudo apt-get install -y \
    bpfcc-tools \
    linux-headers-$(uname -r) \
    python3-bpfcc

# Start eBPF monitor as systemd service
sudo cat > /etc/systemd/system/xoe-ebpf-monitor.service <<EOF
[Unit]
Description=Xoe-NovAi eBPF Security Monitor
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/python3 /opt/xoenovai/security/ebpf_monitor.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable xoe-ebpf-monitor
sudo systemctl start xoe-ebpf-monitor

# Verify monitoring
sudo systemctl status xoe-ebpf-monitor

echo "✅ eBPF security monitor deployed!"
```

---

## Part 3: TextSeal Watermarking Implementation

### 3.1 Watermarking Engine Deployment

```python
# app/security/textseal_engine.py

from typing import Dict, Any, Optional
import hashlib
import json
from datetime import datetime
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class C2PAManifest(BaseModel):
    """C2PA content provenance manifest"""
    version: str = "1.3"
    claim_generator: str = "Xoe-NovAi/1.0.0"
    title: str
    format: str
    instance_id: str
    claim: Dict[str, Any]
    watermark: Dict[str, Any]

class TextSealEngine:
    """Cryptographic watermarking engine for AI content"""
    
    def __init__(self, private_key_path: str):
        # Load signing key
        with open(private_key_path, "rb") as f:
            self.private_key = serialization.load_pem_private_key(
                f.read(),
                password=None
            )
    
    async def watermark_content(
        self,
        content: str,
        metadata: Dict[str, Any]
    ) -> tuple[str, C2PAManifest]:
        """
        Watermark AI-generated content with C2PA provenance
        
        Args:
            content: AI-generated text to watermark
            metadata: Generation metadata (model, prompt, etc.)
            
        Returns:
            Tuple of (watermarked_content, c2pa_manifest)
        """
        
        # 1. Create C2PA manifest
        manifest = self._create_c2pa_manifest(content, metadata)
        
        # 2. Sign manifest
        signature = self._sign_manifest(manifest)
        manifest.claim["signature"] = {
            "algorithm": "RSA-PSS",
            "hash_algorithm": "SHA-256",
            "key_size": 4096,
            "signature_value": signature.hex()
        }
        
        # 3. Embed watermark
        watermark_bits = self._generate_watermark_bits(manifest)
        watermarked_content = self._embed_watermark(content, watermark_bits)
        
        logger.info(f"Content watermarked with instance_id: {manifest.instance_id}")
        
        return watermarked_content, manifest
    
    def _create_c2pa_manifest(
        self,
        content: str,
        metadata: Dict[str, Any]
    ) -> C2PAManifest:
        """Create C2PA manifest"""
        
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        instance_id = f"urn:uuid:{uuid.uuid4()}"
        
        manifest = C2PAManifest(
            title="AI Generated Content",
            format="text/plain",
            instance_id=instance_id,
            claim={
                "dc:title": metadata.get("title", "AI Generated Text"),
                "dc:format": "text/plain",
                "dc:creator": "Xoe-NovAi LLM Service",
                "dcterms:created": datetime.utcnow().isoformat() + "Z",
                "assertions": [
                    {
                        "label": "c2pa.ai-generative-training",
                        "data": {
                            "model_name": metadata.get("model", "unknown"),
                            "model_version": metadata.get("model_version", "1.0.0"),
                            "training_cutoff": "2025-01-31"
                        }
                    },
                    {
                        "label": "c2pa.ai-generative-metadata",
                        "data": {
                            "prompt_hash": hashlib.sha256(
                                metadata.get("prompt", "").encode()
                            ).hexdigest(),
                            "temperature": metadata.get("temperature", 0.7),
                            "max_tokens": metadata.get("max_tokens", 2048),
                            "generation_timestamp": datetime.utcnow().isoformat() + "Z"
                        }
                    },
                    {
                        "label": "c2pa.hash.data",
                        "data": {
                            "algorithm": "SHA-256",
                            "hash": content_hash
                        }
                    }
                ]
            },
            watermark={
                "method": "unicode_steganography",
                "strength": "imperceptible",
                "embedded_at": datetime.utcnow().isoformat() + "Z"
            }
        )
        
        return manifest
    
    def _sign_manifest(self, manifest: C2PAManifest) -> bytes:
        """Sign manifest with private key"""
        
        # Serialize manifest for signing
        manifest_json = json.dumps(
            manifest.claim,
            sort_keys=True,
            separators=(',', ':')
        )
        
        # Sign with RSA-PSS
        signature = self.private_key.sign(
            manifest_json.encode(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        return signature
    
    def _generate_watermark_bits(self, manifest: C2PAManifest) -> str:
        """Generate watermark bit string from manifest"""
        
        # Hash manifest to create watermark payload
        manifest_hash = hashlib.sha256(
            manifest.instance_id.encode()
        ).digest()
        
        # Convert to binary string
        watermark_bits = ''.join(format(byte, '08b') for byte in manifest_hash)
        
        return watermark_bits[:128]  # Use first 128 bits
    
    def _embed_watermark(self, content: str, watermark_bits: str) -> str:
        """Embed watermark using Unicode steganography"""
        
        # Homoglyph mapping
        HOMOGLYPHS = {
            'a': ['а', 'ạ', 'ả', 'ã'],  # Latin a -> Cyrillic/Vietnamese
            'e': ['е', 'ẹ', 'ẻ', 'ẽ'],
            'o': ['о', 'ọ', 'ỏ', 'õ'],
            'i': ['і', 'ị', 'ỉ', 'ĩ'],
            'c': ['с', 'ç', 'ć', 'č'],
        }
        
        result = []
        bit_index = 0
        
        for char in content:
            char_lower = char.lower()
            
            if char_lower in HOMOGLYPHS and bit_index < len(watermark_bits):
                if watermark_bits[bit_index] == '1':
                    # Use homoglyph variant
                    variant = HOMOGLYPHS[char_lower][0]
                    result.append(variant if char.islower() else variant.upper())
                else:
                    # Keep original
                    result.append(char)
                bit_index += 1
            else:
                result.append(char)
        
        return ''.join(result)
    
    async def verify_watermark(
        self,
        content: str,
        manifest: C2PAManifest
    ) -> Dict[str, Any]:
        """Verify watermark and manifest"""
        
        # Extract watermark
        extracted_bits = self._extract_watermark(content)
        expected_bits = self._generate_watermark_bits(manifest)
        
        watermark_match = extracted_bits == expected_bits
        
        # Verify signature
        signature_valid = self._verify_signature(manifest)
        
        return {
            "verified": watermark_match and signature_valid,
            "watermark_detected": len(extracted_bits) > 0,
            "watermark_match": watermark_match,
            "signature_valid": signature_valid,
            "confidence": self._calculate_confidence(extracted_bits, expected_bits)
        }
    
    def _extract_watermark(self, content: str) -> str:
        """Extract watermark bits from content"""
        
        HOMOGLYPHS_REVERSE = {
            'а': 'a', 'ạ': 'a', 'ả': 'a', 'ã': 'a',
            'е': 'e', 'ẹ': 'e', 'ẻ': 'e', 'ẽ': 'e',
            'о': 'o', 'ọ': 'o', 'ỏ': 'o', 'õ': 'o',
            'і': 'i', 'ị': 'i', 'ỉ': 'i', 'ĩ': 'i',
            'с': 'c', 'ç': 'c', 'ć': 'c', 'č': 'c',
        }
        
        bits = []
        
        for char in content:
            char_lower = char.lower()
            if char_lower in HOMOGLYPHS_REVERSE:
                bits.append('1')  # Homoglyph detected
            elif char_lower.isalpha():
                bits.append('0')  # Original character
        
        return ''.join(bits)[:128]
    
    def _verify_signature(self, manifest: C2PAManifest) -> bool:
        """Verify manifest signature"""
        
        try:
            # Get signature from manifest
            signature_hex = manifest.claim["signature"]["signature_value"]
            signature = bytes.fromhex(signature_hex)
            
            # Reconstruct signed data
            claim_copy = manifest.claim.copy()
            del claim_copy["signature"]
            manifest_json = json.dumps(claim_copy, sort_keys=True, separators=(',', ':'))
            
            # Verify with public key
            public_key = self.private_key.public_key()
            public_key.verify(
                signature,
                manifest_json.encode(),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Signature verification failed: {e}")
            return False
    
    def _calculate_confidence(self, extracted: str, expected: str) -> float:
        """Calculate watermark confidence score"""
        
        if not extracted or not expected:
            return 0.0
        
        matches = sum(1 for e, x in zip(expected, extracted) if e == x)
        return matches / len(expected)
```

### 3.2 Integration with LLM Service

```python
# app/services/llm_service.py

from app.security.textseal_engine import TextSealEngine, C2PAManifest
import logging

logger = logging.getLogger(__name__)

class LLMService:
    """LLM service with TextSeal watermarking"""
    
    def __init__(self):
        self.textseal = TextSealEngine("/etc/xoenovai/certs/textseal-private-key.pem")
        self.model = self._load_model()
    
    async def generate(
        self,
        prompt: str,
        user_id: str,
        **generation_kwargs
    ) -> Dict[str, Any]:
        """Generate response with watermarking"""
        
        # Generate AI response
        response = await self.model.generate(prompt, **generation_kwargs)
        
        # Prepare metadata
        metadata = {
            "model": "xoe-pantheon-expert",
            "model_version": "1.0.0",
            "prompt": prompt,
            "user_id": user_id,
            "temperature": generation_kwargs.get("temperature", 0.7),
            "max_tokens": generation_kwargs.get("max_tokens", 2048),
            "title": f"Response to: {prompt[:50]}..."
        }
        
        # Watermark content
        watermarked_response, manifest = await self.textseal.watermark_content(
            content=response,
            metadata=metadata
        )
        
        # Store manifest
        await self.store_manifest(manifest)
        
        logger.info(f"Response watermarked: {manifest.instance_id}")
        
        return {
            "response": watermarked_response,
            "instance_id": manifest.instance_id,
            "watermarked": True
        }
```

---

## Part 4: Monitoring & Alerting Deployment

### 4.1 Deploy Prometheus & Grafana

```bash
#!/bin/bash
# deploy-monitoring-stack.sh

set -euo pipefail

echo "📊 Deploying Monitoring Stack..."

# Create monitoring namespace
kubectl create namespace monitoring

# Deploy Prometheus
kubectl apply -f https://raw.githubusercontent.com/prometheus-operator/prometheus-operator/main/bundle.yaml

# Deploy Prometheus instance
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: monitoring
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
      evaluation_interval: 15s
    
    scrape_configs:
      - job_name: 'xoenovai-services'
        kubernetes_sd_configs:
          - role: pod
            namespaces:
              names:
                - xoenovai
        relabel_configs:
          - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
            action: keep
            regex: true
          - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
            action: replace
            target_label: __metrics_path__
            regex: (.+)
          - source_labels: [__address__, __meta_kubernetes_pod_annotation_prometheus_io_port]
            action: replace
            regex: ([^:]+)(?::\d+)?;(\d+)
            replacement: \$1:\$2
            target_label: __address__
EOF

# Deploy Grafana
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update
helm install grafana grafana/grafana \
    --namespace monitoring \
    --set adminPassword=admin \
    --set service.type=LoadBalancer

echo "✅ Monitoring stack deployed!"
echo "Grafana URL: http://$(kubectl get svc -n monitoring grafana -o jsonpath='{.status.loadBalancer.ingress[0].ip}')"
```

### 4.2 Configure Grafana Dashboards

```json
{
  "dashboard": {
    "title": "Xoe-NovAi Security Dashboard",
    "panels": [
      {
        "id": 1,
        "title": "Authentication Failures",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total{code=~\"401|403\"}[5m])",
            "legendFormat": "{{ service }} - {{ code }}"
          }
        ]
      },
      {
        "id": 2,
        "title": "eBPF Security Alerts",
        "type": "stat",
        "targets": [
          {
            "expr": "sum(ebpf_security_alerts_total)",
            "legendFormat": "Total Alerts"
          }
        ]
      },
      {
        "id": 3,
        "title": "Watermark Verification Rate",
        "type": "gauge",
        "targets": [
          {
            "expr": "rate(watermark_verification_success_total[5m]) / rate(watermark_verification_attempts_total[5m])",
            "legendFormat": "Success Rate"
          }
        ]
      },
      {
        "id": 4,
        "title": "Circuit Breaker States",
        "type": "heatmap",
        "targets": [
          {
            "expr": "circuit_breaker_state",
            "legendFormat": "{{ service }}"
          }
        ]
      }
    ]
  }
}
```

---

## Part 5: Compliance Validation & Testing

### 5.1 SOC2 Control Testing

```python
# tests/compliance/test_soc2_controls.py

import pytest
from app.security.iam_service import IAMService
from app.security.abac_engine import OPAClient

@pytest.mark.compliance
class TestSOC2Controls:
    """SOC2 Type II control validation"""
    
    async def test_cc6_1_logical_access(self):
        """CC6.1: Logical and physical access controls"""
        
        # Test MFA requirement
        iam = IAMService()
        
        # Attempt login without MFA should fail
        with pytest.raises(MFARequiredError):
            await iam.authenticate("user", "password", mfa_code=None)
        
        # Login with MFA should succeed
        token = await iam.authenticate("user", "password", mfa_code="123456")
        assert token is not None
    
    async def test_cc6_2_data_transmission(self):
        """CC6.2: Data transmission protection"""
        
        # Verify TLS 1.3 enforcement
        response = await client.get("https://api.xoenovai.local/health")
        assert response.connection.ssl_version == "TLSv1.3"
    
    async def test_cc6_3_threat_mitigation(self):
        """CC6.3: Threat mitigation"""
        
        # Verify eBPF monitoring active
        monitor_status = await get_ebpf_status()
        assert monitor_status["active"] == True
        assert monitor_status["events_processed"] > 0
    
    async def test_a1_1_availability(self):
        """A1.1: System availability monitoring"""
        
        # Verify 99.9% uptime
        metrics = await prometheus.query(
            "avg_over_time(up[30d])"
        )
        assert metrics["value"] >= 0.999
```

### 5.2 GDPR Compliance Testing

```python
# tests/compliance/test_gdpr.py

import pytest
from app.security.gdpr_handler import GDPRHandler

@pytest.mark.compliance
class TestGDPRCompliance:
    """GDPR compliance validation"""
    
    async def test_right_to_access(self):
        """Article 15: Right of access"""
        
        handler = GDPRHandler()
        
        # User requests their data
        data = await handler.handle_access_request(user_id="test-user")
        
        assert "personal_data" in data
        assert "processing_purposes" in data
        assert "retention_periods" in data
    
    async def test_right_to_erasure(self):
        """Article 17: Right to erasure"""
        
        handler = GDPRHandler()
        
        # User requests deletion
        success = await handler.handle_erasure_request(user_id="test-user")
        assert success == True
        
        # Verify data deleted
        with pytest.raises(UserNotFoundError):
            await db.get_user("test-user")
    
    async def test_data_portability(self):
        """Article 20: Right to data portability"""
        
        handler = GDPRHandler()
        
        # Export user data
        export_data = await handler.handle_portability_request(user_id="test-user")
        
        assert isinstance(export_data, bytes)
        assert len(export_data) > 0
        
        # Verify format is machine-readable JSON
        import json
        parsed = json.loads(export_data)
        assert "personal_data" in parsed
```

### 5.3 Security Penetration Testing

```bash
#!/bin/bash
# run-security-tests.sh

set -euo pipefail

echo "🔒 Running Security Penetration Tests..."

# Run OWASP ZAP scan
docker run -t owasp/zap2docker-stable zap-baseline.py \
    -t https://api.xoenovai.local \
    -r zap-report.html

# Run Nikto web scanner
nikto -h https://api.xoenovai.local -output nikto-report.html

# Run SSL/TLS test
testssl.sh --severity MEDIUM https://api.xoenovai.local

# Run authentication bypass tests
python3 tests/security/test_auth_bypass.py

# Run privilege escalation tests
python3 tests/security/test_privesc.py

# Run injection attack tests
python3 tests/security/test_injections.py

echo "✅ Security tests complete! Review reports."
```

---

## Part 6: Deployment & Validation

### 6.1 Production Deployment Checklist

```markdown
# Security Deployment Checklist

## Pre-Deployment
- [ ] All certificates generated and securely stored
- [ ] HSM integrated for key management
- [ ] Secrets manager configured (Vault/AWS Secrets Manager)
- [ ] IAM policies defined and tested
- [ ] ABAC policies loaded into OPA
- [ ] eBPF monitoring programs tested
- [ ] Watermarking engine validated
- [ ] Monitoring stack deployed
- [ ] Alerting rules configured

## Deployment
- [ ] Deploy IAM service with MFA
- [ ] Deploy OPA policy engine
- [ ] Configure mTLS in service mesh
- [ ] Deploy eBPF security monitors
- [ ] Deploy TextSeal watermarking
- [ ] Configure Prometheus scraping
- [ ] Import Grafana dashboards
- [ ] Test end-to-end security flow

## Post-Deployment
- [ ] Run SOC2 control tests
- [ ] Run GDPR compliance tests
- [ ] Conduct penetration testing
- [ ] Verify monitoring and alerting
- [ ] Document security incidents (if any)
- [ ] Schedule security audit
- [ ] Train operations team
- [ ] Update security runbooks
```

### 6.2 Final Validation Script

```bash
#!/bin/bash
# validate-security-deployment.sh

set -euo pipefail

echo "🔍 Validating Security Deployment..."

# 1. Verify IAM service
echo "Testing IAM service..."
curl -f https://iam.xoenovai.local/health || exit 1

# 2. Verify OPA policies
echo "Testing OPA policies..."
curl -f http://localhost:8181/v1/data/xoenovai/authz || exit 1

# 3. Verify mTLS
echo "Testing mTLS..."
kubectl exec -it $(kubectl get pod -l app=rag-service -o jsonpath='{.items[0].metadata.name}') \
    -c istio-proxy -- curl -s http://localhost:15000/config_dump | grep -q "ISTIO_MUTUAL" || exit 1

# 4. Verify eBPF monitoring
echo "Testing eBPF monitoring..."
sudo systemctl is-active xoe-ebpf-monitor || exit 1

# 5. Verify watermarking
echo "Testing watermarking..."
python3 -c "
from app.security.textseal_engine import TextSealEngine
engine = TextSealEngine('/etc/xoenovai/certs/textseal-private-key.pem')
print('✅ Watermarking engine loaded')
" || exit 1

# 6. Verify monitoring
echo "Testing monitoring stack..."
curl -f http://prometheus:9090/-/healthy || exit 1
curl -f http://grafana:3000/api/health || exit 1

echo "✅ All security components validated!"
echo "Security deployment successful! 🎉"
```

---

## Appendix: Quick Reference

### Common Commands

```bash
# Check IAM service status
systemctl status xoe-iam-service

# Reload OPA policies
curl -X PUT --data-binary @policies/xoenovai-authz.rego \
    http://localhost:8181/v1/policies/xoenovai-authz

# View eBPF monitoring logs
sudo journalctl -u xoe-ebpf-monitor -f

# Test watermark verification
python3 scripts/verify-watermark.py --content "text" --manifest manifest.json

# View Grafana dashboards
kubectl port-forward -n monitoring svc/grafana 3000:80
```

### Troubleshooting

**Issue**: MFA authentication failing
```bash
# Check time synchronization (TOTP requires accurate time)
timedatectl status
sudo ntpdate time.nist.gov
```

**Issue**: OPA policy not loading
```bash
# Validate policy syntax
opa test policies/xoenovai-authz.rego

# Check OPA logs
kubectl logs -n xoenovai deployment/opa
```

**Issue**: eBPF program not attaching
```bash
# Verify kernel headers
uname -r
dpkg -l | grep linux-headers-$(uname -r)

# Check BPF filesystem
mount | grep bpf
```

**Issue**: Watermark verification failing
```bash
# Verify certificates
openssl x509 -in /etc/xoenovai/certs/textseal-cert.pem -text -noout

# Test signature verification
python3 scripts/test-signature.py
```

---

**Document Control**
- **Version**: 1.0.0
- **Last Updated**: January 18, 2026
- **Next Review**: March 18, 2026
- **Classification**: Implementation Guide
- **Owner**: Security Implementation Team
