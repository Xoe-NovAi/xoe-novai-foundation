# 🎯 Xoe-NovAi Custom Observability Portal - Complete Implementation v1.0
## Transform Your Stack Into a Real-Time Monitoring Powerhouse

**Date**: 2026-01-19 | **Status**: Production Ready | **Target Audience**: Your specific stack

---

## 📊 OBSERVABILITY PORTAL OVERVIEW

Your Xoe-NovAi stack will become a unified observability system where:
- **Prometheus** scrapes native metrics from your running services
- **Tempo** collects distributed traces from FastAPI instrumentation
- **Loki** aggregates structured JSON logs with trace IDs
- **Grafana** visualizes everything with smart correlations

**Architecture Flow**:
```
FastAPI (uvicorn) ──┐
Chainlit UI ────────┼──→ OpenTelemetry Instrumentation
Crawler (async) ────┤       ↓
Redis Cache ────────┤    OTel Collector
                    │       ↓
                    └──→ Prometheus (metrics)
                        Tempo (traces)
                        Loki (logs)
                        Pyroscope (profiles)
                            ↓
                        Grafana (unified dashboards)
```

---

## 🔧 PHASE 1: ENABLE YOUR EXISTING INSTRUMENTATION

### Step 1: Activate OpenTelemetry in Your Stack

Your `observability.py` already exists with OpenTelemetry support. Enable it in `main.py`:

```python
# In main.py, in the lifespan startup section

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    
    # EXISTING CODE...
    
    # ADD THIS: Initialize AI-Native Observability (Week 2 Integration)
    try:
        from observability import setup_ai_observability
        setup_ai_observability()
        logger.info("✅ Claude v2 AI-Native Observability initialized")
    except Exception as e:
        logger.warning(f"Observability setup failed: {e}")
    
    # EXISTING CODE...
    
    yield
    
    # SHUTDOWN
```

**What This Does**:
- Activates OpenTelemetry SDK with CardinalityManager (prevents metric explosion)
- Registers 12 AI-specific metric categories from your `metrics.py`
- Enables structured tracing with FastAPI hooks
- Starts collecting hardware benchmarks and voice pipeline metrics

### Step 2: Add Prometheus Export to FastAPI

Your `metrics.py` exposes metrics on port 8002. Ensure Prometheus config scrapes it:

**File**: `prometheus/prometheus.yml`

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    cluster: 'xoe-novai'
    stack_version: 'v0.1.5'

scrape_configs:
  # Your RAG API (native Prometheus metrics)
  - job_name: 'xoe-rag-api'
    static_configs:
      - targets: ['rag:8000']
    metrics_path: '/metrics'
    scrape_interval: 15s
    scrape_timeout: 10s

  # Chainlit UI
  - job_name: 'xoe-ui'
    static_configs:
      - targets: ['ui:8001']
    metrics_path: '/metrics'

  # Redis (if using redis_exporter)
  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']

  # Node exporter (system metrics)
  - job_name: 'node'
    static_configs:
      - targets: ['node-exporter:9100']

  # cAdvisor (container metrics)
  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
```

### Step 3: Enable Structured Logging with Trace IDs

Your `logging_config.py` is production-ready. Just ensure it's initialized in `main.py`:

```python
# In main.py startup (already there, but verify)

from logging_config import setup_logging

# Setup structured JSON logging with trace correlation
setup_logging(
    log_level='INFO',
    log_file='/app/XNAi_rag_app/logs/xnai.log',
    console_enabled=True,
    file_enabled=True,
    json_format=True  # JSON output for Loki
)
```

---

## 🎨 PHASE 2: CUSTOMIZE DASHBOARDS FOR YOUR SERVICES

### Dashboard 1: RAG API Performance (RED Method)

**Purpose**: Monitor query processing end-to-end

**Key Metrics from Your Stack**:
```promql
# Rate: Queries per second
rate(http_requests_total{job="xoe-rag-api"}[1m])

# Errors: Error rate %
rate(http_requests_total{job="xoe-rag-api",status=~"5.."}[5m]) / 
rate(http_requests_total{job="xoe-rag-api"}[5m]) * 100

# Duration: P95 latency
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="xoe-rag-api"}[5m]))

# RAG-specific: Retrieval time
histogram_quantile(0.95, rate(xnai_rag_retrieval_time_ms_bucket[5m]))

# Context: Token generation rate
rate(xnai_tokens_generated_total[1m])
```

**Grafana Panel Configuration**:
- **Panel Type**: Time series (for trends)
- **Variables**: `$service`, `$endpoint`
- **Alerts**: P95 > 1000ms, error rate > 1%

### Dashboard 2: Voice Pipeline Analytics

**Your unique metric**: Voice components (STT → LLM → TTS)

```promql
# STT (Speech-to-Text) latency
histogram_quantile(0.95, rate(voice_stt_latency_ms_bucket[5m]))

# LLM Token rate (from metrics.py)
xnai_token_rate_tps

# TTS (Text-to-Speech) latency
histogram_quantile(0.95, rate(voice_tts_latency_ms_bucket[5m]))

# Total voice pipeline latency
rate(voice_processing_duration_seconds[5m])
```

**Heatmap Visualization**: Show latency distribution across time, identify performance degradation patterns

### Dashboard 3: Session & Cache Performance

**From your Redis + memory tracking**:

```promql
# Active sessions (from metrics.py)
xnai_active_sessions

# Memory usage by component
xnai_memory_usage_bytes

# Cache hit rate (your redis.cache config)
rate(redis_keyspace_hits_total[5m]) / (rate(redis_keyspace_hits_total[5m]) + rate(redis_keyspace_misses_total[5m]))

# FAISS search latency
histogram_quantile(0.95, rate(xnai_rag_retrieval_time_ms_bucket[5m]))
```

### Dashboard 4: AI-Native Observability (From observability.py)

**Your 12 metric categories**:

```promql
# Model inference duration
histogram_quantile(0.95, rate(ai_model_inference_duration_seconds_bucket[5m]))

# Circuit breaker status (multi-color gauge)
circuit_breaker_state{breaker="rag-api"}
circuit_breaker_state{breaker="redis-connection"}
circuit_breaker_state{breaker="voice-processing"}

# Anomaly score (red if > 0.7)
ai_system_anomaly_score

# Token economics
llm_tokens_total

# System health
system_memory_usage_bytes / 1024 / 1024 / 1024  # Convert to GB
```

---

## 🔗 PHASE 3: SIGNAL CORRELATION (The Magic)

### Setup 1: Metrics → Logs Correlation

When you see high error rate in Prometheus, jump to logs showing what went wrong.

**Configuration**: `grafana/provisioning/datasources/prometheus-datasource.yml`

```yaml
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    
    jsonData:
      # Link metrics to logs
      derivedFields:
        - name: "Error Logs"
          value: 'service="xoe-rag-api" AND error_code="${error_type}"'
          url: '/explore?datasource=Loki&query=${value}'
```

### Setup 2: Logs → Traces Correlation

Your structured logs now contain `trace_id`. Extract it:

**Configuration**: `grafana/provisioning/datasources/loki-datasource.yml`

```yaml
apiVersion: 1

datasources:
  - name: Loki
    type: loki
    url: http://loki:3100
    
    jsonData:
      # Extract trace_id from JSON logs
      derivedFields:
        - name: TraceID
          matcherRegex: '"trace_id":"([^"]*)"'
          url: 'http://tempo:3200/search?traceID=${value}'
          datasourceUid: tempo-uid
          
        - name: ServiceName
          matcherRegex: '"service":"([^"]*)"'
```

### Setup 3: Traces → Profiles Correlation

When a trace shows slow inference, jump to profiler to see CPU/memory hotspots.

**Configuration**: `grafana/provisioning/correlations/tempo-pyroscope.yml`

```yaml
apiVersion: v1

correlations:
  - name: "Traces to Profiles"
    sourceUID: "tempo-uid"
    targetUID: "pyroscope-uid"
    description: "View CPU/memory profile during slow trace"
    field: "serviceName"
    transformations:
      - type: regex
        field: "duration"
        expression: "([0-9.]+)s"
        mapValue: "durationMs"
    query:
      target:
        expr: 'service="${serviceName}" AND duration>${durationMs}'
```

---

## 📈 PHASE 4: AUTOMATED DASHBOARDS WITH YOUR METRICS

Your `metrics.py` defines 12+ metrics. Grafana can auto-generate dashboards:

**Command**:
```bash
# Generate dashboard from existing metrics
grafana-cli admin provisioning dashboards generate \
  --datasource=Prometheus \
  --job=xoe-rag-api \
  --output-file=auto-generated-dashboard.json
```

Or manually create panels referencing your metrics:

```python
# In dashboards/auto-rag-dashboard.json

{
  "dashboard": {
    "title": "Auto-Generated RAG Dashboard",
    "panels": [
      {
        "title": "Request Rate (from metrics.py)",
        "targets": [
          {
            "expr": "rate(xnai_requests_total{job='xoe-rag-api'}[1m])"
          }
        ]
      },
      {
        "title": "Error Rate",
        "targets": [
          {
            "expr": "rate(xnai_errors_total{job='xoe-rag-api'}[5m])"
          }
        ]
      },
      {
        "title": "Token Generation",
        "targets": [
          {
            "expr": "rate(xnai_tokens_generated_total[1m])"
          }
        ]
      }
    ]
  }
}
```

---

## 🚀 PHASE 5: ACTIVATE INTELLIGENT ALERTING

### Alert 1: SLO Breach (Error Budget)

```yaml
# prometheus/rules/slo-alerts.yml

groups:
  - name: xoe-novai-slo
    interval: 1m
    rules:
      - alert: ErrorBudgetExhaustion
        expr: |
          (1 - (sum(rate(xnai_requests_total{status=~"2.."}[28d])) / 
           sum(rate(xnai_requests_total[28d])))) > 0.001
        for: 5m
        labels:
          severity: critical
          service: xoe-rag-api
        annotations:
          summary: "Error budget consumed ({{ $value | humanizePercentage }})"
          runbook: "https://wiki.xoe-novai.local/runbooks/error-budget"
          
      - alert: P95LatencyHigh
        expr: |
          histogram_quantile(0.95, rate(xnai_response_latency_ms_bucket[5m])) > 1000
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "P95 latency high: {{ $value }}ms"
```

### Alert 2: Voice Pipeline Degradation

```yaml
      - alert: VoiceSTTLatencyHigh
        expr: |
          histogram_quantile(0.95, rate(voice_stt_latency_ms_bucket[5m])) > 300
        for: 5m
        labels:
          severity: warning
          component: voice-stt
        annotations:
          summary: "STT latency degraded: {{ $value }}ms (target: <300ms)"
          
      - alert: CircuitBreakerOpen
        expr: circuit_breaker_state{breaker="rag-api"} == 1
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "RAG API circuit breaker is OPEN"
          runbook: "Check /api/circuit-breakers endpoint for details"
```

### Alert 3: Resource Constraints

```yaml
      - alert: MemoryUsageHigh
        expr: |
          xnai_memory_usage_gb > 4.5
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Memory usage: {{ $value }}GB (limit: 5GB)"
```

---

## 🎯 PHASE 6: OBSERVABILITY PORTAL FEATURES

### Feature 1: Service Dependency Graph

In Grafana Tempo, view which services call which:
- RAG API → Redis (cache lookups)
- RAG API → FAISS (vector search)
- Chainlit UI → RAG API (queries)
- Crawler → Redis (coordination)

### Feature 2: Error Causation Analysis

Click an error in the dashboard → See:
1. **Error logs** (from Loki)
2. **Full trace** (from Tempo) showing exactly which operation failed
3. **CPU profile** (from Pyroscope) if it was a performance issue
4. **Related errors** from past 24h

### Feature 3: Performance Regression Detection

AI-powered anomaly detection (from `observability.py`):
- Automatically flags when P95 latency increases >20%
- Detects when error rate unusual
- Compares current performance to baseline

---

## 🔧 DEPLOYMENT CHECKLIST

```
INFRASTRUCTURE
☐ Prometheus running, scraping your services
☐ Tempo receiving spans from OTel Collector
☐ Loki receiving logs (Promtail configured)
☐ Pyroscope enabled (optional but recommended)
☐ Grafana accessing all data sources

INSTRUMENTATION
☐ FastAPI instrumented (FastAPIInstrumentor.instrument_app)
☐ Chainlit UI has OpenTelemetry hooks
☐ Logging includes trace_id in JSON
☐ Metrics module exporting on port 8002
☐ observability.py initialized in main.py lifespan

DATA CORRELATION
☐ Loki data source has derived fields for trace_id
☐ Prometheus has links to Loki
☐ Tempo configured to show trace → profile links
☐ Grafana correlations set up for all pairs

DASHBOARDS
☐ RAG API dashboard created and populated
☐ Voice pipeline dashboard active
☐ Session/cache dashboard configured
☐ AI-Native observability dashboard linked
☐ Alert rules loaded into Prometheus

ALERTS
☐ Error budget alert configured
☐ Latency alerts active
☐ Circuit breaker alert set
☐ Memory usage alert enabled
☐ Notification channels tested (Slack/email)
```

---

## 🎓 NEXT: ADVANCED ANALYSIS

With this portal operational, you can now:

1. **Analyze voice AI quality**: See STT accuracy, TTS latency, LLM token rate correlations
2. **Research scaling limits**: Identify bottlenecks (Redis? FAISS? LLM inference?)
3. **Optimize performance**: Profile slow traces, fix hotspots
4. **Study error patterns**: See which components fail under load
5. **Track business metrics**: User satisfaction (voice quality), session engagement, cost per query

---

**Implementation Effort**: 2-3 hours setup + 1 hour customization  
**Payoff**: Complete observability of your AI stack  
**Maintenance**: 15 minutes/week (reviewing dashboards, tuning alerts)