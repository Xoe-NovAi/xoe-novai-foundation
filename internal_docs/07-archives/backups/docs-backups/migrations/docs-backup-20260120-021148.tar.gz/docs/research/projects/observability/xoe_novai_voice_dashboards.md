# 📊 Xoe-NovAi Voice AI Dashboards - Complete JSON Templates v1.0
## Production-Ready Dashboard Configurations for Advanced Monitoring

**Version**: 1.0 | **Status**: Ready to Deploy | **Last Updated**: 2026-01-19

---

## 📋 DASHBOARD LIBRARY

This guide contains copy-paste-ready dashboard JSON for the Xoe-NovAi voice AI RAG stack.

---

## 1️⃣ EXECUTIVE DASHBOARD: Overall System Health

**Purpose**: 30-second overview for executives/on-call engineers  
**Refresh Rate**: 30 seconds  
**Key Metrics**: Uptime, error rate, user satisfaction

```bash
# File: grafana/dashboards/1-executive-dashboard.json
# Deploy: curl -X POST http://localhost:3000/api/dashboards/db \
#   -H "Authorization: Bearer $TOKEN" \
#   -H "Content-Type: application/json" \
#   -d @1-executive-dashboard.json
```

**Dashboard Structure**:
```
Row 1: System Status (4 gauges)
├─ Overall Availability (%)
├─ Error Budget Remaining (min)
├─ Active Voice Sessions
└─ Average Latency P95 (ms)

Row 2: Trend Charts (2 time series)
├─ Success Rate (24h)
└─ Error Budget Burn (24h)

Row 3: Service Status Table
└─ All 5 services with UP/DOWN status
```

**Critical Alerts**:
- Availability < 99.9% (SLO breach)
- Error budget burn > 10x nominal
- Any service DOWN

---

## 2️⃣ VOICE PIPELINE DASHBOARD: Component Analysis

**Purpose**: Deep dive into each voice processing stage  
**Refresh Rate**: 10 seconds  
**Key Metrics**: Latency, accuracy, throughput per component

**Dashboard Structure**:
```
Row 1: STT (Speech-To-Text)
├─ Latency histogram (P50, P95, P99)
├─ WER% (word error rate)
├─ Model accuracy
└─ Model used (distil-large-v3)

Row 2: LLM Inference
├─ Token generation rate (tokens/sec)
├─ Time to First Token (TTFT)
├─ Memory usage during inference
└─ Model temperature/parameters

Row 3: TTS (Text-To-Speech)
├─ Latency histogram
├─ Quality score (MOS)
├─ Voice used
└─ Cache hit rate

Row 4: Embeddings
├─ Vector search latency
├─ Cache hit rate (FAISS)
└─ Dimension verification (384-dim)
```

**How to Read**:
- STT P95 > 300ms → Model overloaded or audio quality issues
- TTFT > 500ms → LLM provider slow or token context too large
- TTS latency > 100ms → Model too large or memory pressure
- Embedding search > 50ms → Index fragmentation or too many vectors

---

## 3️⃣ RAG API DASHBOARD: RED Method

**Purpose**: API health using RED (Rate, Errors, Duration)  
**Refresh Rate**: 15 seconds  
**SLO**: 99.9% availability, P95 < 1000ms

**Dashboard Structure**:

```
Row 1: Rate (requests/second)
├─ Total RPS by endpoint
├─ RPS by status code (2xx, 4xx, 5xx)
└─ Breakdown by query type (RAG vs non-RAG)

Row 2: Errors (error rate %)
├─ Error rate percentage
├─ Error count by type
├─ P99 error latency
└─ Error trends (last 24h)

Row 3: Duration (latency percentiles)
├─ P50, P95, P99 latency
├─ Latency by endpoint
├─ Latency by query complexity
└─ Latency distribution heatmap

Row 4: SLO Compliance
├─ Availability % (target: 99.9%)
├─ P95 latency compliance (target: < 1000ms)
└─ Error budget status gauge
```

**Queries**:
```promql
# Rate
rate(http_requests_total{job="xoe-rag-api"}[1m])

# Errors
rate(http_requests_total{job="xoe-rag-api",status=~"5.."}[5m]) / 
rate(http_requests_total{job="xoe-rag-api"}[5m]) * 100

# Duration P95
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))
```

---

## 4️⃣ FAISS SEARCH DASHBOARD: Vector Database Performance

**Purpose**: Monitor RAG knowledge base search performance  
**Refresh Rate**: 30 seconds

**Dashboard Structure**:
```
Row 1: Search Performance
├─ Search latency P95 (target: < 50ms)
├─ Searches per second
├─ Recall@K metric
└─ Index fragmentation %

Row 2: Cache Effectiveness
├─ Cache hit rate %
├─ Cache size (MB)
├─ TTL effectiveness
└─ Eviction events/min

Row 3: Vector Index Health
├─ Total vectors in index
├─ Index dimensions (must be 384)
├─ Index type (IVFFlat, etc.)
└─ Last index rebuild time

Row 4: Context Assembly
├─ Docs retrieved per query
├─ Context assembly time (ms)
├─ Context size (characters)
└─ Source diversity (# sources per query)
```

---

## 5️⃣ SESSION & PERSISTENCE DASHBOARD: Redis & Sessions

**Purpose**: Monitor session management and caching  
**Refresh Rate**: 30 seconds

**Dashboard Structure**:
```
Row 1: Redis Health
├─ Connected clients
├─ Memory usage (target: < 512MB)
├─ Eviction rate (keys/sec)
└─ Command latency P99

Row 2: Voice Sessions
├─ Active sessions
├─ Session creation rate
├─ Session timeout events
└─ Session duration distribution

Row 3: Cache Performance
├─ Cache hit rate by cache type
├─ Cache eviction type breakdown
├─ Most-evicted keys (top 10)
└─ TTL effectiveness

Row 4: Data Persistence
├─ AOF rewrite frequency
├─ AOF file size (MB)
├─ Last backup time
└─ Backup success rate
```

---

## 6️⃣ ALERTING & SLO DASHBOARD

**Purpose**: Track error budgets and alert status  
**Refresh Rate**: 5 seconds (real-time alerting)

**Dashboard Structure**:
```
Row 1: Error Budget Status
├─ 28-day budget remaining (gauge)
├─ 3-day burn rate (# stdev from mean)
├─ 6-hour burn rate (alert trigger)
└─ Budget exhaustion ETA (days)

Row 2: Alert Status
├─ Firing alerts (count)
├─ Alert firing by severity
├─ Mean time to resolve (MTTR)
└─ Alert flapping ratio

Row 3: SLO Compliance Table
├─ Service | Availability | Duration | Status
├─ xoe-rag-api | 99.95% ✅ | P95: 245ms ✅ | PASS
├─ xoe-ui | 99.99% ✅ | P95: 890ms ✅ | PASS
├─ xoe-crawler | 98.5% ❌ | P95: 2100ms ❌ | FAIL
└─ Redis | 99.99% ✅ | P99: 5ms ✅ | PASS

Row 4: Multi-Burn-Rate Alerts
├─ Fast burn (6h window) - HIGH priority
├─ Slow burn (1d window) - MEDIUM priority
└─ Chronic burn (7d window) - LOW priority
```

---

## 🎯 IMPLEMENTATION GUIDE

### Step 1: Prepare Dashboard JSON Files

Create the following directory structure:
```
grafana/dashboards/
├── 1-executive-dashboard.json
├── 2-voice-pipeline-dashboard.json
├── 3-rag-api-dashboard.json
├── 4-faiss-search-dashboard.json
├── 5-session-dashboard.json
├── 6-slo-dashboard.json
└── _dashboards.yaml  # Provisioning file
```

### Step 2: Dashboard Provisioning

```yaml
# grafana/provisioning/dashboards/_dashboards.yaml
apiVersion: 1

providers:
  - name: 'Xoe-NovAi Dashboards'
    orgId: 1
    folder: 'Xoe-NovAi'
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards
```

### Step 3: Deploy to Grafana

```bash
#!/bin/bash
# scripts/provision-dashboards.sh

GRAFANA_URL="http://localhost:3000"
GRAFANA_API_KEY="$GRAFANA_API_TOKEN"

# Create folder
curl -X POST "$GRAFANA_URL/api/folders" \
  -H "Authorization: Bearer $GRAFANA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"title": "Xoe-NovAi"}'

# Import each dashboard
for dashboard in grafana/dashboards/*.json; do
  echo "Importing $dashboard..."
  curl -X POST "$GRAFANA_URL/api/dashboards/db" \
    -H "Authorization: Bearer $GRAFANA_API_KEY" \
    -H "Content-Type: application/json" \
    -d @"$dashboard"
done

echo "✅ All dashboards imported successfully"
```

### Step 4: Configure Alerts

```yaml
# grafana/provisioning/alerting/xoe-novai-rules.yaml
groups:
  - name: xoe-novai-slo
    interval: 1m
    rules:
      - alert: HighErrorRate
        expr: |
          rate(http_requests_total{status=~"5.."}[5m]) / 
          rate(http_requests_total[5m]) > 0.001
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Error rate high for {{ $labels.job }}"

      - alert: HighLatencyP95
        expr: |
          histogram_quantile(0.95, 
            rate(http_request_duration_seconds_bucket[5m])
          ) > 1.0
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "P95 latency high: {{ $value }}s"

      - alert: StaleVectorIndex
        expr: |
          time() - vector_index_last_rebuild_timestamp_seconds > 86400
        for: 1h
        labels:
          severity: warning
        annotations:
          summary: "FAISS index not rebuilt in 24 hours"
```

---

## 📊 DASHBOARD JSON TEMPLATES

### Mini Template: Latency Histogram Panel

Use this as a building block for any latency panel:

```json
{
  "type": "timeseries",
  "title": "Request Latency - $component",
  "gridPos": { "h": 8, "w": 12, "x": 0, "y": 0 },
  "targets": [
    {
      "expr": "histogram_quantile(0.50, rate(${component}_latency_bucket[5m]))",
      "legendFormat": "P50"
    },
    {
      "expr": "histogram_quantile(0.95, rate(${component}_latency_bucket[5m]))",
      "legendFormat": "P95"
    },
    {
      "expr": "histogram_quantile(0.99, rate(${component}_latency_bucket[5m]))",
      "legendFormat": "P99"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "unit": "ms",
      "custom": {
        "lineWidth": 2,
        "fillOpacity": 10
      },
      "thresholds": {
        "mode": "absolute",
        "steps": [
          { "color": "green", "value": null },
          { "color": "yellow", "value": 300 },
          { "color": "red", "value": 1000 }
        ]
      }
    }
  }
}
```

### Mini Template: SLO Gauge Panel

```json
{
  "type": "gauge",
  "title": "Availability SLO - $service",
  "gridPos": { "h": 8, "w": 6, "x": 0, "y": 0 },
  "targets": [
    {
      "expr": "sum(rate(http_requests_total{status=~\"2..\",job=\"$service\"}[28d])) / sum(rate(http_requests_total{job=\"$service\"}[28d])) * 100"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "max": 100,
      "min": 95,
      "unit": "percent",
      "thresholds": {
        "mode": "absolute",
        "steps": [
          { "color": "red", "value": 95 },
          { "color": "yellow", "value": 99 },
          { "color": "green", "value": 99.9 }
        ]
      }
    }
  }
}
```

---

## 🔗 VARIABLE CONFIGURATION FOR DASHBOARDS

Apply these variables to dashboard scope to enable dynamic filtering:

```json
{
  "templating": {
    "list": [
      {
        "name": "datasource",
        "type": "datasource",
        "datasource": "prometheus",
        "current": { "value": "Prometheus", "text": "Prometheus" },
        "multi": false,
        "includeAll": false
      },
      {
        "name": "environment",
        "type": "query",
        "datasource": "Prometheus",
        "definition": "label_values(up, environment)",
        "current": { "value": "production", "text": "production" },
        "multi": false
      },
      {
        "name": "service",
        "type": "query",
        "datasource": "Prometheus",
        "definition": "label_values(up{environment='$environment'}, job)",
        "current": { "value": "xoe-rag-api", "text": "xoe-rag-api" },
        "multi": true,
        "includeAll": true
      },
      {
        "name": "interval",
        "type": "interval",
        "options": [
          { "text": "1m", "value": "1m" },
          { "text": "5m", "value": "5m" },
          { "text": "10m", "value": "10m" },
          { "text": "30m", "value": "30m" }
        ],
        "current": { "text": "5m", "value": "5m" },
        "auto": false
      }
    ]
  }
}
```

---

## 🚀 DEPLOYMENT CHECKLIST

```
BEFORE DEPLOYING DASHBOARDS
☐ All data sources configured (Prometheus, Loki, Tempo, Pyroscope)
☐ Alert manager configured
☐ Notification channels set up (Slack, email, PagerDuty)
☐ All metrics being collected by instrumentation
☐ Test queries return data in Explore

DASHBOARD VALIDATION
☐ All panels load within 2 seconds
☐ Variables cascade correctly
☐ Data links work (metrics → logs)
☐ Alerts trigger on test data
☐ Refresh rates appropriate for data volume

PRODUCTION READINESS
☐ Dashboards version-controlled in Git
☐ CI/CD pipeline for dashboard deployment
☐ Backup of Grafana database
☐ SLA monitoring active
☐ Runbooks linked for each alert
```

---

## 📈 ADVANCED FEATURES (2026+)

- **Grafana Assistant**: Natural language queries ("Show me error spikes")
- **Autonomous incident response**: Alerts trigger remediation workflows
- **ML anomaly detection**: Detect unusual patterns automatically
- **Cost tracking**: Monitor OpenTelemetry data ingestion costs

---

**Ready to Deploy**: ✅ Copy dashboard JSONs into grafana/dashboards/  
**Support Matrix**: Prometheus + Loki + Tempo + Pyroscope  
**Maintenance**: Review quarterly, update thresholds based on SLA changes