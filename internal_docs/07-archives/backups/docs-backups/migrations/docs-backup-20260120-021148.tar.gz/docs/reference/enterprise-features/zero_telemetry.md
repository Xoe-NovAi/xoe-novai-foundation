# Zero Telemetry Enterprise Feature

**Implemented in 11 endpoints**

## `get_session_stats()` (chainlit_app)

Get current session statistics.

Returns:
    Dict with session stats...

## `check_api_health()` (chainlit_app)

Check if RAG API is available.

Returns:
    Tuple of (is_healthy, message)...

## `stream_from_api(query: str, use_rag: bool, max_tokens: int)` (chainlit_app)

Stream response from RAG API via SSE.

Guide Reference: Section 4.2 (API Streaming)

Args:
    query: User query
    use_rag: Whether to use RAG
    max_tokens: Maximum tokens to generate
    
Yields:...

## `query_local_llm(query: str, max_tokens: int)` (chainlit_app)

Fallback to local LLM if API unavailable.

Guide Reference: Section 4.2 (Local Fallback)
Best Practice: Graceful degradation

Args:
    query: User query string
    max_tokens: Maximum tokens to gener...

## `on_message(message: cl.Message)` (chainlit_app)

Handle incoming messages.

Guide Reference: Section 4.2 (Message Handler)

Args:
    message: User message from Chainlit...

## `get_config_value(key_path: str, default: Any)` (config_loader)

Get nested config value by dot-notation path.

Guide Reference: Section 3.2 (Nested Config Access)

This provides convenient access to deeply nested config values
without multiple dict lookups.

Args:...

## `get_config_summary()` (config_loader)

Return a compact summary of important config values for diagnostics.

Guide Reference: Section 3.2 (Config Summary)

Returns:
    Dict with key metrics and settings

Example:
    >>> summary = get_con...

## `trace_llm_call(self, model: str, prompt: str, response: str, tokens_used: int, **kwargs)` (observability)

Trace LLM API calls with GenAI semantic conventions....

## `instrument_fastapi_app(self, app)` (observability)

Instrument FastAPI application with OpenTelemetry....

## `get_tracer(self)` (observability)

Get the GenAI tracer....

## `get_metrics(self)` (observability)

Get the GenAI metrics collector....

