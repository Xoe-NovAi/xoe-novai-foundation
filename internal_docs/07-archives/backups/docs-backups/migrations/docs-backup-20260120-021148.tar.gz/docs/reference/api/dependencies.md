# Dependencies API Reference

**Endpoints**: 10

## `get_curator(cache_dir: Optional[str], **kwargs)`

Initialize CrawlModule for library curation.

Guide Reference: Section 4.3 (CrawlModule Integration)
Guide Reference: Section 9.2 (CrawlModule Architecture)

NEW in v0.1.4: Provides access to CrawlModule for:
- Library curation from 4 sources (Gutenberg, arXiv, PubMed, YouTube)
- Rate limiting (30 req/min)
- URL allowlist validation
- Metadata tracking in knowledge/curator/index.toml
- Redis caching
- Auto-embed to FAISS (optional)

Args:
    cache_dir: Cache directory (default: /app/cache)
    **kwargs: Additional crawler parameters
    
Returns:
    Initialized crawler instance (from crawl.py functions)
    
Note:
    Returns a dict of functions from crawl.py module, not a class instance

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /curator
**Response Model**: Any
**Enterprise Features**: enterprise_monitoring

---

## `get_embeddings(model_path: Optional[str], **kwargs)`

Initialize LlamaCppEmbeddings model.

Guide Reference: Section 4.2.2 (Embeddings - 50% memory savings)

LlamaCppEmbeddings advantages:
- 50% memory savings vs HuggingFaceEmbeddings
- No PyTorch dependency
- CPU-optimized for Ryzen architecture
- 384 dimensions (all-MiniLM-L12-v2 model)

Args:
    model_path: Path to embedding model (default: from config)
    **kwargs: Additional parameters
    
Returns:
    Initialized LlamaCppEmbeddings instance

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /embeddings
**Response Model**: LlamaCppEmbeddings
**Enterprise Features**: enterprise_monitoring

---

## `get_embeddings_async(model_path: Optional[str], **kwargs)`

Async wrapper for embeddings initialization.

Args:
    model_path: Path to model
    **kwargs: Additional parameters
    
Returns:
    Initialized embeddings

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /embeddings_async
**Response Model**: LlamaCppEmbeddings
**Enterprise Features**: enterprise_monitoring

---

## `get_http_client()`

Get shared HTTP client (singleton pattern).

Returns:
    Async HTTP client

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /http_client
**Response Model**: httpx.AsyncClient
**Enterprise Features**: enterprise_monitoring

---

## `get_llm(model_path: Optional[str], **kwargs)`

Initialize LlamaCpp LLM with Ryzen optimization.

Guide Reference: Section 4.2.1 (LLM Configuration)

Critical optimizations:
- f16_kv=true: Halves KV cache memory (~1GB savings)
- n_threads=6: Optimal for Ryzen 7 5700U (75% of 8C/16T)
- use_mlock=true: Lock model in RAM (prevent swapping)
- use_mmap=true: Memory-mapped file access for efficiency

Args:
    model_path: Path to GGUF model (default: from config)
    **kwargs: Additional llama-cpp parameters
    
Returns:
    Initialized LlamaCpp instance
    
Raises:
    MemoryError: If insufficient memory
    FileNotFoundError: If model not found
    RuntimeError: If initialization fails after 3 retries

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /llm
**Response Model**: LlamaCpp
**Enterprise Features**: enterprise_monitoring

---

## `get_llm_async(model_path: Optional[str], **kwargs)`

Async wrapper for LLM initialization.

Args:
    model_path: Path to model
    **kwargs: Additional parameters
    
Returns:
    Initialized LLM

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /llm_async
**Response Model**: LlamaCpp
**Enterprise Features**: enterprise_monitoring

---

## `get_redis_client()`

Get Redis client (singleton pattern).

Guide Reference: Section 4.1 (Redis Client)

Returns:
    Redis client instance

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /redis_client
**Enterprise Features**: enterprise_monitoring

---

## `get_redis_client_async()`

Get async Redis client (requires redis[asyncio]).

Returns:
    Async Redis client

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /redis_client_async
**Enterprise Features**: enterprise_monitoring

---

## `get_vectorstore(embeddings: Optional[LlamaCppEmbeddings], index_path: Optional[str], backup_path: Optional[str])`

Load FAISS vectorstore with backup fallback.

Guide Reference: Section 4.2.3 (FAISS Backup Strategy)

Loading strategy:
1. Try primary index at /app/XNAi_rag_app/faiss_index
2. If primary fails, try backups (most recent first, up to 5)
3. If backup succeeds, restore it to primary location
4. If verify_on_load=true, validate with test search

Args:
    embeddings: Embeddings instance (will be created if None)
    index_path: Primary index path (default: from config)
    backup_path: Backup directory path (default: from config)
    
Returns:
    Loaded FAISS vectorstore or None if not found

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /vectorstore
**Response Model**: Optional[FAISS]
**Enterprise Features**: enterprise_monitoring

---

## `get_vectorstore_async(embeddings: Optional[LlamaCppEmbeddings], index_path: Optional[str], backup_path: Optional[str])`

Async wrapper for vectorstore initialization.

Args:
    embeddings: Embeddings instance
    index_path: Primary index path
    backup_path: Backup directory
    
Returns:
    Loaded vectorstore or None

**Module**: `dependencies`
**HTTP Method**: GET
**Route**: /vectorstore_async
**Response Model**: Optional[FAISS]
**Enterprise Features**: enterprise_monitoring

---

