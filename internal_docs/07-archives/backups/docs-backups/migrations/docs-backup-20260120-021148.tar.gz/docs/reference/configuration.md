# Configuration Reference

Complete guide to Xoe-NovAi configuration options and environment variables.

## Environment Variables

### Core Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `XOE_MODEL_PATH` | `./models` | Path to AI model files |
| `XOE_REDIS_URL` | `redis://localhost:6379` | Redis connection URL |
| `XOE_LOG_LEVEL` | `INFO` | Logging level (DEBUG, INFO, WARNING, ERROR) |
| `XOE_API_KEY` | None | API authentication key |

### AI Model Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `XOE_MODEL` | `llama-2-7b-chat` | Primary AI model name |
| `XOE_MAX_TOKENS` | `2048` | Maximum tokens per response |
| `XOE_TEMPERATURE` | `0.7` | Response creativity (0.0-1.0) |
| `XOE_CONTEXT_WINDOW` | `4096` | Maximum context length |
| `XOE_TOP_P` | `0.9` | Nucleus sampling parameter |
| `XOE_TOP_K` | `40` | Top-k sampling parameter |

### Voice Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `XOE_VOICE_MODEL` | `en_US-lessac-medium` | Default TTS voice |
| `XOE_SPEECH_RATE` | `1.0` | Speech playback speed |
| `XOE_VOICE_VOLUME` | `1.0` | Voice output volume |
| `XOE_STT_MODEL` | `medium` | Speech-to-text model size |
| `XOE_VOICE_CACHE_DIR` | `./cache/voice` | Voice cache directory |

### Performance Tuning

| Variable | Default | Description |
|----------|---------|-------------|
| `XOE_CUDA_VISIBLE_DEVICES` | None | GPU device selection |
| `XOE_NUM_THREADS` | Auto | CPU thread count |
| `XOE_BATCH_SIZE` | `1` | Inference batch size |
| `XOE_CACHE_SIZE` | `512MB` | Response cache size |
| `XOE_MAX_CONNECTIONS` | `100` | Maximum concurrent connections |

### Enterprise Features

| Variable | Default | Description |
|----------|---------|-------------|
| `XOE_ENTERPRISE_MODE` | `false` | Enable enterprise features |
| `XOE_SECURITY_AUDITING` | `false` | Enable security event logging |
| `XOE_COMPLIANCE_MODE` | `gdpr` | Compliance standard (gdpr, hipaa, soc2) |
| `XOE_ENCRYPTION_KEY` | None | Data encryption key |
| `XOE_AUDIT_LOG_PATH` | `./logs/audit` | Security audit log location |

## Configuration Files

### Docker Compose Override

Create `docker-compose.override.yml` for custom configurations:

```yaml
version: '3.8'
services:
  api:
    environment:
      - XOE_MODEL=gpt2-medium
      - XOE_MAX_TOKENS=1024
      - XOE_TEMPERATURE=0.8
    volumes:
      - ./custom-models:/app/models
    deploy:
      resources:
        limits:
          memory: 4G
          cpus: '2.0'

  ui:
    environment:
      - XOE_VOICE_MODEL=en_GB-alan-medium
    ports:
      - "8080:8001"  # Custom port
```

### Application Configuration

The main configuration file `config.toml`:

```toml
[server]
host = "0.0.0.0"
port = 8000
workers = 4
timeout = 300

[ai]
model_path = "./models"
model_name = "llama-2-7b-chat"
max_tokens = 2048
temperature = 0.7
context_window = 4096

[voice]
tts_model = "en_US-lessac-medium"
stt_model = "medium"
speech_rate = 1.0
cache_dir = "./cache/voice"

[database]
redis_url = "redis://localhost:6379"
cache_ttl = 3600
max_connections = 100

[security]
api_key_required = false
rate_limiting = true
requests_per_minute = 60
encryption_enabled = false

[monitoring]
prometheus_enabled = true
metrics_port = 9090
log_level = "INFO"
```

### Voice Configuration

Advanced voice settings in `voice_config.json`:

```json
{
  "default_voice": "en_US-lessac-medium",
  "fallback_voices": [
    "en_US-ryan-medium",
    "en_GB-alan-medium"
  ],
  "audio_settings": {
    "sample_rate": 22050,
    "channels": 1,
    "format": "wav"
  },
  "speech_settings": {
    "rate": 1.0,
    "volume": 1.0,
    "pitch": 1.0
  },
  "noise_reduction": {
    "enabled": true,
    "sensitivity": 0.5
  }
}
```

## Service-Specific Configuration

### API Service Configuration

```python
# config.py
from pydantic import BaseSettings

class APISettings(BaseSettings):
    model_path: str = "./models"
    redis_url: str = "redis://localhost:6379"
    max_tokens: int = 2048
    temperature: float = 0.7

    class Config:
        env_prefix = "XOE_"
        case_sensitive = False

settings = APISettings()
```

### UI Service Configuration

```javascript
// config.js
const config = {
  apiUrl: process.env.REACT_APP_API_URL || 'http://localhost:8000',
  voiceEnabled: process.env.REACT_APP_VOICE_ENABLED === 'true',
  theme: process.env.REACT_APP_THEME || 'light',
  maxRetries: parseInt(process.env.REACT_APP_MAX_RETRIES) || 3
};

export default config;
```

## Runtime Configuration

### Dynamic Reconfiguration

Xoe-NovAi supports runtime configuration changes:

```bash
# Update voice settings
curl -X POST http://localhost:8000/config/voice \
  -H "Content-Type: application/json" \
  -d '{"speech_rate": 1.2, "voice_model": "en_GB-alan-medium"}'

# Update AI parameters
curl -X POST http://localhost:8000/config/ai \
  -H "Content-Type: application/json" \
  -d '{"temperature": 0.8, "max_tokens": 1024}'
```

### Configuration Validation

All configurations are validated at startup:

```bash
# Validate configuration
docker-compose exec api python -c "from config import settings; print('Config valid')"

# Check for missing required settings
docker-compose exec api python -c "import os; required = ['XOE_MODEL_PATH']; missing = [k for k in required if not os.getenv(k)]; print('Missing:', missing)"
```

## Environment-Specific Settings

### Development

```bash
# .env.development
XOE_LOG_LEVEL=DEBUG
XOE_MODEL=small-model-for-testing
XOE_MAX_TOKENS=512
XOE_CACHE_ENABLED=false
```

### Production

```bash
# .env.production
XOE_LOG_LEVEL=WARNING
XOE_MODEL=production-model
XOE_MAX_TOKENS=2048
XOE_SECURITY_AUDITING=true
XOE_ENCRYPTION_ENABLED=true
XOE_RATE_LIMITING=true
```

### Testing

```bash
# .env.test
XOE_MODEL=mock-model
XOE_REDIS_URL=memory://
XOE_LOG_LEVEL=ERROR
XOE_VOICE_ENABLED=false
```

## Configuration Management

### Version Control

```bash
# Track configuration changes
git add config.toml docker-compose.override.yml
git commit -m "Update configuration for production deployment"

# Use different configs per environment
ln -sf config.production.toml config.toml  # Production
ln -sf config.development.toml config.toml  # Development
```

### Backup and Restore

```bash
# Backup configuration
tar czf config-backup-$(date +%Y%m%d).tar.gz config.toml voice_config.json docker-compose.override.yml

# Restore configuration
tar xzf config-backup-20260115.tar.gz
```

## Troubleshooting Configuration

### Common Issues

**Configuration Not Loading**
```bash
# Check file permissions
ls -la config.toml

# Validate TOML syntax
python -c "import tomllib; tomllib.load(open('config.toml', 'rb'))"

# Check environment variables
env | grep XOE_
```

**Invalid Configuration Values**
```bash
# Validate with schema
python -c "from config import settings; print(settings.dict())"

# Check for type errors
python -c "from pydantic import ValidationError; from config import APISettings; APISettings()"
```

**Environment Variable Precedence**
```bash
# Environment variables override config file
XOE_MAX_TOKENS=1024 python app.py  # Overrides config.toml
```

---

**Configuration Reference**: Complete guide to customizing Xoe-NovAi for your environment.
