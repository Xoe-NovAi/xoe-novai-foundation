# Curation_Worker API Reference

**Endpoints**: 1

## `get_job_data(job_id: str)`

**Module**: `curation_worker`
**HTTP Method**: GET
**Route**: /job_data
**Response Model**: dict

---

