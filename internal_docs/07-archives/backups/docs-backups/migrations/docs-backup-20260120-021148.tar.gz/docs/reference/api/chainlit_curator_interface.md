# Chainlit_Curator_Interface API Reference

**Endpoints**: 2

## `get_curator_interface()`

Get or create global curator interface instance.

**Module**: `chainlit_curator_interface`
**HTTP Method**: GET
**Route**: /curator_interface
**Response Model**: ChainlitCuratorInterface

---

## `process_curator_command(message_text: str)`

Process curator command and return formatted response.

Use in Chainlit message handler:

@cl.on_message
async def handle_message(message: cl.Message):
    if "find" in message.content.lower() or "research" in message.content.lower():
        response = await process_curator_command(message.content)
        await cl.Message(response).send()

**Module**: `chainlit_curator_interface`
**Response Model**: str

---

