# Retrievers API Reference

**Endpoints**: 3

## `_compute_bm25_scores(self, query: str, documents: List[Document])`

Compute BM25 scores for documents.

**Module**: `retrievers`
**HTTP Method**: PUT
**Route**: /_compute_bm25_scores
**Response Model**: List[float]

---

## `_compute_semantic_scores(self, query: str, documents: List[Document], top_k: int)`

Compute semantic similarity scores using FAISS.

**Module**: `retrievers`
**HTTP Method**: PUT
**Route**: /_compute_semantic_scores
**Response Model**: Dict[Document, float]

---

## `get_stats(self)`

Get retriever statistics.

**Module**: `retrievers`
**HTTP Method**: GET
**Route**: /stats
**Response Model**: Dict[str, Any]

---

