# Verify_Imports API Reference

**Endpoints**: 1

## `check_import(module_name: str, required_version: str, check_attribute: str)`

Check if a module can be imported and optionally verify version.

Guide Reference: Section 4 (Import Validation)

Args:
    module_name: Module to import (e.g., 'fastapi')
    required_version: Minimum required version (e.g., '0.118.0')
    check_attribute: Optional attribute to verify (e.g., 'version')
    
Returns:
    Tuple (success: bool, message: str)

**Module**: `verify_imports`
**Response Model**: Tuple[bool, str]
**Enterprise Features**: enterprise_monitoring

---

