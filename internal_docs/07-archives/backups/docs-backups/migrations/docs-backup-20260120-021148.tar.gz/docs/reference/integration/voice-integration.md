# Voice Integration Guide

## Available Voice Endpoints

### `get_voice_interface()`



### `get_voice_performance_stats()`

Get voice degradation system performance statistics.

### `get_voice_degradation_templates()`

Get available voice response templates.

### `process_voice_input(audio_data: bytes)`

Process voice input with distil-large-v3-turbo + CTranslate2 for optimal Ryzen performance.

