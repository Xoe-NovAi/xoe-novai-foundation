# Voice_Degradation API Reference

**Endpoints**: 3

## `get_performance_stats(self)`

Get degradation system performance statistics.

**Module**: `voice_degradation`
**HTTP Method**: GET
**Route**: /performance_stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_monitoring

---

## `get_voice_degradation_templates()`

Get available voice response templates.

**Module**: `voice_degradation`
**HTTP Method**: GET
**Route**: /voice_degradation_templates
**Response Model**: Dict[str, str]
**Enterprise Features**: enterprise_monitoring

---

## `get_voice_performance_stats()`

Get voice degradation system performance statistics.

**Module**: `voice_degradation`
**HTTP Method**: GET
**Route**: /voice_performance_stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_monitoring

---

