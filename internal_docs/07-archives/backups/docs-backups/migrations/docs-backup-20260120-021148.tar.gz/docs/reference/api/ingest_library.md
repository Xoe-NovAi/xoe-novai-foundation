# Ingest_Library API Reference

**Endpoints**: 5

## `_enrich_metadata(self, metadata: ContentMetadata)`

Enrich content metadata using library APIs.

Applies domain classification and Dewey Decimal mapping.

**Module**: `ingest_library`
**Response Model**: ContentMetadata
**Enterprise Features**: enterprise_monitoring

---

## `_get_classical_relationships(self, title: str, author: str)`

Get known relationships for classical texts.

**Module**: `ingest_library`
**HTTP Method**: GET
**Route**: /_classical_relationships
**Response Model**: Dict[str, List[str]]
**Dependencies**: author
**Enterprise Features**: enterprise_monitoring

---

## `_rate_limit_api_call(self)`

Apply rate limiting to API calls.

**Module**: `ingest_library`
**Enterprise Features**: enterprise_monitoring

---

## `ingest_from_api(self, api_name: str, query: str, max_items: int)`

Ingest content from library APIs.

Supported APIs: openlibrary, google_books, internet_archive, gutenberg

**Module**: `ingest_library`
**Response Model**: IngestionStats
**Enterprise Features**: enterprise_monitoring

---

## `ingest_library(library_path: Optional[str], batch_size: int, max_items: int, sources: Optional[List[str]], enable_deduplication: bool, enable_quality_filter: bool)`

Main ingestion function - enterprise-grade library content ingestion.

Args:
    library_path: Path to library directory (default: from config)
    batch_size: Processing batch size
    max_items: Maximum items to process
    sources: List of sources to ingest from ['api', 'rss', 'local']
    enable_deduplication: Enable duplicate detection
    enable_quality_filter: Enable quality filtering

Returns:
    Tuple of (total_ingested, processing_time_seconds)

**Module**: `ingest_library`
**Response Model**: Tuple[int, float]
**Enterprise Features**: enterprise_monitoring

---

