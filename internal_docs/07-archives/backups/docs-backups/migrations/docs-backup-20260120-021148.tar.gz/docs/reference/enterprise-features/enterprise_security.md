# Enterprise Security Enterprise Feature

**Implemented in 47 endpoints**

## `test_library_integration()` (library_api_integrations)

Test library API integrations and domain classification....

## `__post_init__(self)` (library_api_integrations)

Load API keys from environment if not provided....

## `_get_cached(self, key: str)` (library_api_integrations)

Get item from cache if valid....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by identifier (ISBN, OCLC, etc)....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by ISBN or other identifier....

## `_get_first(value)` (library_api_integrations)

Get first item if list, otherwise return value....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by identifier....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by LCCN or other identifier....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by Gutenberg ID....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get track by identifier....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by OCLC number....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get resource by Cambridge Digital Library ID....

## `search(self, query: str, **kwargs)` (library_api_integrations)

Search for EPUB books using Internet Archive EPUB endpoint....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get EPUB resource by Internet Archive identifier....

## `get_by_url(self, feed_url: str)` (library_api_integrations)

Get podcast metadata by RSS feed URL....

## `get_episodes(self, feed_url: str, limit: int)` (library_api_integrations)

Get recent episodes from a podcast feed....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get podcast by ID....

## `get_similar_artists(self, artist_name: str, limit: int)` (library_api_integrations)

Get artists similar to the given artist....

## `get_trending_tracks(self, limit: int)` (library_api_integrations)

Get trending tracks on Last.fm....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get music metadata by artist or track name....

## `get_by_identifier(self, identifier: str, id_type: str)` (library_api_integrations)

Get music by ISRC, ISWC, or artist/recording ID....

## `get_dewey_suggestion(self, category: DomainCategory)` (library_api_integrations)

Get suggested Dewey Decimal classifications for a category....

## `get_all_categories(self)` (library_api_integrations)

Get all available domain categories....

## `get_music_recommendations(self, genre: str, limit: int)` (library_api_integrations)

Get music recommendations by genre or trending....

## `_get_intent_classifier(self)` (library_api_integrations)

Get intent classifier (using transformer zero-shot if available)....

## `_get_entity_extractor(self)` (library_api_integrations)

Get entity extractor (using spaCy if available)....

## `_get_command_type(self, intent: str, entities: Dict[str, Any])` (library_api_integrations)

Determine specific command type from intent and entities....

## `_get_recommendations(self, parameters: Dict[str, Any])` (library_api_integrations)

Get book recommendations based on topics/domains....

## `process_user_input(self, user_input: str)` (library_api_integrations)

Complete pipeline: Parse → Validate → Execute.

Args:
    user_input: Natural language curator command from user
    
Returns:
    Dict with results and metadata...

## `get_circuit_breaker_status()` (chainlit_app_voice)

Get status of all circuit breakers for health checks and monitoring....

## `process_voice_input(audio_data: bytes)` (chainlit_app_voice)

Process voice input with distil-large-v3-turbo + CTranslate2 for optimal Ryzen performance....

## `call_rag_api_with_circuit_breaker(user_input: str, context: str, knowledge_context: str)` (chainlit_app_voice)

Call RAG API with circuit breaker protection....

## `generate_ai_response(user_input: str)` (chainlit_app_voice)

Generate AI response using RAG API with conversation context and circuit breaker protection....

## `get_buffered_audio(self)` (chainlit_app_voice)

...

## `validate_safe_input(text: str, max_length: int)` (crawl)

Whitelist validation for curation inputs to prevent command injection.

Args:
    text: Input text to validate
    max_length: Maximum allowed length

Returns:
    True if input is safe, False otherwi...

## `get_session_stats()` (chainlit_app)

Get current session statistics.

Returns:
    Dict with session stats...

## `check_api_health()` (chainlit_app)

Check if RAG API is available.

Returns:
    Tuple of (is_healthy, message)...

## `stream_from_api(query: str, use_rag: bool, max_tokens: int)` (chainlit_app)

Stream response from RAG API via SSE.

Guide Reference: Section 4.2 (API Streaming)

Args:
    query: User query
    use_rag: Whether to use RAG
    max_tokens: Maximum tokens to generate
    
Yields:...

## `query_local_llm(query: str, max_tokens: int)` (chainlit_app)

Fallback to local LLM if API unavailable.

Guide Reference: Section 4.2 (Local Fallback)
Best Practice: Graceful degradation

Args:
    query: User query string
    max_tokens: Maximum tokens to gener...

## `on_message(message: cl.Message)` (chainlit_app)

Handle incoming messages.

Guide Reference: Section 4.2 (Message Handler)

Args:
    message: User message from Chainlit...

## `retrieve_context(query: str, top_k: int, similarity_threshold: float)` (main)

Retrieve relevant documents from FAISS vectorstore.

Guide Reference: Section 2 (RAG Configuration)
Best Practice: Configurable top_k with timing metrics

Args:
    query: User query string
    top_k:...

## `root()` (main)

Root endpoint with API information.

Guide Reference: Section 4.1 (Root Endpoint)...

## `health_check(request: Request)` (main)

Health check endpoint with integrated healthcheck.py results.

Guide Reference: Section 5.1 (Integrated Health Checks)

Returns:
    Health status with component information...

## `query_endpoint(request: Request, query_req: QueryRequest)` (main)

Synchronous query endpoint.

Guide Reference: Section 4.1 (Query Endpoint)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    Query response with sources...

## `stream_endpoint(request: Request, query_req: QueryRequest)` (main)

Streaming query endpoint (SSE).

Guide Reference: Section 4.1 (SSE Streaming)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    StreamingResponse with SSE events...

## `http_exception_handler(request: Request, exc: HTTPException)` (main)

Handle FastAPI HTTP exceptions with standardized format....

## `global_exception_handler(request: Request, exc: Exception)` (main)

Global exception handler for unhandled errors.

Uses unified error framework for consistent responses....

