# Circuit Breaker Enterprise Feature

**Implemented in 25 endpoints**

## `get_voice_interface()` (voice_interface)

...

## `get_metrics(self)` (voice_interface)

...

## `get_stats(self)` (voice_interface)

...

## `_get_key(self, key_type: str)` (voice_interface)

Generate Redis key with namespace....

## `get_conversation_context(self, max_turns: int)` (voice_interface)

Get conversation history for LLM context....

## `get_stats(self)` (voice_interface)

Get session statistics....

## `get_index_stats(self)` (voice_interface)

Get FAISS index statistics....

## `get_audio_data(self)` (voice_interface)

...

## `get_session_stats(self)` (voice_interface)

...

## `get_circuit_breaker_status()` (chainlit_app_voice)

Get status of all circuit breakers for health checks and monitoring....

## `process_voice_input(audio_data: bytes)` (chainlit_app_voice)

Process voice input with distil-large-v3-turbo + CTranslate2 for optimal Ryzen performance....

## `call_rag_api_with_circuit_breaker(user_input: str, context: str, knowledge_context: str)` (chainlit_app_voice)

Call RAG API with circuit breaker protection....

## `generate_ai_response(user_input: str)` (chainlit_app_voice)

Generate AI response using RAG API with conversation context and circuit breaker protection....

## `get_buffered_audio(self)` (chainlit_app_voice)

...

## `retrieve_context(query: str, top_k: int, similarity_threshold: float)` (main)

Retrieve relevant documents from FAISS vectorstore.

Guide Reference: Section 2 (RAG Configuration)
Best Practice: Configurable top_k with timing metrics

Args:
    query: User query string
    top_k:...

## `root()` (main)

Root endpoint with API information.

Guide Reference: Section 4.1 (Root Endpoint)...

## `health_check(request: Request)` (main)

Health check endpoint with integrated healthcheck.py results.

Guide Reference: Section 5.1 (Integrated Health Checks)

Returns:
    Health status with component information...

## `query_endpoint(request: Request, query_req: QueryRequest)` (main)

Synchronous query endpoint.

Guide Reference: Section 4.1 (Query Endpoint)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    Query response with sources...

## `stream_endpoint(request: Request, query_req: QueryRequest)` (main)

Streaming query endpoint (SSE).

Guide Reference: Section 4.1 (SSE Streaming)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    StreamingResponse with SSE events...

## `http_exception_handler(request: Request, exc: HTTPException)` (main)

Handle FastAPI HTTP exceptions with standardized format....

## `global_exception_handler(request: Request, exc: Exception)` (main)

Global exception handler for unhandled errors.

Uses unified error framework for consistent responses....

## `trace_llm_call(self, model: str, prompt: str, response: str, tokens_used: int, **kwargs)` (observability)

Trace LLM API calls with GenAI semantic conventions....

## `instrument_fastapi_app(self, app)` (observability)

Instrument FastAPI application with OpenTelemetry....

## `get_tracer(self)` (observability)

Get the GenAI tracer....

## `get_metrics(self)` (observability)

Get the GenAI metrics collector....

