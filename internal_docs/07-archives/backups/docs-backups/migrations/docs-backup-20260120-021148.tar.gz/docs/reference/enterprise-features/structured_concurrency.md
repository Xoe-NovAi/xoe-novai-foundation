# Structured Concurrency Enterprise Feature

**Implemented in 1 endpoints**

## `_get_initial_context(self, query: str)` (async_patterns)

Get initial context for query....

