# Crawl API Reference

**Endpoints**: 1

## `validate_safe_input(text: str, max_length: int)`

Whitelist validation for curation inputs to prevent command injection.

Args:
    text: Input text to validate
    max_length: Maximum allowed length

Returns:
    True if input is safe, False otherwise

**Module**: `crawl`
**HTTP Method**: PUT
**Route**: /validate_safe_input
**Response Model**: bool
**Enterprise Features**: enterprise_security

---

