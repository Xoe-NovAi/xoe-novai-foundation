# Config_Loader API Reference

**Endpoints**: 2

## `get_config_summary()`

Return a compact summary of important config values for diagnostics.

Guide Reference: Section 3.2 (Config Summary)

Returns:
    Dict with key metrics and settings

Example:
    >>> summary = get_config_summary()
    >>> print(summary['version'])
    v0.1.4-stable

**Module**: `config_loader`
**HTTP Method**: GET
**Route**: /config_summary
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_monitoring, zero_telemetry

---

## `get_config_value(key_path: str, default: Any)`

Get nested config value by dot-notation path.

Guide Reference: Section 3.2 (Nested Config Access)

This provides convenient access to deeply nested config values
without multiple dict lookups.

Args:
    key_path: Dot-separated path (e.g., "redis.cache.ttl_seconds")
    default: Default value if key not found

Returns:
    Config value or default

Example:
    >>> ttl = get_config_value("redis.cache.ttl_seconds")
    >>> print(ttl)
    3600
    
    >>> missing = get_config_value("nonexistent.key", default="N/A")
    >>> print(missing)
    N/A

**Module**: `config_loader`
**HTTP Method**: GET
**Route**: /config_value
**Response Model**: Any
**Enterprise Features**: enterprise_monitoring, zero_telemetry

---

