# Observability API Reference

**Endpoints**: 4

## `get_metrics(self)`

Get the GenAI metrics collector.

**Module**: `observability`
**HTTP Method**: GET
**Route**: /metrics
**Enterprise Features**: circuit_breaker, enterprise_monitoring, zero_telemetry

---

## `get_tracer(self)`

Get the GenAI tracer.

**Module**: `observability`
**HTTP Method**: GET
**Route**: /tracer
**Enterprise Features**: circuit_breaker, enterprise_monitoring, zero_telemetry

---

## `instrument_fastapi_app(self, app)`

Instrument FastAPI application with OpenTelemetry.

**Module**: `observability`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, zero_telemetry

---

## `trace_llm_call(self, model: str, prompt: str, response: str, tokens_used: int, **kwargs)`

Trace LLM API calls with GenAI semantic conventions.

**Module**: `observability`
**Dependencies**: tokens_used
**Enterprise Features**: circuit_breaker, enterprise_monitoring, zero_telemetry

---

