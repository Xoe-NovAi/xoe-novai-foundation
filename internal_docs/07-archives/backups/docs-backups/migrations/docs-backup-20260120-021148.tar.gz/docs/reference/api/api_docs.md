# Api_Docs API Reference

**Endpoints**: 7

## `create_mkdocs_api_config()`

Create MkDocs configuration for API documentation.

Returns:
    MkDocs plugin configuration for API docs

**Module**: `api_docs`
**Response Model**: Dict[str, Any]

---

## `extract_api_documentation(self)`

Extract comprehensive API documentation from loaded modules.

Returns:
    List of APIDocumentation objects

**Module**: `api_docs`
**Response Model**: List[APIDocumentation]

---

## `generate_api_documentation(source_paths: List[str])`

Generate API documentation for RAG indexing.

Args:
    source_paths: List of paths to scan for Python modules

Returns:
    List of Document objects for vectorstore indexing

**Module**: `api_docs`
**Response Model**: List[Document]

---

## `get_api_documentation_stats()`

Get API documentation generation statistics.

**Module**: `api_docs`
**HTTP Method**: GET
**Route**: /api_documentation_stats
**Response Model**: Dict[str, Any]

---

## `get_stats(self)`

Get API documentation generation statistics.

**Module**: `api_docs`
**HTTP Method**: GET
**Route**: /stats
**Response Model**: Dict[str, Any]

---

## `save_to_json(self, filepath: str)`

Save API documentation to JSON file.

**Module**: `api_docs`

---

## `search_api_documentation(query: str, api_docs: List[APIDocumentation])`

Search API documentation for relevant items.

Args:
    query: Search query
    api_docs: List of API documentation items

Returns:
    Filtered list of relevant API documentation

**Module**: `api_docs`
**Response Model**: List[APIDocumentation]

---

