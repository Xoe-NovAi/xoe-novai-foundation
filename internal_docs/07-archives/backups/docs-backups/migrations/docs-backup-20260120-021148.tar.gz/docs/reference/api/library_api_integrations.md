# Library_Api_Integrations API Reference

**Endpoints**: 29

## `__post_init__(self)`

Load API keys from environment if not provided.

**Module**: `library_api_integrations`
**HTTP Method**: POST
**Route**: /__init__
**Enterprise Features**: enterprise_security

---

## `_get_cached(self, key: str)`

Get item from cache if valid.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_cached
**Response Model**: Optional[Any]
**Enterprise Features**: enterprise_security

---

## `_get_command_type(self, intent: str, entities: Dict[str, Any])`

Determine specific command type from intent and entities.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_command_type
**Response Model**: str
**Enterprise Features**: enterprise_security

---

## `_get_entity_extractor(self)`

Get entity extractor (using spaCy if available).

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_entity_extractor
**Enterprise Features**: enterprise_security

---

## `_get_first(value)`

Get first item if list, otherwise return value.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_first
**Enterprise Features**: enterprise_security

---

## `_get_intent_classifier(self)`

Get intent classifier (using transformer zero-shot if available).

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_intent_classifier
**Enterprise Features**: enterprise_security

---

## `_get_recommendations(self, parameters: Dict[str, Any])`

Get book recommendations based on topics/domains.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /_recommendations
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_security

---

## `get_all_categories(self)`

Get all available domain categories.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /all_categories
**Response Model**: List[str]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by identifier (ISBN, OCLC, etc).

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by ISBN or other identifier.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by identifier.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by LCCN or other identifier.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by Gutenberg ID.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get track by identifier.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by OCLC number.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get resource by Cambridge Digital Library ID.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get EPUB resource by Internet Archive identifier.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get podcast by ID.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get music metadata by artist or track name.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_by_identifier(self, identifier: str, id_type: str)`

Get music by ISRC, ISWC, or artist/recording ID.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_identifier
**Response Model**: Optional[List[LibraryMetadata]]
**Enterprise Features**: enterprise_security

---

## `get_by_url(self, feed_url: str)`

Get podcast metadata by RSS feed URL.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /by_url
**Response Model**: Optional[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_dewey_suggestion(self, category: DomainCategory)`

Get suggested Dewey Decimal classifications for a category.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /dewey_suggestion
**Response Model**: List[str]
**Enterprise Features**: enterprise_security

---

## `get_episodes(self, feed_url: str, limit: int)`

Get recent episodes from a podcast feed.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /episodes
**Response Model**: List[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_music_recommendations(self, genre: str, limit: int)`

Get music recommendations by genre or trending.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /music_recommendations
**Response Model**: List[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_similar_artists(self, artist_name: str, limit: int)`

Get artists similar to the given artist.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /similar_artists
**Response Model**: List[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `get_trending_tracks(self, limit: int)`

Get trending tracks on Last.fm.

**Module**: `library_api_integrations`
**HTTP Method**: GET
**Route**: /trending_tracks
**Response Model**: List[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `process_user_input(self, user_input: str)`

Complete pipeline: Parse → Validate → Execute.

Args:
    user_input: Natural language curator command from user
    
Returns:
    Dict with results and metadata

**Module**: `library_api_integrations`
**HTTP Method**: PUT
**Route**: /process_user_input
**Response Model**: Dict[str, Any]
**Dependencies**: user_input
**Enterprise Features**: enterprise_security

---

## `search(self, query: str, **kwargs)`

Search for EPUB books using Internet Archive EPUB endpoint.

**Module**: `library_api_integrations`
**Response Model**: List[LibraryMetadata]
**Enterprise Features**: enterprise_security

---

## `test_library_integration()`

Test library API integrations and domain classification.

**Module**: `library_api_integrations`
**Enterprise Features**: enterprise_security

---

