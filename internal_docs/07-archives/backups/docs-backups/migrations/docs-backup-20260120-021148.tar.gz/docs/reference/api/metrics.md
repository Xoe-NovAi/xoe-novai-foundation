# Metrics API Reference

**Endpoints**: 3

## `check_performance_targets()`

Check if current metrics meet performance targets.

Guide Reference: Section 5.2 (Performance Validation)

Returns:
    Dict with validation results
    
Example:
    >>> results = check_performance_targets()
    >>> print(results['memory']['status'])
    'OK'

**Module**: `metrics`
**HTTP Method**: GET
**Route**: /check_performance_targets
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_monitoring

---

## `record_error(error_type: str, component: str)`

Record an error.

Args:
    error_type: Type of error (e.g., 'timeout', 'validation', 'llm')
    component: Component where error occurred (e.g., 'api', 'rag', 'llm')
    
Example:
    >>> record_error('timeout', 'llm')

**Module**: `metrics`
**Enterprise Features**: enterprise_monitoring

---

## `record_request(endpoint: str, method: str, status: int)`

Record an API request.

Guide Reference: Section 5.2 (Request Recording)

Args:
    endpoint: Endpoint path (e.g., '/query')
    method: HTTP method (e.g., 'POST')
    status: HTTP status code (e.g., 200)
    
Example:
    >>> record_request('/query', 'POST', 200)

**Module**: `metrics`
**Enterprise Features**: enterprise_monitoring

---

