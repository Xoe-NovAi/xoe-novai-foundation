# Chainlit_App API Reference

**Endpoints**: 5

## `check_api_health()`

Check if RAG API is available.

Returns:
    Tuple of (is_healthy, message)

**Module**: `chainlit_app`
**Response Model**: tuple
**Enterprise Features**: enterprise_monitoring, enterprise_security, zero_telemetry

---

## `get_session_stats()`

Get current session statistics.

Returns:
    Dict with session stats

**Module**: `chainlit_app`
**HTTP Method**: GET
**Route**: /session_stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: enterprise_monitoring, enterprise_security, zero_telemetry

---

## `on_message(message: cl.Message)`

Handle incoming messages.

Guide Reference: Section 4.2 (Message Handler)

Args:
    message: User message from Chainlit

**Module**: `chainlit_app`
**Enterprise Features**: enterprise_monitoring, enterprise_security, zero_telemetry

---

## `query_local_llm(query: str, max_tokens: int)`

Fallback to local LLM if API unavailable.

Guide Reference: Section 4.2 (Local Fallback)
Best Practice: Graceful degradation

Args:
    query: User query string
    max_tokens: Maximum tokens to generate
    
Returns:
    Generated response or None if failed

**Module**: `chainlit_app`
**Response Model**: Optional[str]
**Dependencies**: max_tokens
**Enterprise Features**: enterprise_monitoring, enterprise_security, zero_telemetry

---

## `stream_from_api(query: str, use_rag: bool, max_tokens: int)`

Stream response from RAG API via SSE.

Guide Reference: Section 4.2 (API Streaming)

Args:
    query: User query
    use_rag: Whether to use RAG
    max_tokens: Maximum tokens to generate
    
Yields:
    Tuple of (event_type, content, metadata)

**Module**: `chainlit_app`
**Dependencies**: max_tokens
**Enterprise Features**: enterprise_monitoring, enterprise_security, zero_telemetry

---

