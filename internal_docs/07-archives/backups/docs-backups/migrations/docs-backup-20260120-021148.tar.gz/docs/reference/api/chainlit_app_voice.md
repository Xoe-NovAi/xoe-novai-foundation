# Chainlit_App_Voice API Reference

**Endpoints**: 5

## `call_rag_api_with_circuit_breaker(user_input: str, context: str, knowledge_context: str)`

Call RAG API with circuit breaker protection.

**Module**: `chainlit_app_voice`
**Response Model**: Dict[str, Any]
**Dependencies**: user_input
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `generate_ai_response(user_input: str)`

Generate AI response using RAG API with conversation context and circuit breaker protection.

**Module**: `chainlit_app_voice`
**Response Model**: str
**Dependencies**: user_input
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `get_buffered_audio(self)`

**Module**: `chainlit_app_voice`
**HTTP Method**: GET
**Route**: /buffered_audio
**Response Model**: bytes
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `get_circuit_breaker_status()`

Get status of all circuit breakers for health checks and monitoring.

**Module**: `chainlit_app_voice`
**HTTP Method**: GET
**Route**: /circuit_breaker_status
**Response Model**: Dict[str, Any]
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `process_voice_input(audio_data: bytes)`

Process voice input with distil-large-v3-turbo + CTranslate2 for optimal Ryzen performance.

**Module**: `chainlit_app_voice`
**HTTP Method**: PUT
**Route**: /process_voice_input
**Response Model**: Optional[str]
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

