# Logging_Config API Reference

**Endpoints**: 3

## `get_logger(name: str, context: Dict[str, Any])`

Get configured logger with optional context.

**Module**: `logging_config`
**HTTP Method**: GET
**Route**: /logger
**Response Model**: logging.Logger
**Enterprise Features**: enterprise_monitoring

---

## `setup_console_handler(level: int, use_json: bool)`

Create console handler.

**Module**: `logging_config`
**Response Model**: logging.StreamHandler
**Enterprise Features**: enterprise_monitoring

---

## `setup_file_handler(log_file: str, max_bytes: int, backup_count: int, level: int)`

Create rotating file handler.

CRITICAL: This MUST handle the case where the directory doesn't exist
(created at build time) but we still need to verify it's writable.

**Module**: `logging_config`
**Response Model**: RotatingFileHandler
**Enterprise Features**: enterprise_monitoring

---

