# Healthcheck API Reference

**Endpoints**: 1

## `_get_cached_result(check_name: str)`

Get cached health check result if still valid.

**Module**: `healthcheck`
**HTTP Method**: GET
**Route**: /_cached_result
**Response Model**: Optional[Tuple[bool, str]]
**Enterprise Features**: enterprise_monitoring

---

