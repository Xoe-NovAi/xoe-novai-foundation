# Crawler_Curation API Reference

**Endpoints**: 2

## `enrich_with_library_metadata(document: CrawledDocument, title: str, author: Optional[str])`

Enrich crawled document with library metadata from multiple APIs.

This function automatically:
1. Classifies content into domain categories
2. Searches library APIs for enrichment
3. Maps to Dewey Decimal classifications
4. Updates document metadata

Args:
    document: The crawled document to enrich
    title: Document title for library search
    author: Optional author name

Returns:
    Updated document with library metadata

Example:
    >>> doc = CrawledDocument(...)
    >>> enriched = enrich_with_library_metadata(doc, "Python Programming", "Guido van Rossum")

**Module**: `crawler_curation`
**Response Model**: CrawledDocument
**Dependencies**: author

---

## `get_domain_categories()`

Get list of available domain categories.

**Module**: `crawler_curation`
**HTTP Method**: GET
**Route**: /domain_categories
**Response Model**: List[str]

---

