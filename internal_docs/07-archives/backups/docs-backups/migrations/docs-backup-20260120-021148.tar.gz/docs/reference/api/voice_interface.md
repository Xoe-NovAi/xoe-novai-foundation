# Voice_Interface API Reference

**Endpoints**: 9

## `_get_key(self, key_type: str)`

Generate Redis key with namespace.

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /_key
**Response Model**: str
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_audio_data(self)`

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /audio_data
**Response Model**: bytes
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_conversation_context(self, max_turns: int)`

Get conversation history for LLM context.

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /conversation_context
**Response Model**: str
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_index_stats(self)`

Get FAISS index statistics.

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /index_stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_metrics(self)`

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /metrics
**Response Model**: bytes
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_session_stats(self)`

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /session_stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_stats(self)`

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_stats(self)`

Get session statistics.

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /stats
**Response Model**: Dict[str, Any]
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

## `get_voice_interface()`

**Module**: `voice_interface`
**HTTP Method**: GET
**Route**: /voice_interface
**Response Model**: Optional[VoiceInterface]
**Enterprise Features**: circuit_breaker, enterprise_monitoring

---

