# Main API Reference

**Endpoints**: 7

## `global_exception_handler(request: Request, exc: Exception)`

Global exception handler for unhandled errors.

Uses unified error framework for consistent responses.

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `health_check(request: Request)`

Health check endpoint with integrated healthcheck.py results.

Guide Reference: Section 5.1 (Integrated Health Checks)

Returns:
    Health status with component information

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `http_exception_handler(request: Request, exc: HTTPException)`

Handle FastAPI HTTP exceptions with standardized format.

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `query_endpoint(request: Request, query_req: QueryRequest)`

Synchronous query endpoint.

Guide Reference: Section 4.1 (Query Endpoint)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    Query response with sources

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `retrieve_context(query: str, top_k: int, similarity_threshold: float)`

Retrieve relevant documents from FAISS vectorstore.

Guide Reference: Section 2 (RAG Configuration)
Best Practice: Configurable top_k with timing metrics

Args:
    query: User query string
    top_k: Number of documents to retrieve
    similarity_threshold: Minimum similarity score (unused in FAISS but kept for API)
    
Returns:
    Tuple of (context_str, sources_list)

**Module**: `main`
**Response Model**: tuple
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `root()`

Root endpoint with API information.

Guide Reference: Section 4.1 (Root Endpoint)

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

## `stream_endpoint(request: Request, query_req: QueryRequest)`

Streaming query endpoint (SSE).

Guide Reference: Section 4.1 (SSE Streaming)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    StreamingResponse with SSE events

**Module**: `main`
**Enterprise Features**: circuit_breaker, enterprise_monitoring, enterprise_security

---

