# Async_Patterns API Reference

**Endpoints**: 1

## `_get_initial_context(self, query: str)`

Get initial context for query.

**Module**: `async_patterns`
**HTTP Method**: GET
**Route**: /_initial_context
**Response Model**: Dict[str, Any]
**Enterprise Features**: structured_concurrency

---

