# Voice_Command_Handler API Reference

**Endpoints**: 5

## `__init__(self, faiss_index: Optional[Any], embeddings_model: Optional[Any], confirmation_required: bool)`

Initialize command handler

Args:
    faiss_index: FAISS index instance
    embeddings_model: Embeddings model for encoding
    confirmation_required: Require confirmation for modify operations

**Module**: `voice_command_handler`

---

## `__init__(self, handler: VoiceCommandHandler, tts_callback: Optional[Callable])`

Initialize orchestrator

Args:
    handler: VoiceCommandHandler instance
    tts_callback: Function to call for text-to-speech responses

**Module**: `voice_command_handler`

---

## `get_command_history(self, limit: int)`

Get recent command parsing history

**Module**: `voice_command_handler`
**HTTP Method**: GET
**Route**: /command_history
**Response Model**: List[ParsedVoiceCommand]

---

## `get_execution_log(self, limit: int)`

Get command execution history

**Module**: `voice_command_handler`
**HTTP Method**: GET
**Route**: /execution_log
**Response Model**: List[Dict[str, Any]]

---

## `handle_delete(self, command: ParsedVoiceCommand)`

Handle DELETE command - remove from FAISS

**Module**: `voice_command_handler`
**HTTP Method**: DELETE
**Route**: /handle_delete
**Response Model**: Dict[str, Any]

---

