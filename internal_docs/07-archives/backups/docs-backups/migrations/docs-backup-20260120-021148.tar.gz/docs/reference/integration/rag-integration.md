# RAG Integration Guide

## Search and Retrieval Endpoints

### `search(self, query: str, **kwargs)`

Search for EPUB books using Internet Archive EPUB endpoint.

### `call_rag_api_with_circuit_breaker(user_input: str, context: str, knowledge_context: str)`

Call RAG API with circuit breaker protection.

### `search_api_documentation(query: str, api_docs: List[APIDocumentation])`

Search API documentation for relevant items.

Args:
    query: Search query
    api_docs: List of API documentation items

Returns:
    Filtered list of relevant API documentation

