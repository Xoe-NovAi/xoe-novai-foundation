# Enterprise Monitoring Enterprise Feature

**Implemented in 58 endpoints**

## `get_voice_interface()` (voice_interface)

...

## `get_metrics(self)` (voice_interface)

...

## `get_stats(self)` (voice_interface)

...

## `_get_key(self, key_type: str)` (voice_interface)

Generate Redis key with namespace....

## `get_conversation_context(self, max_turns: int)` (voice_interface)

Get conversation history for LLM context....

## `get_stats(self)` (voice_interface)

Get session statistics....

## `get_index_stats(self)` (voice_interface)

Get FAISS index statistics....

## `get_audio_data(self)` (voice_interface)

...

## `get_session_stats(self)` (voice_interface)

...

## `get_voice_performance_stats()` (voice_degradation)

Get voice degradation system performance statistics....

## `get_voice_degradation_templates()` (voice_degradation)

Get available voice response templates....

## `get_performance_stats(self)` (voice_degradation)

Get degradation system performance statistics....

## `get_circuit_breaker_status()` (chainlit_app_voice)

Get status of all circuit breakers for health checks and monitoring....

## `process_voice_input(audio_data: bytes)` (chainlit_app_voice)

Process voice input with distil-large-v3-turbo + CTranslate2 for optimal Ryzen performance....

## `call_rag_api_with_circuit_breaker(user_input: str, context: str, knowledge_context: str)` (chainlit_app_voice)

Call RAG API with circuit breaker protection....

## `generate_ai_response(user_input: str)` (chainlit_app_voice)

Generate AI response using RAG API with conversation context and circuit breaker protection....

## `get_buffered_audio(self)` (chainlit_app_voice)

...

## `setup_file_handler(log_file: str, max_bytes: int, backup_count: int, level: int)` (logging_config)

Create rotating file handler.

CRITICAL: This MUST handle the case where the directory doesn't exist
(created at build time) but we still need to verify it's writable....

## `setup_console_handler(level: int, use_json: bool)` (logging_config)

Create console handler....

## `get_logger(name: str, context: Dict[str, Any])` (logging_config)

Get configured logger with optional context....

## `check_import(module_name: str, required_version: str, check_attribute: str)` (verify_imports)

Check if a module can be imported and optionally verify version.

Guide Reference: Section 4 (Import Validation)

Args:
    module_name: Module to import (e.g., 'fastapi')
    required_version: Minimu...

## `ingest_library(library_path: Optional[str], batch_size: int, max_items: int, sources: Optional[List[str]], enable_deduplication: bool, enable_quality_filter: bool)` (ingest_library)

Main ingestion function - enterprise-grade library content ingestion.

Args:
    library_path: Path to library directory (default: from config)
    batch_size: Processing batch size
    max_items: Max...

## `_get_classical_relationships(self, title: str, author: str)` (ingest_library)

Get known relationships for classical texts....

## `_rate_limit_api_call(self)` (ingest_library)

Apply rate limiting to API calls....

## `_enrich_metadata(self, metadata: ContentMetadata)` (ingest_library)

Enrich content metadata using library APIs.

Applies domain classification and Dewey Decimal mapping....

## `ingest_from_api(self, api_name: str, query: str, max_items: int)` (ingest_library)

Ingest content from library APIs.

Supported APIs: openlibrary, google_books, internet_archive, gutenberg...

## `get_session_stats()` (chainlit_app)

Get current session statistics.

Returns:
    Dict with session stats...

## `check_api_health()` (chainlit_app)

Check if RAG API is available.

Returns:
    Tuple of (is_healthy, message)...

## `stream_from_api(query: str, use_rag: bool, max_tokens: int)` (chainlit_app)

Stream response from RAG API via SSE.

Guide Reference: Section 4.2 (API Streaming)

Args:
    query: User query
    use_rag: Whether to use RAG
    max_tokens: Maximum tokens to generate
    
Yields:...

## `query_local_llm(query: str, max_tokens: int)` (chainlit_app)

Fallback to local LLM if API unavailable.

Guide Reference: Section 4.2 (Local Fallback)
Best Practice: Graceful degradation

Args:
    query: User query string
    max_tokens: Maximum tokens to gener...

## `on_message(message: cl.Message)` (chainlit_app)

Handle incoming messages.

Guide Reference: Section 4.2 (Message Handler)

Args:
    message: User message from Chainlit...

## `get_redis_client()` (dependencies)

Get Redis client (singleton pattern).

Guide Reference: Section 4.1 (Redis Client)

Returns:
    Redis client instance...

## `get_redis_client_async()` (dependencies)

Get async Redis client (requires redis[asyncio]).

Returns:
    Async Redis client...

## `get_http_client()` (dependencies)

Get shared HTTP client (singleton pattern).

Returns:
    Async HTTP client...

## `get_llm(model_path: Optional[str], **kwargs)` (dependencies)

Initialize LlamaCpp LLM with Ryzen optimization.

Guide Reference: Section 4.2.1 (LLM Configuration)

Critical optimizations:
- f16_kv=true: Halves KV cache memory (~1GB savings)
- n_threads=6: Optima...

## `get_llm_async(model_path: Optional[str], **kwargs)` (dependencies)

Async wrapper for LLM initialization.

Args:
    model_path: Path to model
    **kwargs: Additional parameters
    
Returns:
    Initialized LLM...

## `get_embeddings(model_path: Optional[str], **kwargs)` (dependencies)

Initialize LlamaCppEmbeddings model.

Guide Reference: Section 4.2.2 (Embeddings - 50% memory savings)

LlamaCppEmbeddings advantages:
- 50% memory savings vs HuggingFaceEmbeddings
- No PyTorch depend...

## `get_embeddings_async(model_path: Optional[str], **kwargs)` (dependencies)

Async wrapper for embeddings initialization.

Args:
    model_path: Path to model
    **kwargs: Additional parameters
    
Returns:
    Initialized embeddings...

## `get_vectorstore(embeddings: Optional[LlamaCppEmbeddings], index_path: Optional[str], backup_path: Optional[str])` (dependencies)

Load FAISS vectorstore with backup fallback.

Guide Reference: Section 4.2.3 (FAISS Backup Strategy)

Loading strategy:
1. Try primary index at /app/XNAi_rag_app/faiss_index
2. If primary fails, try b...

## `get_vectorstore_async(embeddings: Optional[LlamaCppEmbeddings], index_path: Optional[str], backup_path: Optional[str])` (dependencies)

Async wrapper for vectorstore initialization.

Args:
    embeddings: Embeddings instance
    index_path: Primary index path
    backup_path: Backup directory
    
Returns:
    Loaded vectorstore or No...

## `get_curator(cache_dir: Optional[str], **kwargs)` (dependencies)

Initialize CrawlModule for library curation.

Guide Reference: Section 4.3 (CrawlModule Integration)
Guide Reference: Section 9.2 (CrawlModule Architecture)

NEW in v0.1.4: Provides access to CrawlMod...

## `record_request(endpoint: str, method: str, status: int)` (metrics)

Record an API request.

Guide Reference: Section 5.2 (Request Recording)

Args:
    endpoint: Endpoint path (e.g., '/query')
    method: HTTP method (e.g., 'POST')
    status: HTTP status code (e.g., ...

## `record_error(error_type: str, component: str)` (metrics)

Record an error.

Args:
    error_type: Type of error (e.g., 'timeout', 'validation', 'llm')
    component: Component where error occurred (e.g., 'api', 'rag', 'llm')
    
Example:
    >>> record_erro...

## `check_performance_targets()` (metrics)

Check if current metrics meet performance targets.

Guide Reference: Section 5.2 (Performance Validation)

Returns:
    Dict with validation results
    
Example:
    >>> results = check_performance_t...

## `_get_cached_result(check_name: str)` (healthcheck)

Get cached health check result if still valid....

## `retrieve_context(query: str, top_k: int, similarity_threshold: float)` (main)

Retrieve relevant documents from FAISS vectorstore.

Guide Reference: Section 2 (RAG Configuration)
Best Practice: Configurable top_k with timing metrics

Args:
    query: User query string
    top_k:...

## `root()` (main)

Root endpoint with API information.

Guide Reference: Section 4.1 (Root Endpoint)...

## `health_check(request: Request)` (main)

Health check endpoint with integrated healthcheck.py results.

Guide Reference: Section 5.1 (Integrated Health Checks)

Returns:
    Health status with component information...

## `query_endpoint(request: Request, query_req: QueryRequest)` (main)

Synchronous query endpoint.

Guide Reference: Section 4.1 (Query Endpoint)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    Query response with sources...

## `stream_endpoint(request: Request, query_req: QueryRequest)` (main)

Streaming query endpoint (SSE).

Guide Reference: Section 4.1 (SSE Streaming)

Args:
    request: FastAPI request
    query_req: Query request model
    
Returns:
    StreamingResponse with SSE events...

## `http_exception_handler(request: Request, exc: HTTPException)` (main)

Handle FastAPI HTTP exceptions with standardized format....

## `global_exception_handler(request: Request, exc: Exception)` (main)

Global exception handler for unhandled errors.

Uses unified error framework for consistent responses....

## `get_config_value(key_path: str, default: Any)` (config_loader)

Get nested config value by dot-notation path.

Guide Reference: Section 3.2 (Nested Config Access)

This provides convenient access to deeply nested config values
without multiple dict lookups.

Args:...

## `get_config_summary()` (config_loader)

Return a compact summary of important config values for diagnostics.

Guide Reference: Section 3.2 (Config Summary)

Returns:
    Dict with key metrics and settings

Example:
    >>> summary = get_con...

## `trace_llm_call(self, model: str, prompt: str, response: str, tokens_used: int, **kwargs)` (observability)

Trace LLM API calls with GenAI semantic conventions....

## `instrument_fastapi_app(self, app)` (observability)

Instrument FastAPI application with OpenTelemetry....

## `get_tracer(self)` (observability)

Get the GenAI tracer....

## `get_metrics(self)` (observability)

Get the GenAI metrics collector....

