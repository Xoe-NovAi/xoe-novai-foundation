# Meta: Grok Account: Xoe.Nova.Ai; Project: Xoe-NovAi; Chat Session: Vulkan Best Practices v0.1.5-stable; Timestamp: January 10, 2026, 13:15:00 AST

## Best Practices & Proven Vulkan Integration Methods for Xoe-NovAi

### Executive Summary
Vulkan backend in **llama.cpp** (via llama-cpp-python 0.3.16+) provides cross-platform GPU acceleration, ideal for AMD Ryzen 7 5700U's Vega 8 iGPU (shared ~2GB VRAM max). Proven gains: 20-30% tok/s uplift vs CPU for partial offload on similar APUs (e.g., Rembrandt/RDNA2 benchmarks show 1.5-2x for 7-13B models). Full offload limited by shared memory; partial (20-30 layers) recommended.

**Current Hooks** (from snapshot): Dockerfile.api supports CMAKE_ARGS; dependencies.py loads Llama neutrally. Phase 2 prep strong—enable via env without code rewrite.

**Maturity** (Jan 2026): Stable on Linux RADV (Mesa); no major regressions. Best for iGPU (no ROCm on Vega). Risks: Idle GPU usage (~100% post-inference on some drivers), device detection in Docker.

**Recommendations**: Conditional enable (env toggle), iGPU passthrough in compose, partial offload default. Aligns with Ryzen opts (N_THREADS=6 fallback), sovereignty (no external deps beyond host Vulkan).

**Pros/Cons Table**:
| Aspect               | Pros                                  | Cons                                                  |
| -------------------- | ------------------------------------- | ----------------------------------------------------- |
| **Performance**      | 20-30% gain; low-latency matrix ops   | Modest on Vega (shared mem bottleneck); no flash attn |
| **Compatibility**    | Excellent AMD iGPU via RADV           | Driver-dependent; multi-GPU finicky                   |
| **Integration Ease** | Build-time flag; runtime n_gpu_layers | Docker needs /dev/dri passthrough                     |
| **Stability**        | Mature (2025+ fixes); CPU fallback    | Potential idle leaks; OOM on full offload             |

### 1. Best Practices
| Practice               | Why (Ryzen 5700U Focus)                                    | Validation/Command                                           |
| ---------------------- | ---------------------------------------------------------- | ------------------------------------------------------------ |
| **Driver Setup**       | Use Mesa RADV (open-source Vulkan) for best perf/stability | Host: `sudo apt install mesa-vulkan-drivers`; `vulkaninfo \| grep deviceName` (expect Vega 8) |
| **Build with Vulkan**  | Compile-time enable; offline-compatible                    | CMAKE_ARGS="-DGGML_VULKAN=ON" (current flag)                 |
| **Docker iGPU Access** | Passthrough /dev/dri for Vulkan detection                  | Add devices in compose (no --gpus needed)                    |
| **Partial Offload**    | Avoid OOM; balance shared VRAM (~2GB max)                  | n_gpu_layers=20-30 for 4B models                             |
| **Device Selection**   | Force iGPU if dGPU present                                 | Env: GGML_VK_VISIBLE_DEVICES=0                               |
| **Idle Mitigation**    | Prevent 100% usage post-inference                          | Explicit del llm; gc.collect() in cleanup                    |
| **Fallback**           | Graceful CPU if Vulkan unavailable                         | Check logs for "Vulkan0" device; else CPU                    |
| **Monitoring**         | Track VRAM/util in Prometheus                              | Extend metrics.py: Add gpu_util query                        |

### 2. Proven Integration Methods & Code Snippets

#### 2.1 Build-Time (Dockerfile.api Update)
Multi-stage remains offline-friendly. Conditional via ARG.

```dockerfile
# Dockerfile.api (add/modify)
ARG CMAKE_ARGS=""  # Default empty (CPU-only)
ENV CMAKE_ARGS=${CMAKE_ARGS}

# In wheelhouse/pip stage:
RUN export CMAKE_ARGS="${CMAKE_ARGS} -DGGML_VULKAN=ON" && \
    pip install --no-cache-dir llama-cpp-python==0.3.16
```

**Build Command** (Makefile target):
```makefile
vulkan-build:
    docker-compose build --build-arg CMAKE_ARGS="-DGGML_VULKAN=ON" api
```

#### 2.2 Runtime Config (.env Example)
```env
# .env (Phase 2 Vulkan)
VULKAN_ENABLED=true
N_GPU_LAYERS=30  # Partial; adjust post-benchmark (20-40 safe for 4B Q5)
GGML_VK_VISIBLE_DEVICES=0  # Force iGPU (index from vulkaninfo)
```

#### 2.3 dependencies.py Update (Conditional Offload)
```python
# app/XNAi_rag_app/dependencies.py (modify get_llm)
import os
import gc

@retry(...)  # Pattern 2
def get_llm():
    from llama_cpp import Llama
    
    vulkan_enabled = os.getenv('VULKAN_ENABLED', 'false').lower() == 'true'
    n_gpu_layers = int(os.getenv('N_GPU_LAYERS', '0' if not vulkan_enabled else '30'))
    
    llm = Llama(
        model_path="/models/gemma-3-4b-it-UD-Q5_K_XL.gguf",
        n_threads=6 if n_gpu_layers == 0 else 4,  # Reduce threads if offloading
        n_gpu_layers=n_gpu_layers,  # Key param
        f16_kv=True,
        use_mlock=True,
        verbose=False
    )
    
    logger.info(f"Vulkan offload: {n_gpu_layers} layers ({'enabled' if vulkan_enabled else 'disabled'})")
    return llm

# Optional cleanup hook (post-query)
def cleanup_llm(llm):
    del llm
    gc.collect()
    logger.info("Vulkan resources released")
```

#### 2.4 docker-compose.yml (iGPU Passthrough)
```yaml
# docker-compose.yml (api service)
services:
  rag:
    build: 
      context: .
      dockerfile: Dockerfile.api
      args:
        CMAKE_ARGS: "-DGGML_VULKAN=ON"  # Optional: hardcode or via .env
    devices:
      - /dev/dri:/dev/dri  # Essential for Vulkan iGPU
    # ... existing config
```

#### 2.5 Validation & Benchmark
```bash
# Host preflight
vulkaninfo | grep deviceName  # Confirm Vega 8

# Stack
make vulkan-build
docker-compose up -d
docker logs xnai_rag_api | grep Vulkan  # Expect device detection + offload

# Benchmark (extend make benchmark)
./llama-bench -m /models/... -ngl 30  # Compare vs -ngl 0
```

**Expected Logs**:
```
ggml_vulkan: Found 1 Vulkan devices:
ggml_vulkan: 0 = AMD Radeon Graphics (Vega) ...
offloading 30 repeating layers to GPU
```
