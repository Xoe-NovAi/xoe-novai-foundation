# Archived snapshot — LOCAL_TELEMETRY_FREE_TTS_OPTIONS_2025 (01_04_2026)

This archived snapshot preserves the original `LOCAL_TELEMETRY_FREE_TTS_OPTIONS_2025_dup.md` contents as of 2026-01-04.

(Full original content preserved below)

