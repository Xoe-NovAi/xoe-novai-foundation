# Archived: Project Narrative README (README_dup.md)

This file is an archived snapshot of the more narrative project README that was previously placed under `docs/` as `README_dup.md`.

It has been archived because the canonical, developer-oriented documentation now lives in `docs/PROJECT_OVERVIEW.md` and other technical docs. Keep this file for historical/contextual reference only.

(Original content preserved in repository history.)