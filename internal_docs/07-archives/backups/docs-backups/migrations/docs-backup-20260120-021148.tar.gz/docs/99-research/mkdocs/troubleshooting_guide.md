# MkDocs Troubleshooting Guide

## Common Issues

### Issue 1: "Config file 'mkdocs.yml' does not exist"

**Cause:** Running mkdocs command from wrong directory

**Fix:**
```bash
# Check you're in project root
pwd
# Should show: /path/to/xoe-novai

# Or specify config explicitly
mkdocs build -f /path/to/mkdocs.yml
```

### Issue 2: Plugin ImportError

**Error:**
```
ModuleNotFoundError: No module named 'mkdocs_glightbox'
```

**Cause:** Plugin not installed

**Fix:**
```bash
pip install mkdocs-glightbox
# Or reinstall all doc dependencies
pip install -r requirements-docs.txt
```

### Issue 3: Navigation Not Showing

**Symptom:** Sidebar is empty or shows wrong structure

**Cause:** Incorrect nav configuration or .pages file

**Debug:**
```bash
# Check mkdocs.yml syntax
python -c "import yaml; yaml.safe_load(open('mkdocs.yml'))"

# Validate .pages files
find docs -name ".pages" -exec cat {} \;

# Check for orphaned files
python scripts/find_orphaned_docs.py
```

**Fix:**
```yaml
# mkdocs.yml - ensure nav structure is correct
nav:
  - Home: index.md
  - Getting Started:
    - Quick Start: getting-started/quickstart.md
```

### Issue 4: Search Not Working

**Symptom:** Search returns no results or crashes

**Cause:** Search index not built or corrupted

**Fix:**
```bash
# Rebuild site with clean search index
rm -rf site/
mkdocs build --clean

# Check search_index.json exists
ls -lh site/search/search_index.json

# Validate search index
python -c "import json; json.load(open('site/search/search_index.json'))"
```

### Issue 5: Slow Build Times

**Symptom:** `mkdocs build` takes >30 seconds

**Diagnosis:**
```bash
# Profile build
time mkdocs build

# Check for large files
find docs -type f -size +1M

# Check number of files
find docs -name "*.md" | wc -l
```

**Optimization:**
```yaml
# mkdocs.yml - disable expensive plugins during dev
plugins:
  - search
  # - git-revision-date-localized  # Disable for faster builds
  # - minify  # Disable during development
```

**Or use dev build:**
```bash
# Fast build (skip optimization)
MKDOCS_DEV=1 mkdocs build
```

### Issue 6: RAG Ingestion Fails

**Error:**
```
FileNotFoundError: site/search/search_index.json
```

**Cause:** MkDocs site not built before ingestion

**Fix:**
```bash
# Always build first
make docs-build
make rag-ingest-docs

# Or use --build-first flag
python scripts/mkdocs_rag_ingestion.py --build-first
```

### Issue 7: Memory Issues with FAISS

**Error:**
```
MemoryError: Unable to allocate array
```

**Cause:** Too many documents or large embeddings

**Fix:**
```python
# Reduce chunk size
ingestion = MkDocsRAGIngestion(
    chunk_size=300,  # Smaller chunks
    chunk_overlap=25
)

# Or use index sharding
vectorstore = FAISS.from_documents(
    documents[:1000],  # Process in batches
    embedding=embeddings
)
```

### Issue 8: Git Revision Date Plugin Errors

**Error:**
```
GitCommandError: 'git log' failed
```

**Cause:** Not a git repository or shallow clone

**Fix:**
```bash
# Initialize git if needed
git init
git add .
git commit -m "Initial commit"

# Or disable plugin
# In mkdocs.yml, comment out:
# - git-revision-date-localized
```

### Issue 9: Material Theme Not Loading

**Symptom:** Site looks plain, no Material design

**Cause:** Theme not installed or wrong theme name

**Fix:**
```bash
# Install Material theme
pip install mkdocs-material

# Check mkdocs.yml
theme:
  name: material  # Must be exactly "material"
```

### Issue 10: Code Blocks Not Highlighting

**Symptom:** Code blocks show as plain text

**Cause:** Missing Pygments or wrong language specifier

**Fix:**
```bash
# Install Pygments
pip install pygments

# Use correct language identifiers
\`\`\`python  # Not "py" or "Python"
def example():
    pass
\`\`\`

# Check supported languages
python -c "from pygments.lexers import get_all_lexers; print([l[1][0] for l in get_all_lexers()])"
```

## Performance Optimization

### Build Performance

**Baseline:** Aim for <30 seconds build time

**Optimization Checklist:**

1. **Disable Expensive Plugins During Dev**
```yaml
# mkdocs.yml - development config
plugins:
  - search
  # - git-revision-date-localized  # ~10s overhead
  # - minify  # ~5s overhead
```

2. **Use Incremental Builds**
```bash
# mkdocs serve uses incremental builds automatically
mkdocs serve  # Only rebuilds changed files
```

3. **Optimize Images**
```bash
# Compress images before committing
find docs -name "*.png" -exec optipng {} \;
find docs -name "*.jpg" -exec jpegoptim {} \;
```

4. **Profile Slow Plugins**
```bash
# Time individual plugin loads
python -c "
import time
import mkdocs.plugins

for plugin in mkdocs.plugins.get_plugins():
    start = time.time()
    plugin.on_files(None, None)
    print(f'{plugin}: {time.time() - start:.2f}s')
"
```

### RAG Ingestion Performance

**Baseline:** Aim for <60 seconds for 1000 documents

**Optimization Checklist:**

1. **Batch Embedding Generation**
```python
# Instead of one-by-one:
for doc in documents:
    embed = embeddings.embed_query(doc.page_content)

# Use batch processing:
embeddings.embed_documents([doc.page_content for doc in documents])
```

2. **Use GPU for Embeddings**
```python
embeddings = HuggingFaceEmbeddings(
    model_name="all-MiniLM-L6-v2",
    model_kwargs={'device': 'cuda'}  # Use GPU
)
```

3. **Index Caching**
```python
# Save processed chunks to avoid reprocessing
chunks = extract_chunks()
with open("cache/chunks.json", "w") as f:
    json.dump(chunks, f)

# Load from cache in subsequent runs
if Path("cache/chunks.json").exists():
    with open("cache/chunks.json", "r") as f:
        chunks = json.load(f)
```

### Search Performance

**Baseline:** <100ms for search queries

**Optimization:**

1. **Optimize Search Index**
```yaml
# mkdocs.yml
plugins:
  - search:
      separator: '[\s\-,!=\[\]()"/]+|(?!\d)\.|\&[lg]t;'
      min_search_length: 2  # Fewer false positives
      prebuild_index: true  # Build at compile time
```

2. **Enable Search Result Caching**
```javascript
// In extra.js
const searchCache = new Map();

function search(query) {
  if (searchCache.has(query)) {
    return searchCache.get(query);
  }
  const results = performSearch(query);
  searchCache.set(query, results);
  return results;
}
```

## Debugging Tools

### MkDocs Debug Mode

```bash
# Verbose logging
mkdocs build --verbose

# Very verbose
mkdocs build -v -v
```

### Check Configuration

```bash
# Validate mkdocs.yml
python -c "
import yaml
import sys

try:
    config = yaml.safe_load(open('mkdocs.yml'))
    print('✅ Configuration valid')
    print(f'Site name: {config.get(\"site_name\")}')
    print(f'Plugins: {list(config.get(\"plugins\", {}).keys())}')
except Exception as e:
    print(f'❌ Configuration error: {e}')
    sys.exit(1)
"
```

### Find Missing Files

```bash
# Check for broken references
python scripts/check_references.py

# Find orphaned files (not in nav)
python scripts/find_orphaned_docs.py

# Check for duplicate files
find docs -type f -exec md5sum {} \; | sort | uniq -w32 -D
```

### Monitor Build Performance

```bash
# Profile build time
time mkdocs build

# Profile by component
python -m cProfile -s cumtime $(which mkdocs) build
```

## Getting Help

### Check Logs

```bash
# MkDocs logs
mkdocs build 2>&1 | tee build.log

# RAG ingestion logs
python scripts/mkdocs_rag_ingestion.py 2>&1 | tee ingest.log
```

### Version Information

```bash
# Check versions
mkdocs --version
python --version
pip list | grep mkdocs

# Check plugin versions
pip show mkdocs-material mkdocs-glightbox
```

### Community Resources

- **MkDocs Documentation:** https://www.mkdocs.org
- **Material Theme Docs:** https://squidfunk.github.io/mkdocs-material
- **GitHub Issues:** https://github.com/mkdocs/mkdocs/issues
- **Stack Overflow:** Tag `mkdocs`

### Create Minimal Reproducible Example

```bash
# Create test project
mkdir test-mkdocs && cd test-mkdocs
mkdocs new .

# Minimal mkdocs.yml
cat > mkdocs.yml << EOF
site_name: Test
theme:
  name: material
plugins:
  - search
EOF

# Test build
mkdocs build

# If this works, issue is in your config
# If this fails, issue is in your environment
```
