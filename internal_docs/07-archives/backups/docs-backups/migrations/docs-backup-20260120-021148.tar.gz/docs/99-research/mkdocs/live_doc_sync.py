#!/usr/bin/env python3
"""
Live Documentation Sync for AI Assistants
Watches docs/ directory and auto-updates RAG when files change

This enables:
- Real-time AI assistant context updates
- No manual "rebuild" steps
- Instant documentation search results
- Development-time RAG testing

Usage:
    python scripts/live_documentation_sync.py --watch
"""

import time
import subprocess
from pathlib import Path
from typing import Set, Optional
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent
import argparse

class DocumentationChangeHandler(FileSystemEventHandler):
    """
    Handles file system events for documentation changes
    
    Triggers:
    - File created in docs/
    - File modified in docs/
    - mkdocs.yml changed
    """
    
    def __init__(
        self,
        docs_dir: Path,
        on_change_callback,
        debounce_seconds: float = 2.0
    ):
        self.docs_dir = docs_dir
        self.on_change_callback = on_change_callback
        self.debounce_seconds = debounce_seconds
        self.pending_changes: Set[Path] = set()
        self.last_trigger_time = 0
    
    def on_modified(self, event):
        """Handle file modification"""
        if event.is_directory:
            return
        
        file_path = Path(event.src_path)
        
        # Only process markdown and config files
        if file_path.suffix in [".md", ".yml", ".yaml"]:
            self._schedule_update(file_path)
    
    def on_created(self, event):
        """Handle file creation"""
        if event.is_directory:
            return
        
        file_path = Path(event.src_path)
        
        if file_path.suffix in [".md", ".yml", ".yaml"]:
            self._schedule_update(file_path)
    
    def _schedule_update(self, file_path: Path):
        """Schedule update with debouncing"""
        self.pending_changes.add(file_path)
        
        # Check if enough time has passed since last trigger
        current_time = time.time()
        if current_time - self.last_trigger_time >= self.debounce_seconds:
            self._trigger_update()
    
    def _trigger_update(self):
        """Trigger the update callback"""
        if self.pending_changes:
            print(f"\n📝 Changes detected in {len(self.pending_changes)} files:")
            for path in sorted(self.pending_changes):
                print(f"   - {path.relative_to(Path.cwd())}")
            
            # Trigger callback
            self.on_change_callback(list(self.pending_changes))
            
            # Reset state
            self.pending_changes.clear()
            self.last_trigger_time = time.time()

class LiveDocumentationSync:
    """
    Manages live synchronization of documentation to RAG system
    
    Workflow:
    1. Watch docs/ directory for changes
    2. On change detected:
       a. Rebuild MkDocs site (mkdocs build)
       b. Re-ingest to FAISS (mkdocs_rag_ingestion.py)
       c. Notify AI assistants (optional webhook)
    3. Repeat
    """
    
    def __init__(
        self,
        docs_dir: Path = Path("docs"),
        auto_rebuild: bool = True,
        auto_ingest: bool = True,
        notify_webhook: Optional[str] = None
    ):
        self.docs_dir = docs_dir
        self.auto_rebuild = auto_rebuild
        self.auto_ingest = auto_ingest
        self.notify_webhook = notify_webhook
    
    def start_watching(self):
        """Start watching documentation directory"""
        print(f"👀 Watching {self.docs_dir} for changes...")
        print(f"   Auto-rebuild: {self.auto_rebuild}")
        print(f"   Auto-ingest: {self.auto_ingest}")
        print(f"")
        
        event_handler = DocumentationChangeHandler(
            docs_dir=self.docs_dir,
            on_change_callback=self._handle_changes
        )
        
        observer = Observer()
        observer.schedule(event_handler, str(self.docs_dir), recursive=True)
        observer.schedule(event_handler, "mkdocs.yml", recursive=False)
        observer.start()
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n⏹  Stopping documentation sync...")
            observer.stop()
        
        observer.join()
    
    def _handle_changes(self, changed_files: list):
        """Handle documentation changes"""
        print(f"")
        print(f"🔄 Processing changes...")
        
        # Step 1: Rebuild MkDocs
        if self.auto_rebuild:
            if not self._rebuild_mkdocs():
                print(f"❌ MkDocs build failed, skipping ingestion")
                return
        
        # Step 2: Re-ingest to RAG
        if self.auto_ingest:
            if not self._ingest_to_rag():
                print(f"❌ RAG ingestion failed")
                return
        
        # Step 3: Notify AI assistants (optional)
        if self.notify_webhook:
            self._send_notification(changed_files)
        
        print(f"âœ… Documentation sync complete")
        print(f"")
    
    def _rebuild_mkdocs(self) -> bool:
        """Rebuild MkDocs site"""
        print(f"   📚 Rebuilding MkDocs...")
        
        try:
            result = subprocess.run(
                ["mkdocs", "build", "--clean"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                print(f"   âœ… MkDocs build successful")
                return True
            else:
                print(f"   ❌ MkDocs build failed:")
                print(f"      {result.stderr}")
                return False
        
        except subprocess.TimeoutExpired:
            print(f"   ❌ MkDocs build timed out")
            return False
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
    
    def _ingest_to_rag(self) -> bool:
        """Ingest documentation to RAG system"""
        print(f"   🔮 Ingesting to RAG system...")
        
        try:
            result = subprocess.run(
                [
                    "python",
                    "scripts/mkdocs_rag_ingestion.py",
                    "--collection", "docs",
                    "--output-dir", "data/rag"
                ],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                # Parse output for statistics
                output = result.stdout
                if "chunks" in output.lower():
                    print(f"   âœ… RAG ingestion complete")
                    print(f"      {output.split('chunks')[0].strip().split('\n')[-1]}")
                else:
                    print(f"   âœ… RAG ingestion complete")
                return True
            else:
                print(f"   ❌ RAG ingestion failed:")
                print(f"      {result.stderr}")
                return False
        
        except subprocess.TimeoutExpired:
            print(f"   ❌ RAG ingestion timed out")
            return False
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
    
    def _send_notification(self, changed_files: list):
        """Send webhook notification to AI assistants"""
        print(f"   📡 Notifying AI assistants...")
        
        # This would send a webhook to your AI assistant
        # Example: notify Cline that context has been updated
        
        import requests
        
        payload = {
            "event": "documentation_updated",
            "files": [str(f) for f in changed_files],
            "timestamp": time.time(),
            "message": "Documentation has been updated. Context refresh recommended."
        }
        
        try:
            response = requests.post(
                self.notify_webhook,
                json=payload,
                timeout=5
            )
            
            if response.status_code == 200:
                print(f"   âœ… Notification sent")
            else:
                print(f"   âš ï¸  Notification failed: {response.status_code}")
        
        except Exception as e:
            print(f"   âš ï¸  Could not send notification: {e}")

def main():
    parser = argparse.ArgumentParser(
        description="Live documentation sync for AI assistants"
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Start watching documentation directory"
    )
    parser.add_argument(
        "--docs-dir",
        default="docs",
        help="Documentation directory to watch"
    )
    parser.add_argument(
        "--no-rebuild",
        action="store_true",
        help="Disable automatic MkDocs rebuild"
    )
    parser.add_argument(
        "--no-ingest",
        action="store_true",
        help="Disable automatic RAG ingestion"
    )
    parser.add_argument(
        "--webhook",
        help="Webhook URL for AI assistant notifications"
    )
    
    args = parser.parse_args()
    
    if not args.watch:
        print("Use --watch to start live documentation sync")
        return
    
    # Check dependencies
    try:
        from watchdog.observers import Observer
    except ImportError:
        print("❌ Missing dependency: watchdog")
        print("   Install with: pip install watchdog")
        return
    
    sync = LiveDocumentationSync(
        docs_dir=Path(args.docs_dir),
        auto_rebuild=not args.no_rebuild,
        auto_ingest=not args.no_ingest,
        notify_webhook=args.webhook
    )
    
    sync.start_watching()

if __name__ == "__main__":
    main()
