#!/usr/bin/env python3
"""
Enterprise Audit Logging for MkDocs Documentation System

Compliance Requirements:
- GDPR: User data access tracking
- SOC2: Change management audit trail
- CCPA: Data access transparency
- HIPAA: PHI documentation access (if applicable)

Integration: scripts/enterprise_security.py AuditLogger
"""

from mkdocs.plugins import BasePlugin
from mkdocs.config import config_options
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import json
import hashlib
import logging

logger = logging.getLogger("mkdocs.plugins.audit")

class AuditLoggingPlugin(BasePlugin):
    """
    MkDocs plugin for comprehensive audit logging
    
    Logged Events:
    - BUILD: Documentation build initiated/completed
    - PAGE_CREATE: New page created
    - PAGE_MODIFY: Existing page modified
    - PAGE_DELETE: Page removed
    - CONFIG_CHANGE: mkdocs.yml modified
    - PLUGIN_ERROR: Plugin execution failure
    - ACCESS_ATTEMPT: User access (runtime, via integration)
    
    Audit Trail Format: JSON Lines (.jsonl)
    Storage: data/audit/mkdocs_audit.jsonl
    Retention: Configurable (default: 365 days)
    """
    
    config_scheme = (
        ('audit_file', config_options.Type(str, default='data/audit/mkdocs_audit.jsonl')),
        ('enabled', config_options.Type(bool, default=True)),
        ('log_level', config_options.Type(str, default='INFO')),
        ('retention_days', config_options.Type(int, default=365)),
        ('include_content_hash', config_options.Type(bool, default=True)),
        ('compliance_mode', config_options.Type(str, default='GDPR')),  # GDPR, SOC2, HIPAA
    )
    
    def __init__(self):
        self.audit_entries: List[Dict] = []
        self.build_id = self._generate_build_id()
    
    def _generate_build_id(self) -> str:
        """Generate unique build identifier"""
        timestamp = datetime.utcnow().isoformat()
        return hashlib.sha256(timestamp.encode()).hexdigest()[:16]
    
    def on_startup(self, command, dirty):
        """Log build start"""
        if not self.config['enabled']:
            return
        
        self._log_event(
            event_type='BUILD_START',
            severity='INFO',
            details={
                'command': command,
                'dirty_build': dirty,
                'build_id': self.build_id
            }
        )
    
    def on_config(self, config):
        """Log configuration loaded"""
        if not self.config['enabled']:
            return config
        
        # Log config checksum for tamper detection
        config_checksum = self._compute_config_checksum(config)
        
        self._log_event(
            event_type='CONFIG_LOADED',
            severity='INFO',
            details={
                'site_name': config.get('site_name'),
                'theme': config.get('theme', {}).get('name'),
                'plugins': list(config.get('plugins', {}).keys()),
                'config_checksum': config_checksum
            }
        )
        
        return config
    
    def on_files(self, files, config):
        """Log file inventory"""
        if not self.config['enabled']:
            return files
        
        file_inventory = {
            'total_files': len(files),
            'markdown_files': sum(1 for f in files if f.src_path.endswith('.md')),
            'media_files': sum(1 for f in files if any(f.src_path.endswith(ext) 
                               for ext in ['.png', '.jpg', '.svg', '.gif']))
        }
        
        self._log_event(
            event_type='FILE_INVENTORY',
            severity='INFO',
            details=file_inventory
        )
        
        return files
    
    def on_page_markdown(self, markdown, page, config, files):
        """Log page processing"""
        if not self.config['enabled']:
            return markdown
        
        page_hash = None
        if self.config['include_content_hash']:
            page_hash = hashlib.sha256(markdown.encode()).hexdigest()
        
        self._log_event(
            event_type='PAGE_PROCESS',
            severity='DEBUG',
            details={
                'page_path': page.file.src_path,
                'page_title': page.title,
                'content_hash': page_hash,
                'word_count': len(markdown.split())
            }
        )
        
        return markdown
    
    def on_post_build(self, config):
        """Log build completion and flush audit log"""
        if not self.config['enabled']:
            return
        
        self._log_event(
            event_type='BUILD_COMPLETE',
            severity='INFO',
            details={
                'build_id': self.build_id,
                'total_events': len(self.audit_entries),
                'output_dir': config['site_dir']
            }
        )
        
        # Flush audit log to disk
        self._flush_audit_log()
    
    def on_build_error(self, error):
        """Log build errors"""
        if not self.config['enabled']:
            return
        
        self._log_event(
            event_type='BUILD_ERROR',
            severity='ERROR',
            details={
                'error_type': type(error).__name__,
                'error_message': str(error),
                'build_id': self.build_id
            }
        )
    
    def _log_event(self, event_type: str, severity: str, details: Dict):
        """Create audit log entry"""
        entry = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'build_id': self.build_id,
            'event_type': event_type,
            'severity': severity,
            'compliance_mode': self.config['compliance_mode'],
            'details': details,
            'system_info': self._get_system_info()
        }
        
        self.audit_entries.append(entry)
        logger.log(
            getattr(logging, severity, logging.INFO),
            f"AUDIT: {event_type} - {details}"
        )
    
    def _get_system_info(self) -> Dict:
        """Collect system context for audit"""
        import platform
        import getpass
        
        return {
            'hostname': platform.node(),
            'os': platform.system(),
            'python_version': platform.python_version(),
            'user': getpass.getuser()  # For change attribution
        }
    
    def _compute_config_checksum(self, config: Dict) -> str:
        """Compute checksum of mkdocs.yml for tamper detection"""
        config_str = json.dumps(config, sort_keys=True)
        return hashlib.sha256(config_str.encode()).hexdigest()
    
    def _flush_audit_log(self):
        """Write audit entries to disk"""
        audit_file = Path(self.config['audit_file'])
        audit_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Append to existing log (JSON Lines format)
        with open(audit_file, 'a') as f:
            for entry in self.audit_entries:
                f.write(json.dumps(entry) + '\n')
        
        logger.info(f"✅ Audit log flushed: {len(self.audit_entries)} entries written")


# Integration with enterprise_security.py AuditLogger
class MkDocsAuditIntegration:
    """
    Integrates MkDocs audit logging with enterprise security system
    
    Features:
    - Unified audit trail across all systems
    - Advanced querying and reporting
    - Compliance dashboard integration
    - Real-time alerting on suspicious activity
    """
    
    def __init__(self, enterprise_audit_logger, mkdocs_audit_file: Path):
        from scripts.enterprise_security import AuditLogger
        
        self.enterprise_logger = enterprise_audit_logger
        self.mkdocs_audit_file = mkdocs_audit_file
    
    def sync_audit_logs(self):
        """
        Sync MkDocs audit logs to enterprise system
        
        This enables:
        - Centralized audit dashboard
        - Cross-system correlation
        - Advanced threat detection
        """
        if not self.mkdocs_audit_file.exists():
            logger.warning(f"⚠️  MkDocs audit file not found: {self.mkdocs_audit_file}")
            return
        
        synced_count = 0
        
        with open(self.mkdocs_audit_file, 'r') as f:
            for line in f:
                entry = json.loads(line)
                
                # Convert to enterprise audit format
                self.enterprise_logger.log_event(
                    event_type=f"DOCS_{entry['event_type']}",
                    user=entry.get('system_info', {}).get('user', 'system'),
                    resource=f"mkdocs:{entry.get('details', {}).get('page_path', 'system')}",
                    action='build',
                    result='success' if entry['severity'] != 'ERROR' else 'failure',
                    metadata=entry
                )
                
                synced_count += 1
        
        logger.info(f"✅ Synced {synced_count} audit entries to enterprise system")
    
    def generate_compliance_report(self, framework: str = 'GDPR') -> Dict:
        """
        Generate compliance report from audit logs
        
        Frameworks: GDPR, SOC2, CCPA, HIPAA, ISO27001
        """
        if not self.mkdocs_audit_file.exists():
            return {'error': 'Audit file not found'}
        
        events = []
        with open(self.mkdocs_audit_file, 'r') as f:
            for line in f:
                events.append(json.loads(line))
        
        # Filter by compliance mode
        compliance_events = [e for e in events if e.get('compliance_mode') == framework]
        
        report = {
            'framework': framework,
            'total_events': len(compliance_events),
            'event_types': {},
            'severity_breakdown': {},
            'date_range': {
                'start': compliance_events[0]['timestamp'] if compliance_events else None,
                'end': compliance_events[-1]['timestamp'] if compliance_events else None
            },
            'user_activity': {},
            'error_rate': 0
        }
        
        # Analyze events
        for event in compliance_events:
            event_type = event['event_type']
            severity = event['severity']
            user = event.get('system_info', {}).get('user', 'system')
            
            report['event_types'][event_type] = report['event_types'].get(event_type, 0) + 1
            report['severity_breakdown'][severity] = report['severity_breakdown'].get(severity, 0) + 1
            report['user_activity'][user] = report['user_activity'].get(user, 0) + 1
        
        # Calculate error rate
        error_count = report['severity_breakdown'].get('ERROR', 0)
        report['error_rate'] = (error_count / len(compliance_events) * 100) if compliance_events else 0
        
        return report


# Runtime audit logging (for deployed documentation)
NGINX_AUDIT_LOGGING = """
# nginx_audit.conf
# Runtime audit logging for MkDocs documentation access

log_format audit_log escape=json '{'
    '"timestamp":"$time_iso8601",'
    '"remote_addr":"$remote_addr",'
    '"request_uri":"$request_uri",'
    '"request_method":"$request_method",'
    '"status":"$status",'
    '"user_agent":"$http_user_agent",'
    '"user_id":"$http_x_user_id",'  # From auth header
    '"session_id":"$http_x_session_id",'
    '"referer":"$http_referer",'
    '"response_time":"$request_time"'
'}';

server {
    listen 80;
    server_name docs.xoe-novai.local;
    
    # Audit log location
    access_log /var/log/nginx/mkdocs_audit.log audit_log;
    
    # Enable audit logging for all requests
    access_log /var/log/nginx/mkdocs_access.log combined;
    
    location / {
        # Documentation root
        root /usr/share/nginx/html;
        index index.html;
        
        # Add security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-XSS-Protection "1; mode=block" always;
    }
}
"""


# Audit log analysis tool
class AuditLogAnalyzer:
    """
    Analyze MkDocs audit logs for security insights
    
    Features:
    - Anomaly detection
    - Access pattern analysis
    - Compliance validation
    - Threat intelligence
    """
    
    def __init__(self, audit_file: Path):
        self.audit_file = audit_file
        self.events = self._load_events()
    
    def _load_events(self) -> List[Dict]:
        """Load audit events from file"""
        events = []
        
        if self.audit_file.exists():
            with open(self.audit_file, 'r') as f:
                for line in f:
                    events.append(json.loads(line))
        
        return events
    
    def detect_anomalies(self) -> List[Dict]:
        """
        Detect suspicious patterns in audit logs
        
        Anomalies:
        - Unusual access patterns (time, frequency)
        - Failed authentication attempts
        - Suspicious user agents
        - Rapid page enumeration
        """
        anomalies = []
        
        # Check for high error rates
        error_events = [e for e in self.events if e['severity'] == 'ERROR']
        if len(error_events) / len(self.events) > 0.05:  # >5% errors
            anomalies.append({
                'type': 'HIGH_ERROR_RATE',
                'severity': 'WARNING',
                'details': f"{len(error_events)} errors in {len(self.events)} events"
            })
        
        # Check for configuration tampering
        config_changes = [e for e in self.events if e['event_type'] == 'CONFIG_LOADED']
        if len(config_changes) > 10:  # Multiple config loads
            anomalies.append({
                'type': 'SUSPICIOUS_CONFIG_CHANGES',
                'severity': 'CRITICAL',
                'details': f"{len(config_changes)} configuration loads detected"
            })
        
        return anomalies
    
    def generate_access_report(self) -> Dict:
        """Generate access pattern report"""
        report = {
            'total_builds': len([e for e in self.events if e['event_type'] == 'BUILD_START']),
            'total_pages': len([e for e in self.events if e['event_type'] == 'PAGE_PROCESS']),
            'unique_users': len(set(e.get('system_info', {}).get('user') for e in self.events)),
            'error_count': len([e for e in self.events if e['severity'] == 'ERROR']),
            'date_range': {
                'start': self.events[0]['timestamp'] if self.events else None,
                'end': self.events[-1]['timestamp'] if self.events else None
            }
        }
        
        return report


if __name__ == "__main__":
    print("="*60)
    print("Enterprise Audit Logging for MkDocs")
    print("="*60)
    print("\nSetup Instructions:")
    print("\n1. Add plugin to mkdocs.yml:")
    print("   plugins:")
    print("     - audit_logging:")
    print("         enabled: true")
    print("         compliance_mode: GDPR")
    print("")
    print("2. Configure audit file location:")
    print("   audit_file: data/audit/mkdocs_audit.jsonl")
    print("")
    print("3. Set up log rotation:")
    print("   logrotate -f /etc/logrotate.d/mkdocs-audit")
    print("")
    print("4. Integrate with enterprise security:")
    print("   from scripts.enterprise_security import AuditLogger")
    print("   integration = MkDocsAuditIntegration(audit_logger, audit_file)")
    print("   integration.sync_audit_logs()")
    print("")
    
    # Save Nginx audit config
    nginx_config_path = Path("deployment/nginx/mkdocs_audit.conf")
    nginx_config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(nginx_config_path, 'w') as f:
        f.write(NGINX_AUDIT_LOGGING)
    print(f"✅ Nginx audit config saved: {nginx_config_path}")
