# Cline + MkDocs Integration Guide

This guide shows how to leverage MkDocs documentation with Cline (Claude Code Assistant in VS Code) for optimal development experience.

## Quick Start Commands

### 1. Generate Context for Cline

```bash
# Before asking Cline to implement a feature
make ai-context

# Example: voice interface work
# You'll be prompted for topic: "voice interface"
# This generates ai_context.md

# Then in Cline:
"@ai_context.md Before implementing the new TTS provider, review this context"
```

### 2. Auto-Update Documentation from Code

```bash
# After writing a new Python module
make docs-auto-generate

# This extracts:
# - Function signatures
# - Docstrings
# - Type hints
# - Examples

# Then Cline can reference the generated docs
```

### 3. Live Development Mode

```bash
# Terminal 1: MkDocs live server
make docs-serve

# Terminal 2: Auto-sync to RAG
make docs-watch

# Now as you edit docs:
# 1. MkDocs rebuilds site instantly
# 2. RAG system auto-updates
# 3. Cline has latest context
```

## Integration Patterns

### Pattern 1: Context-Aware Code Generation

**Problem:** Cline hallucinates APIs or uses outdated patterns

**Solution:** Generate focused context before coding

```
# Your workflow:
1. Run: make ai-context
   Topic: "FastAPI endpoints"

2. Tell Cline:
   "@ai_context.md Implement a new /api/voice/synthesize endpoint
   following our existing patterns"

3. Cline reads:
   - Existing endpoint examples
   - Request/response schemas
   - Error handling patterns
   - Security requirements
```

**Why this works:**
- Cline gets EXACT examples from your docs
- No hallucinated API endpoints
- Consistent with existing code

### Pattern 2: Documentation-Driven Development

**Problem:** Documentation and code get out of sync

**Solution:** Make Cline responsible for both

```
# Your workflow:
1. Tell Cline:
   "Implement feature X, then update docs/guides/feature-x.md"

2. Cline implements code + writes docs

3. Run: make rag-update

4. Now your RAG system knows about the new feature
```

### Pattern 3: Expert Knowledge Bases

**Problem:** Cline's context gets cluttered with irrelevant information

**Solution:** Use specialized expert knowledge bases

```
# Your workflow:
1. Create expert KBs:
   make rag-create-experts

2. When working on voice features:
   "Use voice expert knowledge base: data/rag/experts/voice/"

3. Cline queries only voice-related docs
   - Faster retrieval
   - More relevant context
   - Better answers
```

## Best Practices

### DO: Structure Documentation for AI

```markdown
<!-- Good: Clear, scannable structure -->
## Voice Interface API

### `synthesize_speech()`

**Purpose:** Convert text to audio using TTS

**Parameters:**
- `text` (str): Text to synthesize
- `voice_id` (str): Voice identifier

**Returns:** Audio bytes

**Example:**
\`\`\`python
audio = await synthesize_speech("Hello world", "en-US-male")
\`\`\`
```

```markdown
<!-- Bad: Vague, unstructured -->
The voice interface has a synthesize function that takes some text
and returns audio. You can use different voices.
```

### DO: Use Metadata for AI Filtering

```markdown
---
title: Voice Interface API
tags: [api, voice, audio, tts]
category: reference
difficulty: intermediate
last_updated: 2026-01-14
---
```

This helps Cline:
- Filter relevant docs
- Understand context level
- Check for outdated info

### DO: Include Decision Records

```markdown
## Architecture Decision: Why Piper TTS?

**Context:** Need offline TTS for voice interface

**Options Considered:**
1. XTTS V2 - High quality, requires GPU
2. Piper ONNX - Good quality, CPU-only
3. pyttsx3 - Low quality, always available

**Decision:** Piper ONNX (primary) + pyttsx3 (fallback)

**Rationale:**
- CPU-only requirement (Ryzen 7)
- Real-time performance needed
- Offline-first architecture
```

When Cline sees this, it understands WHY decisions were made.

### DON'T: Hide Information in Images

```markdown
<!-- Bad: Cline can't read this -->
![Architecture Diagram](architecture.png)

<!-- Good: Describe it too -->
![Architecture Diagram](architecture.png)

**Architecture Overview:**
1. FastAPI server receives requests
2. Voice handler processes audio
3. RAG pipeline retrieves context
4. LLM generates response
5. TTS synthesizes audio
```

## Advanced Workflows

### Workflow 1: Feature Implementation with Documentation

```
You: "@docs/architecture/components.md I want to add a new audio filter component"

Cline: "I see the existing component architecture. Here's my plan:
1. Create AudioFilterComponent class
2. Implement IComponent interface
3. Add to component registry
4. Update documentation

Should I proceed?"

You: "Yes, and make sure to add usage examples"

Cline: [Implements code + docs]

You: "make rag-update"  [RAG system learns about new component]
```

### Workflow 2: Debugging with Documentation Context

```
You: "Getting error: 'VoiceProvider not found'"

Cline: "Let me check the voice interface docs..."

Cline: "@docs/api/voice.md According to the documentation, VoiceProvider
needs to be registered in the provider registry. Let me check your code..."

[Cline finds the issue: missing provider registration]

Cline: "Found it. You need to call register_provider() in __init__.py"
```

### Workflow 3: Documentation Validation

```
You: "make docs-validate"

[Script checks for:
 - Broken internal links
 - Missing API references
 - Outdated code examples
 - Inconsistent terminology]

[If issues found:]

You: "@validation_report.md Fix these documentation issues"

Cline: [Fixes all issues automatically]
```

## VS Code Tasks Integration

### Quick Access

Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac) → "Tasks: Run Task"

Available tasks:
- **MkDocs: Build Documentation**
- **MkDocs: Serve Documentation**
- **MkDocs: Generate AI Context**
- **RAG: Ingest Documentation**
- **RAG: Create Expert Knowledge Bases**
- **Docs: Auto-Generate from Code**
- **Docs: Watch and Auto-Sync**
- **Docs: Full AI Update Pipeline**

### Keyboard Shortcuts

Add to `.vscode/keybindings.json`:

```json
[
  {
    "key": "ctrl+shift+d b",
    "command": "workbench.action.tasks.runTask",
    "args": "MkDocs: Build Documentation"
  },
  {
    "key": "ctrl+shift+d s",
    "command": "workbench.action.tasks.runTask",
    "args": "MkDocs: Serve Documentation"
  },
  {
    "key": "ctrl+shift+d a",
    "command": "workbench.action.tasks.runTask",
    "args": "MkDocs: Generate AI Context"
  }
]
```

## Troubleshooting

### Cline Gives Outdated Answers

**Cause:** RAG system hasn't been updated

**Fix:**
```bash
make rag-update
```

Then tell Cline: "Context has been refreshed, please try again"

### Cline Can't Find Documentation

**Cause:** Search index not built

**Fix:**
```bash
make docs-build
make rag-ingest-docs
```

### Documentation Out of Sync with Code

**Cause:** Code changed but docs weren't updated

**Fix:**
```bash
# Auto-generate docs from code
make docs-auto-generate

# Or tell Cline:
"Review the code in app/voice_interface.py and update docs/api/voice.md
to match the current implementation"
```

## Pro Tips

### Tip 1: Use Git Commit Messages as Documentation

```bash
# After implementation, tell Cline:
"Write a commit message that explains this change, then add the
explanation to docs/changelog.md"

# Cline will:
1. Write clear commit message
2. Update changelog
3. Commit both code and docs
```

### Tip 2: Automated Documentation Reviews

```bash
# Add to .github/workflows/

name: Doc Review
on: [pull_request]

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Check if docs were updated
        run: |
          if git diff --name-only origin/main | grep -q "^app/"; then
            if ! git diff --name-only origin/main | grep -q "^docs/"; then
              echo "❌ Code changed but docs weren't updated"
              exit 1
            fi
          fi
```

### Tip 3: Documentation Snippets Library

Create `docs/snippets/` with reusable content:

```markdown
<!-- docs/snippets/installation.md -->
## Installation

\`\`\`bash
pip install -r requirements.txt
\`\`\`
```

Then in any doc:

```markdown
--8<-- "snippets/installation.md"
```

Cline can reference these snippets for consistency.

## Summary

MkDocs + Cline integration provides:

âœ… **Better Code Quality**: Cline follows documented patterns  
âœ… **Faster Development**: Context-aware suggestions  
âœ… **Living Documentation**: Docs evolve with code  
âœ… **Knowledge Sharing**: RAG system learns from docs  
âœ… **Reduced Errors**: Consistent patterns enforced  

**Next Steps:**
1. Run `make ai-update-all` to set up integration
2. Try generating context: `make ai-context`
3. Start development mode: `make docs-dev`
4. Tell Cline: "@ai_context.md Let's build something!"
