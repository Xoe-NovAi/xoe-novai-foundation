#!/usr/bin/env python3
"""
MkDocs to RAG Ingestion Pipeline
Converts MkDocs documentation into FAISS-ready embeddings

This replaces crawl4ai for local documentation ingestion
- Faster (no browser overhead)
- Better structure preservation
- Direct access to search_index.json

Usage:
    python scripts/mkdocs_rag_ingestion.py --build-first --collection docs
"""

import json
from pathlib import Path
from typing import List, Dict, Optional
import argparse
from dataclasses import dataclass
import hashlib

# Your existing RAG imports
try:
    from sentence_transformers import SentenceTransformer
    from langchain.vectorstores import FAISS
    from langchain.embeddings import HuggingFaceEmbeddings
    from langchain.schema import Document
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    print("⚠️  LangChain not installed. Install with: pip install langchain sentence-transformers")

@dataclass
class DocChunk:
    """Represents a documentation chunk for RAG"""
    id: str
    title: str
    location: str
    text: str
    section: str  # e.g., "api", "guides", "research"
    metadata: Dict

class MkDocsRAGIngestion:
    """
    Ingests MkDocs documentation into your RAG system
    
    Architecture:
    1. Load search_index.json (pre-processed by MkDocs)
    2. Chunk documents intelligently (preserve headers)
    3. Generate embeddings with your existing model
    4. Store in FAISS with metadata
    5. Enable hybrid search (BM25 + dense vectors)
    """
    
    def __init__(
        self,
        docs_dir: Path = Path("docs"),
        site_dir: Path = Path("site"),
        embedding_model: str = "all-MiniLM-L6-v2",
        chunk_size: int = 500,
        chunk_overlap: int = 50
    ):
        self.docs_dir = docs_dir
        self.site_dir = site_dir
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        if LANGCHAIN_AVAILABLE:
            self.embeddings = HuggingFaceEmbeddings(
                model_name=embedding_model,
                model_kwargs={'device': 'cpu'},  # Use GPU if available
                encode_kwargs={'normalize_embeddings': True}
            )
        else:
            self.embeddings = None
        
        self.search_index = self._load_search_index()
    
    def _load_search_index(self) -> Dict:
        """Load MkDocs search index"""
        search_path = self.site_dir / "search" / "search_index.json"
        
        if not search_path.exists():
            raise FileNotFoundError(
                f"Search index not found at {search_path}. "
                "Run 'mkdocs build' first."
            )
        
        with open(search_path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def extract_chunks(self) -> List[DocChunk]:
        """
        Extract intelligent chunks from MkDocs search index
        
        MkDocs already provides structure:
        - docs: List of {location, title, text}
        - Hierarchical navigation preserved
        - Headers included in text
        
        We enhance this with:
        - Smart chunking (preserve code blocks, headers)
        - Section tagging (api, guides, research)
        - Metadata enrichment
        """
        chunks = []
        
        for doc_entry in self.search_index.get("docs", []):
            location = doc_entry.get("location", "")
            title = doc_entry.get("title", "Unknown")
            text = doc_entry.get("text", "")
            
            # Determine section from location
            section = self._extract_section(location)
            
            # Smart chunking
            text_chunks = self._intelligent_chunk(text, title)
            
            for i, chunk_text in enumerate(text_chunks):
                chunk_id = self._generate_chunk_id(location, i)
                
                chunks.append(DocChunk(
                    id=chunk_id,
                    title=title,
                    location=location,
                    text=chunk_text,
                    section=section,
                    metadata={
                        "source": "mkdocs",
                        "type": "documentation",
                        "section": section,
                        "chunk_index": i,
                        "total_chunks": len(text_chunks),
                        "url": f"/{location}"
                    }
                ))
        
        print(f"âœ… Extracted {len(chunks)} chunks from {len(self.search_index.get('docs', []))} documents")
        return chunks
    
    def _extract_section(self, location: str) -> str:
        """Determine documentation section from URL"""
        parts = location.strip("/").split("/")
        if not parts or parts[0] == "":
            return "home"
        return parts[0]  # e.g., "api", "guides", "research"
    
    def _intelligent_chunk(self, text: str, title: str) -> List[str]:
        """
        Chunk text while preserving structure
        
        Rules:
        1. Never split code blocks (``` ... ```)
        2. Prefer splitting at headers (## ...)
        3. Keep chunks around target size
        4. Preserve context with overlap
        """
        chunks = []
        
        # Add title as context prefix
        context_prefix = f"# {title}\n\n"
        
        # Split on double newlines (paragraphs)
        paragraphs = text.split("\n\n")
        
        current_chunk = context_prefix
        in_code_block = False
        
        for para in paragraphs:
            # Track code blocks
            if "```" in para:
                in_code_block = not in_code_block
            
            # Potential chunk
            potential_chunk = current_chunk + para + "\n\n"
            
            # Decision logic
            if len(potential_chunk) > self.chunk_size and not in_code_block:
                # Save current chunk
                if current_chunk != context_prefix:
                    chunks.append(current_chunk.strip())
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap(current_chunk)
                current_chunk = context_prefix + overlap_text + para + "\n\n"
            else:
                current_chunk = potential_chunk
        
        # Add final chunk
        if current_chunk != context_prefix:
            chunks.append(current_chunk.strip())
        
        return chunks if chunks else [context_prefix + text]
    
    def _get_overlap(self, text: str) -> str:
        """Get last N characters for context overlap"""
        words = text.split()
        overlap_words = words[-self.chunk_overlap:] if len(words) > self.chunk_overlap else words
        return " ".join(overlap_words) + "\n\n"
    
    def _generate_chunk_id(self, location: str, index: int) -> str:
        """Generate unique chunk ID"""
        content = f"{location}_{index}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def create_faiss_index(
        self,
        chunks: List[DocChunk],
        index_path: Path = Path("data/faiss_docs_index")
    ) -> Optional[FAISS]:
        """
        Create FAISS vector store from chunks
        
        This integrates with your existing RAG system
        """
        if not LANGCHAIN_AVAILABLE:
            print("❌ LangChain not available. Cannot create FAISS index.")
            return None
        
        # Convert to LangChain documents
        documents = [
            Document(
                page_content=chunk.text,
                metadata={
                    "id": chunk.id,
                    "title": chunk.title,
                    "location": chunk.location,
                    "section": chunk.section,
                    **chunk.metadata
                }
            )
            for chunk in chunks
        ]
        
        print(f"🔄 Generating embeddings for {len(documents)} chunks...")
        
        # Create FAISS index
        vectorstore = FAISS.from_documents(
            documents=documents,
            embedding=self.embeddings
        )
        
        # Save to disk
        index_path.parent.mkdir(parents=True, exist_ok=True)
        vectorstore.save_local(str(index_path))
        
        print(f"âœ… FAISS index saved to {index_path}")
        return vectorstore
    
    def add_to_existing_index(
        self,
        chunks: List[DocChunk],
        existing_index_path: Path
    ):
        """
        Add documentation chunks to existing FAISS index
        
        Use this to incrementally update your RAG system
        """
        if not LANGCHAIN_AVAILABLE:
            print("❌ LangChain not available.")
            return
        
        # Load existing index
        vectorstore = FAISS.load_local(
            str(existing_index_path),
            embeddings=self.embeddings
        )
        
        # Convert chunks to documents
        documents = [
            Document(
                page_content=chunk.text,
                metadata={
                    "id": chunk.id,
                    "title": chunk.title,
                    "location": chunk.location,
                    "section": chunk.section,
                    **chunk.metadata
                }
            )
            for chunk in chunks
        ]
        
        # Add to existing index
        vectorstore.add_documents(documents)
        
        # Save updated index
        vectorstore.save_local(str(existing_index_path))
        
        print(f"âœ… Added {len(chunks)} chunks to existing index")
    
    def export_for_crawl4ai(self, chunks: List[DocChunk], output_path: Path):
        """
        Export chunks in format compatible with crawl4ai pipeline
        
        This allows using MkDocs as alternative source for crawl4ai
        """
        export_data = {
            "source": "mkdocs",
            "chunks": [
                {
                    "id": chunk.id,
                    "title": chunk.title,
                    "url": f"file:///{self.site_dir / chunk.location}",
                    "content": chunk.text,
                    "section": chunk.section,
                    "metadata": chunk.metadata
                }
                for chunk in chunks
            ]
        }
        
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2)
        
        print(f"âœ… Exported {len(chunks)} chunks for crawl4ai: {output_path}")

def main():
    parser = argparse.ArgumentParser(
        description="Ingest MkDocs documentation into RAG system"
    )
    parser.add_argument(
        "--build-first",
        action="store_true",
        help="Run 'mkdocs build' before ingestion"
    )
    parser.add_argument(
        "--collection",
        default="docs",
        help="Collection name for FAISS index"
    )
    parser.add_argument(
        "--output-dir",
        default="data",
        help="Output directory for FAISS index"
    )
    parser.add_argument(
        "--export-crawl4ai",
        help="Export chunks for crawl4ai (JSON file path)"
    )
    parser.add_argument(
        "--add-to-existing",
        help="Add to existing FAISS index (path)"
    )
    
    args = parser.parse_args()
    
    # Build MkDocs if requested
    if args.build_first:
        import subprocess
        print("🔄 Building MkDocs site...")
        subprocess.run(["mkdocs", "build"], check=True)
    
    # Initialize ingestion pipeline
    ingestion = MkDocsRAGIngestion()
    
    # Extract chunks
    chunks = ingestion.extract_chunks()
    
    # Export for crawl4ai if requested
    if args.export_crawl4ai:
        ingestion.export_for_crawl4ai(chunks, Path(args.export_crawl4ai))
    
    # Add to existing index
    if args.add_to_existing:
        ingestion.add_to_existing_index(chunks, Path(args.add_to_existing))
    else:
        # Create new FAISS index
        index_path = Path(args.output_dir) / f"faiss_{args.collection}_index"
        ingestion.create_faiss_index(chunks, index_path)
    
    print(f"")
    print(f"✅ RAG ingestion complete!")
    print(f"")
    print(f"Next steps:")
    print(f"1. Test retrieval: query your FAISS index")
    print(f"2. Integrate with your RAG pipeline")
    print(f"3. Set up automated ingestion (GitHub Actions)")

if __name__ == "__main__":
    main()
