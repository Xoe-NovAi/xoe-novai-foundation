#!/usr/bin/env python3
"""
Expert Knowledge Base Manager
Manages specialized knowledge bases for different AI experts

Architecture:
- Voice Expert: STT/TTS, audio processing, voice interface
- RAG Expert: Vector search, embeddings, retrieval strategies
- Deployment Expert: Docker, Kubernetes, CI/CD
- Research Expert: Latest papers, implementation guides

Each expert has dedicated FAISS index with domain-specific docs
"""

import json
from pathlib import Path
from typing import List, Dict, Optional, Set
from dataclasses import dataclass
from enum import Enum

@dataclass
class ExpertConfig:
    """Configuration for specialized expert"""
    name: str
    sections: List[str]  # MkDocs sections to include
    keywords: List[str]  # Additional filtering keywords
    min_relevance: float = 0.7
    max_docs: int = 1000

class ExpertType(str, Enum):
    """Available expert types"""
    VOICE = "voice"
    RAG = "rag"
    DEPLOYMENT = "deployment"
    RESEARCH = "research"
    API = "api"
    SECURITY = "security"

class ExpertKnowledgeManager:
    """
    Manages creation and updates of specialized knowledge bases
    
    Why this matters:
    - AI experts perform better with focused context
    - Reduces noise in retrieval (no irrelevant docs)
    - Enables parallel expert querying
    - Supports multi-agent architectures
    """
    
    EXPERT_CONFIGS = {
        ExpertType.VOICE: ExpertConfig(
            name="Voice Interface Expert",
            sections=["api/voice", "guides/voice", "architecture"],
            keywords=["STT", "TTS", "audio", "whisper", "piper", "microphone"]
        ),
        ExpertType.RAG: ExpertConfig(
            name="RAG Pipeline Expert",
            sections=["api/rag", "guides/rag", "architecture/rag"],
            keywords=["FAISS", "embedding", "vector", "retrieval", "langchain"]
        ),
        ExpertType.DEPLOYMENT: ExpertConfig(
            name="Deployment Expert",
            sections=["guides/deployment", "guides/docker", "guides/kubernetes"],
            keywords=["docker", "k8s", "compose", "ci/cd", "github actions"]
        ),
        ExpertType.RESEARCH: ExpertConfig(
            name="Research Implementation Expert",
            sections=["research"],
            keywords=["vulkan", "kokoro", "optimization", "performance"]
        ),
        ExpertType.API: ExpertConfig(
            name="API Development Expert",
            sections=["api"],
            keywords=["fastapi", "endpoint", "request", "response", "schema"]
        ),
        ExpertType.SECURITY: ExpertConfig(
            name="Security Expert",
            sections=["guides/security", "architecture/security"],
            keywords=["auth", "encryption", "rbac", "compliance", "audit"]
        )
    }
    
    def __init__(self, docs_index_path: Path):
        """
        Initialize with base documentation index
        
        Args:
            docs_index_path: Path to FAISS index from MkDocs ingestion
        """
        self.docs_index_path = docs_index_path
        self.base_chunks = self._load_base_chunks()
    
    def _load_base_chunks(self) -> List[Dict]:
        """Load all chunks from base documentation index"""
        # This would load from your FAISS index
        # Simplified here for demonstration
        chunks_file = self.docs_index_path.parent / "chunks.json"
        
        if chunks_file.exists():
            with open(chunks_file, "r") as f:
                return json.load(f)
        return []
    
    def create_expert_kb(
        self,
        expert_type: ExpertType,
        output_path: Path
    ) -> Dict[str, int]:
        """
        Create specialized knowledge base for expert
        
        Returns:
            Statistics: {"total_chunks": N, "filtered_chunks": M}
        """
        config = self.EXPERT_CONFIGS[expert_type]
        
        print(f"🔄 Creating knowledge base for {config.name}...")
        
        # Filter chunks by section and keywords
        filtered_chunks = self._filter_chunks(config)
        
        # Enrich chunks with expert-specific metadata
        enriched_chunks = self._enrich_chunks(filtered_chunks, expert_type)
        
        # Save expert-specific index
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path / "expert_chunks.json", "w") as f:
            json.dump(enriched_chunks, f, indent=2)
        
        stats = {
            "expert": expert_type.value,
            "total_base_chunks": len(self.base_chunks),
            "filtered_chunks": len(filtered_chunks),
            "enriched_chunks": len(enriched_chunks),
            "config": {
                "sections": config.sections,
                "keywords": config.keywords
            }
        }
        
        with open(output_path / "stats.json", "w") as f:
            json.dump(stats, f, indent=2)
        
        print(f"âœ… Created expert KB: {len(enriched_chunks)} chunks")
        print(f"   Filtered from {len(self.base_chunks)} base chunks")
        
        return stats
    
    def _filter_chunks(self, config: ExpertConfig) -> List[Dict]:
        """Filter chunks by section and keywords"""
        filtered = []
        
        for chunk in self.base_chunks:
            # Check section match
            section_match = any(
                section in chunk.get("section", "")
                for section in config.sections
            )
            
            # Check keyword match
            text = chunk.get("text", "").lower()
            keyword_match = any(
                keyword.lower() in text
                for keyword in config.keywords
            )
            
            if section_match or keyword_match:
                filtered.append(chunk)
        
        return filtered
    
    def _enrich_chunks(
        self,
        chunks: List[Dict],
        expert_type: ExpertType
    ) -> List[Dict]:
        """Add expert-specific metadata to chunks"""
        enriched = []
        
        for chunk in chunks:
            enriched_chunk = chunk.copy()
            enriched_chunk["metadata"] = enriched_chunk.get("metadata", {})
            enriched_chunk["metadata"]["expert"] = expert_type.value
            enriched_chunk["metadata"]["specialized"] = True
            
            # Add relevance scoring based on keyword density
            config = self.EXPERT_CONFIGS[expert_type]
            relevance = self._calculate_relevance(chunk, config)
            enriched_chunk["metadata"]["relevance_score"] = relevance
            
            enriched.append(enriched_chunk)
        
        # Sort by relevance
        enriched.sort(key=lambda x: x["metadata"]["relevance_score"], reverse=True)
        
        # Limit to max_docs if configured
        config = self.EXPERT_CONFIGS[expert_type]
        if config.max_docs:
            enriched = enriched[:config.max_docs]
        
        return enriched
    
    def _calculate_relevance(self, chunk: Dict, config: ExpertConfig) -> float:
        """Calculate relevance score for chunk"""
        text = chunk.get("text", "").lower()
        
        # Count keyword occurrences
        keyword_count = sum(
            text.count(keyword.lower())
            for keyword in config.keywords
        )
        
        # Normalize by text length
        text_length = len(text.split())
        relevance = keyword_count / max(text_length, 1) * 100
        
        return min(relevance, 1.0)  # Cap at 1.0
    
    def create_all_experts(self, output_base: Path):
        """Create all expert knowledge bases"""
        stats_all = {}
        
        for expert_type in ExpertType:
            output_path = output_base / expert_type.value
            stats = self.create_expert_kb(expert_type, output_path)
            stats_all[expert_type.value] = stats
        
        # Save overall statistics
        with open(output_base / "all_experts_stats.json", "w") as f:
            json.dump(stats_all, f, indent=2)
        
        print(f"")
        print(f"âœ… Created all expert knowledge bases")
        for expert, stats in stats_all.items():
            print(f"   {expert}: {stats['enriched_chunks']} chunks")
    
    def update_expert_kb(
        self,
        expert_type: ExpertType,
        new_chunks: List[Dict],
        kb_path: Path
    ):
        """
        Incrementally update expert knowledge base
        
        Use this when:
        - New documentation added
        - Research reports published
        - API changes documented
        """
        # Load existing chunks
        existing_file = kb_path / "expert_chunks.json"
        if existing_file.exists():
            with open(existing_file, "r") as f:
                existing_chunks = json.load(f)
        else:
            existing_chunks = []
        
        # Filter and enrich new chunks
        config = self.EXPERT_CONFIGS[expert_type]
        filtered_new = self._filter_chunks_list(new_chunks, config)
        enriched_new = self._enrich_chunks(filtered_new, expert_type)
        
        # Merge with existing (deduplicate by ID)
        existing_ids = {c.get("id") for c in existing_chunks}
        merged = existing_chunks + [
            c for c in enriched_new
            if c.get("id") not in existing_ids
        ]
        
        # Save updated KB
        with open(existing_file, "w") as f:
            json.dump(merged, f, indent=2)
        
        print(f"âœ… Updated {expert_type.value} KB:")
        print(f"   Added {len(enriched_new)} new chunks")
        print(f"   Total: {len(merged)} chunks")
    
    def _filter_chunks_list(self, chunks: List[Dict], config: ExpertConfig) -> List[Dict]:
        """Helper to filter a specific list of chunks"""
        return [
            chunk for chunk in chunks
            if self._chunk_matches_config(chunk, config)
        ]
    
    def _chunk_matches_config(self, chunk: Dict, config: ExpertConfig) -> bool:
        """Check if chunk matches expert config"""
        section_match = any(
            section in chunk.get("section", "")
            for section in config.sections
        )
        
        text = chunk.get("text", "").lower()
        keyword_match = any(
            keyword.lower() in text
            for keyword in config.keywords
        )
        
        return section_match or keyword_match

def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Manage specialized expert knowledge bases"
    )
    parser.add_argument(
        "--base-index",
        required=True,
        help="Path to base FAISS documentation index"
    )
    parser.add_argument(
        "--output-dir",
        default="data/rag/experts",
        help="Output directory for expert KBs"
    )
    parser.add_argument(
        "--expert",
        choices=[e.value for e in ExpertType],
        help="Create specific expert KB (default: all)"
    )
    parser.add_argument(
        "--update",
        action="store_true",
        help="Update existing expert KB instead of creating new"
    )
    
    args = parser.parse_args()
    
    manager = ExpertKnowledgeManager(Path(args.base_index))
    output_base = Path(args.output_dir)
    
    if args.expert:
        # Create/update specific expert
        expert_type = ExpertType(args.expert)
        output_path = output_base / expert_type.value
        
        if args.update:
            print(f"⚠️  Update mode not yet implemented")
            print(f"   Recreating {expert_type.value} KB from scratch")
        
        manager.create_expert_kb(expert_type, output_path)
    else:
        # Create all experts
        manager.create_all_experts(output_base)
    
    print(f"")
    print(f"Next steps:")
    print(f"1. Deploy expert KBs to your RAG system")
    print(f"2. Configure AI agents to use specialized KBs")
    print(f"3. Test expert retrieval performance")

if __name__ == "__main__":
    main()
