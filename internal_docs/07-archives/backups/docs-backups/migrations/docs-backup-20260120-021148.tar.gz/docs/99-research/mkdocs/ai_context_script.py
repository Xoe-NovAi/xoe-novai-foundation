#!/usr/bin/env python3
"""
AI Context Helper for Cline/Claude Code Assistant
Builds structured context from MkDocs documentation for AI queries

Usage:
    # From Cline prompt:
    "Before implementing X, run: python scripts/ai_context_helper.py --topic 'voice interface'"
    
    # This generates a context.md file that Cline can read
"""

import json
import yaml
from pathlib import Path
from typing import List, Dict, Optional
import argparse

class MkDocsContextBuilder:
    """Extracts relevant documentation context for AI assistants"""
    
    def __init__(self, docs_dir: Path = Path("docs"), site_dir: Path = Path("site")):
        self.docs_dir = docs_dir
        self.site_dir = site_dir
        self.mkdocs_config = self._load_mkdocs_config()
        self.search_index = self._load_search_index()
    
    def _load_mkdocs_config(self) -> dict:
        """Load mkdocs.yml for structure understanding"""
        with open("mkdocs.yml", "r") as f:
            return yaml.safe_load(f)
    
    def _load_search_index(self) -> dict:
        """Load pre-built search index"""
        search_path = self.site_dir / "search" / "search_index.json"
        if not search_path.exists():
            print("⚠️  Search index not found. Run 'mkdocs build' first.")
            return {"docs": []}
        
        with open(search_path, "r") as f:
            return json.load(f)
    
    def search_docs(self, query: str, max_results: int = 5) -> List[Dict]:
        """
        Simple keyword search in documentation
        (In production, integrate with your FAISS RAG system)
        """
        query_lower = query.lower()
        results = []
        
        for doc in self.search_index.get("docs", []):
            # Score based on title and text matches
            title_matches = query_lower in doc.get("title", "").lower()
            text_matches = query_lower in doc.get("text", "").lower()
            
            if title_matches or text_matches:
                score = (title_matches * 2) + text_matches  # Title match = 2x weight
                results.append({
                    "title": doc.get("title"),
                    "location": doc.get("location"),
                    "text": doc.get("text", "")[:500],  # First 500 chars
                    "score": score
                })
        
        # Sort by relevance
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:max_results]
    
    def get_section_context(self, section: str) -> Optional[str]:
        """
        Extract entire section from docs
        
        Args:
            section: Path like "api/voice" or "guides/deployment"
        """
        doc_path = self.docs_dir / f"{section}.md"
        
        if not doc_path.exists():
            # Try as directory with index
            doc_path = self.docs_dir / section / "index.md"
        
        if not doc_path.exists():
            return None
        
        with open(doc_path, "r") as f:
            return f.read()
    
    def build_context_file(
        self,
        topic: str,
        output: Path = Path("ai_context.md"),
        include_code_examples: bool = True
    ):
        """
        Generate comprehensive context file for AI assistant
        
        This is what Cline reads before generating code
        """
        search_results = self.search_docs(topic)
        
        context_parts = [
            f"# AI Context: {topic}",
            f"",
            f"**Generated from MkDocs documentation**",
            f"**Project:** {self.mkdocs_config.get('site_name')}",
            f"**Version:** {self.mkdocs_config.get('extra', {}).get('project', {}).get('version', 'unknown')}",
            f"",
            f"## Relevant Documentation Sections",
            f""
        ]
        
        for i, result in enumerate(search_results, 1):
            context_parts.extend([
                f"### {i}. {result['title']}",
                f"**Location:** `{result['location']}`",
                f"",
                result['text'],
                f"",
                f"[Read full documentation]({result['location']})",
                f"",
                "---",
                ""
            ])
        
        # Add project structure overview
        context_parts.extend([
            "## Project Structure",
            "```",
            self._get_project_structure(),
            "```",
            ""
        ])
        
        # Add relevant code examples if requested
        if include_code_examples:
            examples = self._extract_code_examples(search_results)
            if examples:
                context_parts.extend([
                    "## Code Examples",
                    ""
                ])
                for lang, code in examples:
                    context_parts.extend([
                        f"### {lang}",
                        f"```{lang}",
                        code,
                        "```",
                        ""
                    ])
        
        # Write to file
        with open(output, "w") as f:
            f.write("\n".join(context_parts))
        
        print(f"âœ… Context file generated: {output}")
        print(f"📊 Included {len(search_results)} documentation sections")
        print(f"")
        print(f"Next steps for Cline:")
        print(f"1. Read the context: @{output}")
        print(f"2. Ask: 'Based on this context, implement {topic}'")
    
    def _get_project_structure(self) -> str:
        """Generate tree view of docs structure"""
        nav = self.mkdocs_config.get("nav", [])
        return self._format_nav_tree(nav)
    
    def _format_nav_tree(self, nav, indent=0) -> str:
        """Recursively format navigation as tree"""
        lines = []
        for item in nav:
            if isinstance(item, dict):
                for key, value in item.items():
                    lines.append("  " * indent + f"├── {key}")
                    if isinstance(value, list):
                        lines.append(self._format_nav_tree(value, indent + 1))
                    else:
                        lines.append("  " * (indent + 1) + f"└── {value}")
            else:
                lines.append("  " * indent + f"├── {item}")
        return "\n".join(lines)
    
    def _extract_code_examples(self, search_results: List[Dict]) -> List[tuple]:
        """Extract code blocks from documentation"""
        examples = []
        for result in search_results:
            location = result["location"].rstrip("/")
            # Get full markdown file
            doc_path = self.docs_dir / f"{location}.md"
            
            if doc_path.exists():
                with open(doc_path, "r") as f:
                    content = f.read()
                    
                # Simple code block extraction (```language)
                import re
                code_blocks = re.findall(r"```(\w+)\n(.*?)```", content, re.DOTALL)
                examples.extend(code_blocks[:2])  # Max 2 per doc
        
        return examples[:5]  # Max 5 total

def main():
    parser = argparse.ArgumentParser(
        description="Build AI context from MkDocs documentation"
    )
    parser.add_argument(
        "--topic",
        required=True,
        help="Topic to search for (e.g., 'voice interface', 'deployment')"
    )
    parser.add_argument(
        "--output",
        default="ai_context.md",
        help="Output file for AI context"
    )
    parser.add_argument(
        "--no-code",
        action="store_true",
        help="Exclude code examples from context"
    )
    
    args = parser.parse_args()
    
    builder = MkDocsContextBuilder()
    builder.build_context_file(
        topic=args.topic,
        output=Path(args.output),
        include_code_examples=not args.no_code
    )

if __name__ == "__main__":
    main()
