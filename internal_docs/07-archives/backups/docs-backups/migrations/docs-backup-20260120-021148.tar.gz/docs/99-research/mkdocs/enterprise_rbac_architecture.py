#!/usr/bin/env python3
"""
Enterprise RBAC Architecture for MkDocs
Hybrid approach: Build-time metadata + Runtime enforcement

Architecture Layers:
1. MkDocs Plugin: Adds RBAC metadata at build time
2. Nginx/Traefik: Runtime access control via Lua/middleware
3. Integration: Connects to existing enterprise_security.py RBAC system
"""

from mkdocs.plugins import BasePlugin
from mkdocs.config import config_options
from pathlib import Path
import json
import yaml
from typing import Dict, List, Optional, Set
import logging

logger = logging.getLogger("mkdocs.plugins.enterprise_rbac")

class EnterpriseRBACPlugin(BasePlugin):
    """
    MkDocs plugin for enterprise RBAC integration
    
    Features:
    - Page-level access control metadata
    - Role-based navigation filtering
    - Audit logging integration
    - Dynamic content restriction
    
    Integration with scripts/enterprise_security.py:
    - Uses same RBAC roles (viewer, editor, admin)
    - Connects to existing permission checking
    - Integrates with audit logger
    """
    
    config_scheme = (
        ('rbac_config', config_options.Type(str, default='rbac_config.yml')),
        ('default_role', config_options.Type(str, default='viewer')),
        ('audit_enabled', config_options.Type(bool, default=True)),
        ('restrict_search', config_options.Type(bool, default=True)),
        ('generate_access_map', config_options.Type(bool, default=True)),
    )
    
    def __init__(self):
        self.rbac_rules: Dict[str, List[str]] = {}
        self.page_access_map: Dict[str, Dict] = {}
        self.restricted_pages: Set[str] = set()
    
    def on_config(self, config):
        """Load RBAC configuration at build start"""
        logger.info("🔐 Loading Enterprise RBAC configuration...")
        
        rbac_config_path = Path(self.config['rbac_config'])
        if rbac_config_path.exists():
            with open(rbac_config_path, 'r') as f:
                self.rbac_rules = yaml.safe_load(f)
            logger.info(f"✅ Loaded RBAC rules: {len(self.rbac_rules)} roles configured")
        else:
            logger.warning(f"⚠️  RBAC config not found: {rbac_config_path}")
            self._create_default_config(rbac_config_path)
        
        return config
    
    def on_page_markdown(self, markdown, page, config, files):
        """
        Process page metadata for RBAC
        
        Frontmatter example:
        ---
        title: API Documentation
        rbac_roles: [admin, developer]
        rbac_restricted: true
        classification: internal
        ---
        """
        # Extract RBAC metadata from frontmatter
        if page.meta:
            roles_required = page.meta.get('rbac_roles', [self.config['default_role']])
            is_restricted = page.meta.get('rbac_restricted', False)
            classification = page.meta.get('classification', 'public')
            
            # Store access metadata
            page_path = page.file.src_path
            self.page_access_map[page_path] = {
                'roles': roles_required,
                'restricted': is_restricted,
                'classification': classification,
                'url': page.url
            }
            
            if is_restricted:
                self.restricted_pages.add(page_path)
                logger.debug(f"🔒 Restricted page: {page_path} (roles: {roles_required})")
        
        return markdown
    
    def on_page_context(self, context, page, config, nav):
        """Inject RBAC metadata into page context"""
        page_path = page.file.src_path
        
        if page_path in self.page_access_map:
            context['rbac'] = self.page_access_map[page_path]
            context['rbac']['enabled'] = True
        else:
            context['rbac'] = {
                'enabled': False,
                'roles': [self.config['default_role']],
                'restricted': False,
                'classification': 'public'
            }
        
        return context
    
    def on_post_build(self, config):
        """Generate access control files for runtime enforcement"""
        logger.info("📝 Generating RBAC access control files...")
        
        if self.config['generate_access_map']:
            # Generate access map for reverse proxy
            self._generate_nginx_access_map(config)
            self._generate_rbac_manifest(config)
        
        logger.info(f"✅ RBAC build complete: {len(self.page_access_map)} pages processed")
        logger.info(f"   🔒 Restricted pages: {len(self.restricted_pages)}")
    
    def _generate_nginx_access_map(self, config):
        """
        Generate Nginx/Traefik access control configuration
        
        Output: site/rbac/nginx_access.conf
        Format: Map of URL paths to required roles
        """
        site_dir = Path(config['site_dir'])
        rbac_dir = site_dir / 'rbac'
        rbac_dir.mkdir(exist_ok=True)
        
        # Generate Nginx map file
        nginx_map = [
            "# MkDocs RBAC Access Control Map",
            "# Generated by EnterpriseRBACPlugin",
            "# Include in nginx.conf: include /path/to/rbac/nginx_access.conf;",
            "",
            "map $request_uri $required_roles {"
        ]
        
        for page_path, access_info in self.page_access_map.items():
            url = access_info['url']
            roles = ','.join(access_info['roles'])
            nginx_map.append(f"    ~*^{url}$ \"{roles}\";")
        
        nginx_map.append("    default \"viewer\";")
        nginx_map.append("}")
        
        nginx_conf_path = rbac_dir / 'nginx_access.conf'
        with open(nginx_conf_path, 'w') as f:
            f.write('\n'.join(nginx_map))
        
        logger.info(f"✅ Generated Nginx config: {nginx_conf_path}")
    
    def _generate_rbac_manifest(self, config):
        """
        Generate RBAC manifest for API consumption
        
        Output: site/rbac/manifest.json
        Used by: API gateway, authentication middleware
        """
        site_dir = Path(config['site_dir'])
        rbac_dir = site_dir / 'rbac'
        
        manifest = {
            'version': '1.0',
            'generated_at': self._get_timestamp(),
            'pages': self.page_access_map,
            'roles': self.rbac_rules,
            'restricted_count': len(self.restricted_pages),
            'total_pages': len(self.page_access_map)
        }
        
        manifest_path = rbac_dir / 'manifest.json'
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        logger.info(f"✅ Generated RBAC manifest: {manifest_path}")
    
    def _create_default_config(self, config_path: Path):
        """Create default RBAC configuration"""
        default_config = {
            'roles': {
                'viewer': {
                    'permissions': ['docs:read'],
                    'description': 'Read-only access to public documentation'
                },
                'editor': {
                    'permissions': ['docs:read', 'docs:edit'],
                    'description': 'Edit documentation content'
                },
                'developer': {
                    'permissions': ['docs:read', 'api:read'],
                    'description': 'Developer documentation access'
                },
                'admin': {
                    'permissions': ['docs:*', 'api:*', 'admin:*'],
                    'description': 'Full administrative access'
                }
            },
            'page_rules': {
                'api/**': ['developer', 'admin'],
                'internal/**': ['editor', 'admin'],
                'admin/**': ['admin']
            }
        }
        
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, 'w') as f:
            yaml.dump(default_config, f, default_flow_style=False)
        
        logger.info(f"✅ Created default RBAC config: {config_path}")
    
    def _get_timestamp(self) -> str:
        """Get current timestamp for manifest"""
        from datetime import datetime
        return datetime.utcnow().isoformat() + 'Z'


# Integration with enterprise_security.py
class MkDocsRBACIntegration:
    """
    Connects MkDocs RBAC plugin with existing enterprise security system
    
    Usage:
        from scripts.enterprise_security import RBACManager
        
        rbac = RBACManager()
        mkdocs_rbac = MkDocsRBACIntegration(rbac)
        
        # Check access
        can_access = mkdocs_rbac.check_page_access(
            user_id="user123",
            page_url="/api/endpoints/"
        )
    """
    
    def __init__(self, rbac_manager, manifest_path: Path = Path("site/rbac/manifest.json")):
        self.rbac_manager = rbac_manager
        self.manifest = self._load_manifest(manifest_path)
    
    def _load_manifest(self, manifest_path: Path) -> Dict:
        """Load RBAC manifest from build output"""
        if not manifest_path.exists():
            logger.warning(f"⚠️  RBAC manifest not found: {manifest_path}")
            return {'pages': {}}
        
        with open(manifest_path, 'r') as f:
            return json.load(f)
    
    def check_page_access(self, user_id: str, page_url: str) -> bool:
        """
        Check if user can access page
        
        Flow:
        1. Load page access requirements from manifest
        2. Get user roles from RBAC manager
        3. Check if user has required role
        4. Log access attempt (audit trail)
        """
        # Find page in manifest
        page_info = self._find_page_by_url(page_url)
        
        if not page_info:
            # Page not in manifest = public
            return True
        
        required_roles = page_info.get('roles', ['viewer'])
        
        # Check user roles via enterprise RBAC
        for role in required_roles:
            if self.rbac_manager.check_permission(user_id, f"docs:{role}"):
                # Audit log (if enabled)
                self._audit_access(user_id, page_url, "ALLOWED", role)
                return True
        
        # Access denied
        self._audit_access(user_id, page_url, "DENIED", None)
        return False
    
    def _find_page_by_url(self, page_url: str) -> Optional[Dict]:
        """Find page metadata by URL"""
        pages = self.manifest.get('pages', {})
        
        for page_path, page_info in pages.items():
            if page_info.get('url') == page_url:
                return page_info
        
        return None
    
    def _audit_access(self, user_id: str, page_url: str, result: str, role: Optional[str]):
        """Log access attempt to audit system"""
        # This would integrate with scripts/enterprise_security.py AuditLogger
        logger.info(f"AUDIT: user={user_id} page={page_url} result={result} role={role}")
    
    def get_user_accessible_pages(self, user_id: str) -> List[str]:
        """Get list of all pages user can access"""
        accessible = []
        
        pages = self.manifest.get('pages', {})
        for page_path, page_info in pages.items():
            if self.check_page_access(user_id, page_info['url']):
                accessible.append(page_info['url'])
        
        return accessible


# Example: Nginx Lua integration script
NGINX_LUA_RBAC_SCRIPT = """
-- nginx_rbac_auth.lua
-- Runtime RBAC enforcement for MkDocs documentation

local cjson = require "cjson"
local http = require "resty.http"

-- Load RBAC manifest
local function load_rbac_manifest()
    local file = io.open("/usr/share/nginx/html/rbac/manifest.json", "r")
    if not file then
        ngx.log(ngx.ERR, "RBAC manifest not found")
        return nil
    end
    
    local content = file:read("*a")
    file:close()
    return cjson.decode(content)
end

-- Check user authentication (via existing auth system)
local function get_user_roles()
    -- Extract from JWT token or session
    local auth_header = ngx.var.http_authorization
    
    if not auth_header then
        return {"viewer"}  -- Default role
    end
    
    -- Call enterprise auth API
    local httpc = http.new()
    local res, err = httpc:request_uri("http://auth-service:8080/validate", {
        method = "GET",
        headers = {
            ["Authorization"] = auth_header
        }
    })
    
    if not res or res.status ~= 200 then
        return {"viewer"}
    end
    
    local auth_data = cjson.decode(res.body)
    return auth_data.roles or {"viewer"}
end

-- Main RBAC check
local function check_access()
    local manifest = load_rbac_manifest()
    if not manifest then
        return true  -- Fail open if manifest missing
    end
    
    local request_uri = ngx.var.request_uri
    local user_roles = get_user_roles()
    
    -- Find page in manifest
    for page_path, page_info in pairs(manifest.pages) do
        if string.match(request_uri, page_info.url) then
            local required_roles = page_info.roles
            
            -- Check if user has required role
            for _, user_role in ipairs(user_roles) do
                for _, required_role in ipairs(required_roles) do
                    if user_role == required_role then
                        return true
                    end
                end
            end
            
            -- Access denied
            ngx.status = ngx.HTTP_FORBIDDEN
            ngx.say(cjson.encode({
                error = "Access Denied",
                required_roles = required_roles,
                your_roles = user_roles
            }))
            return ngx.exit(ngx.HTTP_FORBIDDEN)
        end
    end
    
    return true  -- Page not restricted
end

-- Execute
check_access()
"""


def save_nginx_lua_script():
    """Save Nginx Lua RBAC script for deployment"""
    script_path = Path("deployment/nginx/lua/nginx_rbac_auth.lua")
    script_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(script_path, 'w') as f:
        f.write(NGINX_LUA_RBAC_SCRIPT)
    
    print(f"✅ Nginx Lua RBAC script saved: {script_path}")


if __name__ == "__main__":
    # Demo: Generate Nginx Lua script
    save_nginx_lua_script()
    
    print("\n" + "="*60)
    print("Enterprise RBAC Plugin for MkDocs")
    print("="*60)
    print("\nUsage:")
    print("1. Add to mkdocs.yml:")
    print("   plugins:")
    print("     - enterprise_rbac:")
    print("         rbac_config: rbac_config.yml")
    print("         audit_enabled: true")
    print("")
    print("2. Add RBAC metadata to pages:")
    print("   ---")
    print("   rbac_roles: [admin, developer]")
    print("   rbac_restricted: true")
    print("   ---")
    print("")
    print("3. Deploy with Nginx + Lua:")
    print("   access_by_lua_file /path/to/nginx_rbac_auth.lua;")
    print("")
    print("4. Integrate with enterprise_security.py:")
    print("   from scripts.enterprise_security import RBACManager")
    print("   rbac = RBACManager()")
    print("   mkdocs_rbac = MkDocsRBACIntegration(rbac)")
