#!/usr/bin/env python3
"""
Automatic Documentation Generator
Extracts docstrings and type hints from code to generate MkDocs pages

AI assistants can run this to keep docs in sync with code changes

Usage:
    python scripts/auto_doc_generator.py --module app.XNAi_rag_app.voice_interface
"""

import ast
import inspect
from pathlib import Path
from typing import List, Dict, Optional
import argparse
from dataclasses import dataclass

@dataclass
class FunctionDoc:
    """Represents a function's documentation"""
    name: str
    signature: str
    docstring: Optional[str]
    parameters: List[Dict[str, str]]
    returns: Optional[str]
    examples: List[str]

class CodeDocExtractor:
    """Extracts documentation from Python code"""
    
    def __init__(self, module_path: Path):
        self.module_path = module_path
        self.module_name = self._get_module_name(module_path)
    
    def _get_module_name(self, path: Path) -> str:
        """Convert file path to module name"""
        # app/XNAi_rag_app/voice_interface.py -> app.XNAi_rag_app.voice_interface
        parts = path.with_suffix("").parts
        # Remove base directory if present
        if parts[0] in ["app", "src"]:
            parts = parts[1:]
        return ".".join(parts)
    
    def extract_module_doc(self) -> Dict:
        """Extract all documentation from module"""
        with open(self.module_path, "r") as f:
            tree = ast.parse(f.read())
        
        module_doc = {
            "name": self.module_name,
            "docstring": ast.get_docstring(tree),
            "classes": [],
            "functions": [],
            "constants": []
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                module_doc["classes"].append(self._extract_class_doc(node))
            elif isinstance(node, ast.FunctionDef):
                if not self._is_method(node, tree):
                    module_doc["functions"].append(self._extract_function_doc(node))
            elif isinstance(node, ast.Assign):
                if self._is_constant(node):
                    module_doc["constants"].append(self._extract_constant_doc(node))
        
        return module_doc
    
    def _extract_class_doc(self, node: ast.ClassDef) -> Dict:
        """Extract class documentation"""
        return {
            "name": node.name,
            "docstring": ast.get_docstring(node),
            "bases": [self._get_name(base) for base in node.bases],
            "methods": [
                self._extract_function_doc(n)
                for n in node.body
                if isinstance(n, ast.FunctionDef)
            ]
        }
    
    def _extract_function_doc(self, node: ast.FunctionDef) -> FunctionDoc:
        """Extract function documentation with type hints"""
        # Get signature
        args = []
        for arg in node.args.args:
            arg_type = self._get_annotation(arg.annotation) if arg.annotation else "Any"
            args.append(f"{arg.arg}: {arg_type}")
        
        returns = self._get_annotation(node.returns) if node.returns else "None"
        signature = f"def {node.name}({', '.join(args)}) -> {returns}"
        
        # Parse docstring for examples
        docstring = ast.get_docstring(node) or ""
        examples = self._extract_examples(docstring)
        
        return FunctionDoc(
            name=node.name,
            signature=signature,
            docstring=docstring,
            parameters=[
                {"name": arg.arg, "type": self._get_annotation(arg.annotation)}
                for arg in node.args.args
            ],
            returns=returns,
            examples=examples
        )
    
    def _extract_constant_doc(self, node: ast.Assign) -> Dict:
        """Extract constant/config documentation"""
        name = node.targets[0].id if hasattr(node.targets[0], 'id') else "unknown"
        value = ast.unparse(node.value) if hasattr(ast, 'unparse') else str(node.value)
        
        return {
            "name": name,
            "value": value,
            "docstring": None  # Constants don't have docstrings in AST
        }
    
    def _get_annotation(self, node) -> str:
        """Convert AST annotation to string"""
        if node is None:
            return "Any"
        if hasattr(ast, 'unparse'):
            return ast.unparse(node)
        return "Any"
    
    def _get_name(self, node) -> str:
        """Get name from AST node"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_name(node.value)}.{node.attr}"
        return "unknown"
    
    def _is_method(self, node: ast.FunctionDef, tree: ast.Module) -> bool:
        """Check if function is a class method"""
        for n in ast.walk(tree):
            if isinstance(n, ast.ClassDef):
                if any(m.name == node.name for m in n.body if isinstance(m, ast.FunctionDef)):
                    return True
        return False
    
    def _is_constant(self, node: ast.Assign) -> bool:
        """Check if assignment is a module-level constant"""
        if not node.targets:
            return False
        target = node.targets[0]
        if hasattr(target, 'id'):
            return target.id.isupper()
        return False
    
    def _extract_examples(self, docstring: str) -> List[str]:
        """Extract code examples from docstring"""
        examples = []
        in_example = False
        current_example = []
        
        for line in docstring.split("\n"):
            if "Example:" in line or ">>> " in line:
                in_example = True
            
            if in_example:
                if line.strip().startswith(">>>") or line.strip().startswith("..."):
                    current_example.append(line.strip()[4:])  # Remove >>> or ...
                elif line.strip() == "" and current_example:
                    examples.append("\n".join(current_example))
                    current_example = []
                    in_example = False
        
        if current_example:
            examples.append("\n".join(current_example))
        
        return examples

class MkDocsPageGenerator:
    """Generates MkDocs markdown from extracted documentation"""
    
    def __init__(self, docs_dir: Path = Path("docs/api")):
        self.docs_dir = docs_dir
        self.docs_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_module_page(self, module_doc: Dict, output_file: Optional[Path] = None):
        """Generate complete API documentation page"""
        if output_file is None:
            # Convert module.name to filename: app.voice -> voice.md
            filename = module_doc["name"].split(".")[-1] + ".md"
            output_file = self.docs_dir / filename
        
        sections = [
            self._generate_header(module_doc),
            self._generate_overview(module_doc),
            self._generate_classes(module_doc["classes"]),
            self._generate_functions(module_doc["functions"]),
            self._generate_constants(module_doc["constants"])
        ]
        
        content = "\n\n".join(filter(None, sections))
        
        with open(output_file, "w") as f:
            f.write(content)
        
        print(f"âœ… Generated documentation: {output_file}")
        return output_file
    
    def _generate_header(self, module_doc: Dict) -> str:
        """Generate page header with metadata"""
        return f"""---
title: {module_doc['name']}
description: Auto-generated API documentation
tags:
  - api
  - python
  - auto-generated
---

# `{module_doc['name']}`"""
    
    def _generate_overview(self, module_doc: Dict) -> str:
        """Generate module overview section"""
        if not module_doc.get("docstring"):
            return ""
        
        return f"""## Overview

{module_doc['docstring']}"""
    
    def _generate_classes(self, classes: List[Dict]) -> str:
        """Generate class documentation sections"""
        if not classes:
            return ""
        
        sections = ["## Classes"]
        
        for cls in classes:
            sections.append(f"### `{cls['name']}`")
            
            if cls.get("bases"):
                bases = ", ".join(f"`{b}`" for b in cls["bases"])
                sections.append(f"**Inherits from:** {bases}")
            
            if cls.get("docstring"):
                sections.append(f"\n{cls['docstring']}\n")
            
            # Methods
            if cls.get("methods"):
                sections.append("#### Methods")
                for method in cls["methods"]:
                    sections.append(self._format_function(method))
        
        return "\n\n".join(sections)
    
    def _generate_functions(self, functions: List[FunctionDoc]) -> str:
        """Generate function documentation sections"""
        if not functions:
            return ""
        
        sections = ["## Functions"]
        
        for func in functions:
            sections.append(self._format_function(func))
        
        return "\n\n".join(sections)
    
    def _format_function(self, func: FunctionDoc) -> str:
        """Format a single function's documentation"""
        parts = [f"### `{func.name}()`"]
        
        # Signature
        parts.append(f"```python\n{func.signature}\n```")
        
        # Docstring
        if func.docstring:
            parts.append(func.docstring)
        
        # Parameters table
        if func.parameters:
            parts.append("**Parameters:**")
            parts.append("")
            parts.append("| Parameter | Type | Description |")
            parts.append("|-----------|------|-------------|")
            for param in func.parameters:
                # Extract param description from docstring if available
                desc = self._extract_param_desc(func.docstring, param["name"])
                parts.append(f"| `{param['name']}` | `{param['type']}` | {desc} |")
        
        # Returns
        if func.returns and func.returns != "None":
            return_desc = self._extract_return_desc(func.docstring)
            parts.append(f"**Returns:** `{func.returns}` - {return_desc}")
        
        # Examples
        if func.examples:
            parts.append("**Example:**")
            for example in func.examples:
                parts.append(f"```python\n{example}\n```")
        
        return "\n\n".join(parts)
    
    def _generate_constants(self, constants: List[Dict]) -> str:
        """Generate constants section"""
        if not constants:
            return ""
        
        sections = ["## Constants"]
        sections.append("")
        sections.append("| Name | Value |")
        sections.append("|------|-------|")
        
        for const in constants:
            sections.append(f"| `{const['name']}` | `{const['value']}` |")
        
        return "\n".join(sections)
    
    def _extract_param_desc(self, docstring: Optional[str], param_name: str) -> str:
        """Extract parameter description from docstring"""
        if not docstring:
            return ""
        
        # Look for "Args:" or "Parameters:" section
        import re
        pattern = rf"{param_name}[:\s]+(.+?)(?:\n\s*\n|\n\s*\w+:)"
        match = re.search(pattern, docstring, re.DOTALL)
        
        if match:
            return match.group(1).strip().replace("\n", " ")
        return ""
    
    def _extract_return_desc(self, docstring: Optional[str]) -> str:
        """Extract return description from docstring"""
        if not docstring:
            return ""
        
        import re
        pattern = r"Returns?[:\s]+(.+?)(?:\n\s*\n|\n\s*\w+:|$)"
        match = re.search(pattern, docstring, re.DOTALL | re.IGNORECASE)
        
        if match:
            return match.group(1).strip().replace("\n", " ")
        return ""

def main():
    parser = argparse.ArgumentParser(
        description="Generate MkDocs API documentation from Python code"
    )
    parser.add_argument(
        "--module",
        required=True,
        help="Module path (e.g., app/XNAi_rag_app/voice_interface.py)"
    )
    parser.add_argument(
        "--output-dir",
        default="docs/api",
        help="Output directory for generated docs"
    )
    
    args = parser.parse_args()
    
    module_path = Path(args.module)
    if not module_path.exists():
        print(f"❌ Module not found: {module_path}")
        return
    
    # Extract documentation
    extractor = CodeDocExtractor(module_path)
    module_doc = extractor.extract_module_doc()
    
    # Generate MkDocs page
    generator = MkDocsPageGenerator(docs_dir=Path(args.output_dir))
    output_file = generator.generate_module_page(module_doc)
    
    print(f"")
    print(f"Next steps:")
    print(f"1. Review generated docs: {output_file}")
    print(f"2. Run 'mkdocs build' to regenerate site")
    print(f"3. Commit changes to version control")

if __name__ == "__main__":
    main()
