#!/usr/bin/env python3
"""
Enterprise Monitoring Integration for MkDocs
Prometheus metrics collection for documentation system

Metrics Categories:
1. Build Performance (duration, file count, plugin timing)
2. Search Performance (query latency, result count, cache hits)
3. Content Analytics (page views, search queries, user sessions)
4. System Health (memory usage, CPU time, error rates)

Integration: Connects to scripts/enterprise_monitoring.py
"""

from mkdocs.plugins import BasePlugin
from mkdocs.config import config_options
from prometheus_client import Counter, Histogram, Gauge, push_to_gateway
from prometheus_client import CollectorRegistry
import time
import psutil
from pathlib import Path
from typing import Dict, Optional
import logging

logger = logging.getLogger("mkdocs.plugins.prometheus")

class PrometheusMetricsPlugin(BasePlugin):
    """
    MkDocs plugin for Prometheus metrics collection
    
    Exposes metrics to existing enterprise_monitoring.py Prometheus stack
    
    Metrics exposed:
    - mkdocs_build_duration_seconds (histogram)
    - mkdocs_build_files_total (gauge)
    - mkdocs_build_pages_total (gauge)
    - mkdocs_plugin_duration_seconds{plugin="name"} (histogram)
    - mkdocs_search_index_size_bytes (gauge)
    - mkdocs_build_memory_usage_bytes (gauge)
    - mkdocs_build_errors_total (counter)
    """
    
    config_scheme = (
        ('pushgateway_url', config_options.Type(str, default='http://localhost:9091')),
        ('job_name', config_options.Type(str, default='mkdocs_builds')),
        ('enable_push', config_options.Type(bool, default=True)),
        ('collect_system_metrics', config_options.Type(bool, default=True)),
        ('plugin_timing', config_options.Type(bool, default=True)),
    )
    
    def __init__(self):
        self.registry = CollectorRegistry()
        self.build_start_time = None
        self.plugin_timings: Dict[str, float] = {}
        self.error_count = 0
        
        # Define metrics
        self._init_metrics()
    
    def _init_metrics(self):
        """Initialize Prometheus metrics"""
        # Build performance
        self.build_duration = Histogram(
            'mkdocs_build_duration_seconds',
            'Total MkDocs build duration',
            registry=self.registry
        )
        
        self.build_files = Gauge(
            'mkdocs_build_files_total',
            'Total number of files processed',
            registry=self.registry
        )
        
        self.build_pages = Gauge(
            'mkdocs_build_pages_total',
            'Total number of pages generated',
            registry=self.registry
        )
        
        # Plugin performance
        self.plugin_duration = Histogram(
            'mkdocs_plugin_duration_seconds',
            'Plugin execution duration',
            ['plugin_name'],
            registry=self.registry
        )
        
        # Search metrics
        self.search_index_size = Gauge(
            'mkdocs_search_index_size_bytes',
            'Search index size in bytes',
            registry=self.registry
        )
        
        # System metrics
        self.memory_usage = Gauge(
            'mkdocs_build_memory_usage_bytes',
            'Memory usage during build',
            registry=self.registry
        )
        
        self.cpu_time = Gauge(
            'mkdocs_build_cpu_seconds_total',
            'CPU time consumed by build',
            registry=self.registry
        )
        
        # Error tracking
        self.build_errors = Counter(
            'mkdocs_build_errors_total',
            'Total number of build errors',
            ['error_type'],
            registry=self.registry
        )
    
    def on_startup(self, command, dirty):
        """Record build start time"""
        self.build_start_time = time.time()
        logger.info("📊 Prometheus metrics collection started")
        
        if self.config['collect_system_metrics']:
            self._collect_initial_system_metrics()
    
    def on_files(self, files, config):
        """Record file count"""
        self.build_files.set(len(files))
        logger.debug(f"📁 Files to process: {len(files)}")
        return files
    
    def on_page_markdown(self, markdown, page, config, files):
        """Track page processing"""
        # Could add per-page timing here if needed
        return markdown
    
    def on_post_build(self, config):
        """Collect final metrics and push to Prometheus"""
        if self.build_start_time:
            build_duration = time.time() - self.build_start_time
            self.build_duration.observe(build_duration)
            logger.info(f"⏱️  Build duration: {build_duration:.2f}s")
        
        # Collect post-build metrics
        self._collect_search_metrics(config)
        self._collect_system_metrics()
        
        # Push to Prometheus Push Gateway
        if self.config['enable_push']:
            self._push_metrics()
    
    def _collect_initial_system_metrics(self):
        """Collect system metrics at build start"""
        process = psutil.Process()
        
        # Memory usage
        memory_info = process.memory_info()
        self.memory_usage.set(memory_info.rss)
        
        # CPU time
        cpu_times = process.cpu_times()
        self.cpu_time.set(cpu_times.user + cpu_times.system)
    
    def _collect_system_metrics(self):
        """Collect final system metrics"""
        process = psutil.Process()
        
        # Peak memory usage
        memory_info = process.memory_info()
        self.memory_usage.set(memory_info.rss)
        
        # Total CPU time
        cpu_times = process.cpu_times()
        self.cpu_time.set(cpu_times.user + cpu_times.system)
    
    def _collect_search_metrics(self, config):
        """Collect search index metrics"""
        site_dir = Path(config['site_dir'])
        search_index = site_dir / 'search' / 'search_index.json'
        
        if search_index.exists():
            size = search_index.stat().st_size
            self.search_index_size.set(size)
            logger.debug(f"🔍 Search index size: {size} bytes")
    
    def _push_metrics(self):
        """Push metrics to Prometheus Push Gateway"""
        try:
            push_to_gateway(
                gateway=self.config['pushgateway_url'],
                job=self.config['job_name'],
                registry=self.registry
            )
            logger.info(f"✅ Metrics pushed to {self.config['pushgateway_url']}")
        except Exception as e:
            logger.error(f"❌ Failed to push metrics: {e}")
            self.build_errors.labels(error_type='metrics_push').inc()


class MkDocsMetricsExporter:
    """
    Standalone metrics exporter for MkDocs documentation system
    
    Runs as HTTP server exposing /metrics endpoint
    Integrates with Prometheus scraping
    """
    
    def __init__(self, port: int = 9101):
        self.port = port
        from prometheus_client import start_http_server
        start_http_server(port)
        logger.info(f"📊 Metrics server started on :{port}")
    
    def expose_runtime_metrics(self):
        """
        Expose runtime documentation metrics
        
        For live MkDocs serve or deployed static site with analytics
        """
        # Page view counter (requires JS integration)
        page_views = Counter(
            'mkdocs_page_views_total',
            'Total page views',
            ['page_path']
        )
        
        # Search query counter
        search_queries = Counter(
            'mkdocs_search_queries_total',
            'Total search queries',
            ['query_term']
        )
        
        # Session tracking
        active_sessions = Gauge(
            'mkdocs_active_sessions',
            'Current active documentation sessions'
        )
        
        return {
            'page_views': page_views,
            'search_queries': search_queries,
            'active_sessions': active_sessions
        }


# Integration with enterprise_monitoring.py
def integrate_with_enterprise_monitoring():
    """
    Connect MkDocs metrics to existing Prometheus stack
    
    File: scripts/enterprise_monitoring.py
    Class: EnterpriseMonitoringSystem
    
    Integration points:
    1. Add MkDocs metrics to Prometheus collector
    2. Create Grafana dashboard for documentation metrics
    3. Set up alerting rules for build failures
    """
    
    # Example Grafana dashboard JSON
    grafana_dashboard = {
        "dashboard": {
            "title": "MkDocs Documentation System",
            "panels": [
                {
                    "title": "Build Duration",
                    "targets": [{
                        "expr": "mkdocs_build_duration_seconds",
                        "legendFormat": "Build Time"
                    }],
                    "type": "graph"
                },
                {
                    "title": "Search Index Size",
                    "targets": [{
                        "expr": "mkdocs_search_index_size_bytes",
                        "legendFormat": "Index Size (bytes)"
                    }],
                    "type": "stat"
                },
                {
                    "title": "Build Errors",
                    "targets": [{
                        "expr": "rate(mkdocs_build_errors_total[5m])",
                        "legendFormat": "Error Rate"
                    }],
                    "type": "graph"
                },
                {
                    "title": "Memory Usage",
                    "targets": [{
                        "expr": "mkdocs_build_memory_usage_bytes",
                        "legendFormat": "Memory (bytes)"
                    }],
                    "type": "graph"
                }
            ]
        }
    }
    
    return grafana_dashboard


# Prometheus alerting rules
PROMETHEUS_ALERT_RULES = """
# MkDocs Documentation Alerts
# Add to prometheus/rules/mkdocs_alerts.yml

groups:
  - name: mkdocs_documentation
    interval: 30s
    rules:
      - alert: MkDocsBuildSlow
        expr: mkdocs_build_duration_seconds > 60
        for: 2m
        labels:
          severity: warning
          component: documentation
        annotations:
          summary: "MkDocs build taking too long"
          description: "Build duration {{ $value }}s exceeds threshold of 60s"
      
      - alert: MkDocsBuildFailed
        expr: increase(mkdocs_build_errors_total[5m]) > 0
        for: 1m
        labels:
          severity: critical
          component: documentation
        annotations:
          summary: "MkDocs build errors detected"
          description: "{{ $value }} build errors in last 5 minutes"
      
      - alert: MkDocsSearchIndexTooLarge
        expr: mkdocs_search_index_size_bytes > 10485760  # 10MB
        for: 5m
        labels:
          severity: warning
          component: documentation
        annotations:
          summary: "Search index size excessive"
          description: "Index size {{ $value }} bytes may impact performance"
      
      - alert: MkDocsHighMemoryUsage
        expr: mkdocs_build_memory_usage_bytes > 2147483648  # 2GB
        for: 2m
        labels:
          severity: warning
          component: documentation
        annotations:
          summary: "MkDocs build using excessive memory"
          description: "Memory usage {{ $value }} bytes exceeds threshold"
"""


def save_prometheus_alerts():
    """Save Prometheus alert rules"""
    alerts_path = Path("prometheus/rules/mkdocs_alerts.yml")
    alerts_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(alerts_path, 'w') as f:
        f.write(PROMETHEUS_ALERT_RULES)
    
    print(f"✅ Prometheus alert rules saved: {alerts_path}")


# JavaScript snippet for client-side metrics
CLIENT_SIDE_METRICS_JS = """
// docs/javascripts/metrics.js
// Client-side metrics collection for MkDocs

(function() {
    // Metrics endpoint (Prometheus Push Gateway or custom endpoint)
    const METRICS_ENDPOINT = '/api/metrics';
    
    // Track page views
    function trackPageView() {
        const pageUrl = window.location.pathname;
        
        fetch(METRICS_ENDPOINT, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                metric: 'page_view',
                page: pageUrl,
                timestamp: Date.now()
            })
        }).catch(err => console.error('Metrics error:', err));
    }
    
    // Track search queries
    function trackSearch(query) {
        fetch(METRICS_ENDPOINT, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                metric: 'search_query',
                query: query,
                timestamp: Date.now()
            })
        }).catch(err => console.error('Metrics error:', err));
    }
    
    // Track time on page
    let pageLoadTime = Date.now();
    window.addEventListener('beforeunload', function() {
        const timeOnPage = Date.now() - pageLoadTime;
        
        navigator.sendBeacon(METRICS_ENDPOINT, JSON.stringify({
            metric: 'time_on_page',
            page: window.location.pathname,
            duration_ms: timeOnPage
        }));
    });
    
    // Initialize
    trackPageView();
    
    // Hook into MkDocs search
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.querySelector('[data-md-component="search-query"]');
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                if (e.target.value.length > 2) {
                    trackSearch(e.target.value);
                }
            });
        }
    });
})();
"""


if __name__ == "__main__":
    print("="*60)
    print("Enterprise Monitoring Integration for MkDocs")
    print("="*60)
    print("\nSetup Instructions:")
    print("\n1. Add plugin to mkdocs.yml:")
    print("   plugins:")
    print("     - prometheus_metrics:")
    print("         pushgateway_url: http://localhost:9091")
    print("         enable_push: true")
    print("")
    print("2. Deploy Prometheus Push Gateway:")
    print("   docker run -d -p 9091:9091 prom/pushgateway")
    print("")
    print("3. Configure Prometheus scraping:")
    print("   scrape_configs:")
    print("     - job_name: 'mkdocs'")
    print("       static_configs:")
    print("         - targets: ['pushgateway:9091']")
    print("")
    print("4. Import Grafana dashboard:")
    print("   dashboard = integrate_with_enterprise_monitoring()")
    print("")
    
    # Generate alert rules
    save_prometheus_alerts()
    
    # Save client-side metrics
    js_path = Path("docs/javascripts/metrics.js")
    js_path.parent.mkdir(parents=True, exist_ok=True)
    with open(js_path, 'w') as f:
        f.write(CLIENT_SIDE_METRICS_JS)
    print(f"✅ Client-side metrics saved: {js_path}")
